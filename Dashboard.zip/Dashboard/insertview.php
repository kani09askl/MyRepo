<?php
session_start();
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];



    $_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;

	if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}

//echo $dept_id_db;

?>
<head>
	
	<meta http-equiv="Content-Type" content="text/html" charset=ISO-8859-1">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery.min.js"> </script>
        <script type="text/javascript" src="js/bootstrap.min.js" ></script>
</head> 

<?php


function dept_details()
{
?>
<html>
<head>
<title>Dept_details</title>
</head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=dept_details" method="post" enctype="multipart/form-data">
<center>
<table>
<tr>
<td id="td">About the Course:</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_message" required style="background-color: white;">
</textarea></td>
</tr>
<tr>
<td id="td">Long Term Goal:</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message1" required style="background-color: white;"> 
</textarea></td>
</tr>
<tr>
<td id="td">Short Term Goal:</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message2" required style="background-color: white;">
</textarea></td>
</tr>
<tr>
<td id="td">Programme Educational Objective:</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message3" required style="background-color: white;">
</textarea></td>
</tr>
<tr>
<td id="td">Programme Outcomes</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message4" required style="background-color: white;">
</textarea></td>
</tr>
<tr>
<td id="td">Department Quote</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message5" required style="background-color: white;" maxlength="50" placeholder="(Maximum 50 characters)">
</textarea></td>
</tr>
<tr>
<td id="td">Dept_hod_name </td>
<td><textarea rows="2" cols="45" id="msg" name="dept_hod_name" required style="background-color: white;" >
</textarea></td>
</tr>
<tr>
<td id="td">Dept_hod_address </td>
<td><textarea rows="7" cols="60" id="msg" name="dept_hod_address" required style="background-color: white;">
</textarea></td>
</tr>
<tr>
				<td id="ftd">Image</td>
				<td><input type="file"  id="img" name="image1" ></td>
			</tr>
</table>
<input type="submit" value="Insert" id="nsub">
</center>
</form>
</body>
</html>
<?php
}
?>
<?php
function lab_details()
{
?>
<html>
<head><title>Lab_Details</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=lab" method="post" enctype="multipart/form-data">
<center>
<table>
<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file"  id="img" name="image1" ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file"  id="img" name="image2" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" id="img" name="image3" ></td>
			</tr>
			<tr>
				<td id="ftd">Image4</td>
				<td><input type="file"  id="img" name="image4" ></td>
			</tr>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required></textarea></td>
			</tr>
			
</table>
<input type="submit" value="Insert" id="nsub">
</center>
</form>
</body>
</html>

<?php

}

function rnd()
{
?>
<html><head>
<title>Research and Developement Center</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=rnd" method="post" enctype="multipart/form-data">
	<center>
		<table>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file"  id="img" name="image1" ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" id="img" name="image2" ></td>
			</tr><tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required  style="background-color: white;"></textarea></td>
			</tr>
		</table>
		<input type="submit" value="Insert" id="nsub">
	</center>
	</form>
</body>
</html>
<?php

}
function tieups()
{
?>
<html>
<head><title>Tieups</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=tieups" method="post" enctype="multipart/form-data"><center>
		<table>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required ></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" id="img" name="image1" ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file"  id="img" name="image2" ></td>
			</tr><tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required  style="background-color: white;"></textarea></td>
			</tr>
		</table>
		<input type="submit" value="Insert" id="nsub">
	</center>

</form>
</body>
</html>

<?php

}
function achievements()
{
?>
<html>
<head><title>Achievements</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=achievements" method="post" enctype="multipart/form-data">
<center>
		<table>
			<tr>
				<td id="ftd">Achievers name </td>
				<td><input type="text" id="name" name="achieversname" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Prize Gain </td>
				<td><textarea  id="title" name="gain" required></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Date </td>
				<td><input type="date" id="date" name="date" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Image</td>
				<td><input type="file" id="img" name="image1" ></td>
			</tr>
			<tr>
				<td id="ftd">Organization </td>
				<td><textarea  id="title" name="organization" required></textarea></td>
			</tr>
		</table>
		<input type="submit" value="Insert" id="nsub">
	</center>
</form>
</body>
</html>

<?php
}
function testimonials()
{
?>
<html>
<head><title>Testimonials</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=testimonials" method="post" enctype="multipart/form-data">
<center>
		<table>
			<tr>
				<td id="ftd">Name:</td>
				<td><input type="text" id="name" name="name" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Role:</td>
				<td><textarea  id="name" name="role" required style="background-color: white;"></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Date:</td>
				<td><input type="date" id="name" name="date" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Title:</td>
				<td><textarea  id="name" name="title" required style="background-color: white;"></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image</td>
				<td><input type="file" name="image1" id="img"  ></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"></textarea></td>
			</tr>
		</table>
		<input type="submit" value="Insert" name="Insert" id="nsub">
	</center>
</form>
</body>
</html>
<?php
}
function faculty()
{
?>
<html>
<head><title>Faculty</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=faculty" method="post" enctype="multipart/form-data">
<center>
	<table>
		<tr>
<td id="td1">Name </td>
<td><input type="text" id="fname" name="name" required style="background-color: white;"></td>
</tr>
<tr>
<td id="td2">Degree </td>
<td><input type="text" id="deg" name="degree" required style="background-color: white;"></td>
</tr>
<tr>
<td id="td3">Designation</td>
<td><select name="designation" id="des" required style="background-color: white;">
    <option></option>
    <option value="hod">HOD</option>
    <option value="Assistant Professor">Assistant Professor</option>
     <option value="Associate Professor">Associate professor</option>
      <option value="librarian">Librarian</option>
       <option value="staff">Staff</option>
        <option value="pt">Pysical Trainner</option>
        <option >Asst.Physical Director</option>
  </select></td>
</tr>
</table>
<input type="submit" value="Insert" id="nsub">	
</center>
</form>
</body>

</html>
?>
<?php
}
function news_events()
{
?>
<html>
<head><title>News_Events</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=news_events" method="post" enctype="multipart/form-data">
	<center>
		<table>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Date </td>
				<td><input type="date" id="date" name="date" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" name="image1" id="img"  ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" name="image2" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" name="image3" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image4</td>
				<td><input type="file" name="image4" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image5</td>
				<td><input type="file" name="image5" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image6</td>
				<td><input type="file" name="image6" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image7</td>
				<td><input type="file" name="image7" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image8</td>
				<td><input type="file" name="image8" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image9</td>
				<td><input type="file" name="image9" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image10</td>
				<td><input type="file" name="image0" id="img" ></td>
			</tr>
		</table>
		<input type="submit" value="Insert" id="nsub">
	</center>
	</form>
</body>
</html>
<?php
}
function facility()
{
?>
<html>
<head><title>Facility</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=facility" method="post" enctype="multipart/form-data">
	<center>
		<table>
			<tr>
			<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" name="image1" id="img"  ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" name="image2" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" name="image4" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image4</td>
				<td><input type="file" name="image5" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image5</td>
				<td><input type="file" name="image6" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;">
				</textarea></td>
			</tr>
			</table>
		<input type="submit" value="Insert" id="nsub">
	</center>
	</form>
</body>
</html>
<?php
}
function advertisement()
{
?>
<html>
<head><title>Advertisement</title></head>
<body style="background-color: white;">
<form action="dbinsertion.php?field=advertisement" method="post" enctype="multipart/form-data">
	<center>
		<table>
		<tr>
			<td id="ftd">Event Name:</td>
				<td><textarea  id="title" name="title" required style="background-color: white;"></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required  style="background-color: white;"></textarea></td>
			</tr>
            <tr>
				<td id="ftd">Date:</td>
				<td><input type="date" id="name" name="date" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" name="image1" id="img"  ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" name="image2" id="img" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" name="image3" id="img" ></td>
			</tr>
			<td id="ftd">Registration_Link </td>
				<td><textarea  id="title" name="reglink" style="background-color: white;"></textarea></td>
			</tr>
		</table>
		<input type="submit" value="Insert" id="nsub">
	</center>
	</form>
</body>
</html>
<?php
}
?>	