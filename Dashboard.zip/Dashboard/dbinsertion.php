<?php
session_start();
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];
$field=$_GET['field'];
require 'db.php';

if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}

//echo $dept_id_db;

?>
<?php

$image1=$image2=$image3=$image4=$image5=$image6=$image7=$image8=$image9=$image0="";

function image1()
{
   global $image1;global $dept_id_db;
        
        if(basename( $_FILES['image1']['name'])==true){
          $path = "uploads/";
        $image1 = $path .$dept_id_db."_" . basename( $_FILES['image1']['name']);
        move_uploaded_file($_FILES['image1']['tmp_name'], $image1);
        //echo $image1;
      }

}
function image2()
{
   global $image2;global $dept_id_db;
       
        if(basename( $_FILES['image2']['name'])==true){
        $path = "uploads/";
        $image2 = $path.$dept_id_db."_"  . basename( $_FILES['image2']['name']);
        move_uploaded_file($_FILES['image2']['tmp_name'], $image2);
       // echo $image2;
      }
    }
function image3()
{
   global $image3;global $dept_id_db;
       
        if(basename( $_FILES['image3']['name'])==true){
        $path = "uploads/";
        $image3 = $path .$dept_id_db."_" . basename( $_FILES['image3']['name']);
        move_uploaded_file($_FILES['image3']['tmp_name'], $image3);
        //echo $image3;
      }
    }
    function image4()
{
   global $image4;global $dept_id_db;
       
        if(basename( $_FILES['image4']['name'])==true){
        $path = "uploads/";
        $image4 = $path .$dept_id_db."_" . basename( $_FILES['image4']['name']);
        move_uploaded_file($_FILES['image4']['tmp_name'], $image4);
        //echo $image4;
      }
    }
    function image5()
{
   global $image5;global $dept_id_db;
       
        if(basename( $_FILES['image5']['name'])==true){
        $path = "uploads/";
        $image5 = $path .$dept_id_db."_" . basename( $_FILES['image5']['name']);
        move_uploaded_file($_FILES['image5']['tmp_name'], $image5);
        //echo $image5;
      }
    }


    function image6()
{
   global $image6;global $dept_id_db;
       
        if(basename( $_FILES['image6']['name'])==true){
        $path="uploads/";
        $image6=$path.$dept_id_db."_" .basename( $_FILES['image6']['name']);
        move_uploaded_file($_FILES['image6']['tmp_name'],$image6);
        //echo $image6;
      }
    }
function image7()
{
   global $image7;global $dept_id_db;
       
        if(basename( $_FILES['image7']['name'])==true){
        $path = "uploads/";
        $image7=$path.$dept_id_db."_" .basename( $_FILES['image7']['name']);
        move_uploaded_file($_FILES['image7']['tmp_name'],$image7);
        //echo $image7;
      }
    }
function image8()
{
   global $image8;global $dept_id_db;
       
        if(basename( $_FILES['image8']['name'])==true){
        $path = "uploads/";
        $image8=$path.$dept_id_db."_" .basename( $_FILES['image8']['name']);
        move_uploaded_file($_FILES['image8']['tmp_name'],$image8);
        //echo $image8;
      }
    }    
                                  
function image9()
{
   global $image9;global $dept_id_db;
       
        if(basename( $_FILES['image9']['name'])==true){
        $path = "uploads/";
        $image9=$path.$dept_id_db."_" .basename( $_FILES['image9']['name']);
        move_uploaded_file($_FILES['image9']['tmp_name'],$image9);
        //echo $image9;
      }
    }
 function image0()
{
   global $image0;global $dept_id_db;
       
        if(basename( $_FILES['image0']['name'])==true){
        $path = "uploads/";
        $image0=$path.$dept_id_db."_" .basename( $_FILES['image0']['name']);
        move_uploaded_file($_FILES['image0']['tmp_name'], $image0);
        //echo $image0;
      }
    }   
?>
<?php


if($field=="dept_details")
{


$dept_message=@mysqli_real_escape_string($con,$_POST['dept_message']);
$dept_sub_message1=@mysqli_real_escape_string($con,$_POST['dept_sub_message1']);
$dept_sub_message2=@mysqli_real_escape_string($con,$_POST['dept_sub_message2']);
$dept_sub_message3=@mysqli_real_escape_string($con,$_POST['dept_sub_message3']);
$dept_sub_message4=@mysqli_real_escape_string($con,$_POST['dept_sub_message4']);
$dept_sub_message5=@mysqli_real_escape_string($con,$_POST['dept_sub_message5']);
$dept_hod_name=@mysqli_real_escape_string($con,$_POST['dept_hod_name']);
$dept_hod_address=@mysqli_real_escape_string($con,$_POST['dept_hod_address']);
//$image=$_POST['image1'];
image1();


$str="insert into sce_department_details values('','$dept_id_db','$dept_message','$dept_sub_message1','$dept_sub_message2','$dept_sub_message3','$dept_sub_message4','$dept_sub_message5','$dept_hod_name','$dept_hod_address','$image1')";


}


elseif($field=="rnd")
{
   $title=@mysqli_real_escape_string($con,$_POST['title']);
   $message=@mysqli_real_escape_string($con,$_POST['message']);
   image1();image2();
   
   //echo $image2;
   
   $str="insert into sce_rd values('','$dept_id_db','$title','$image1','$image2','$message')";
   
   
 

}
elseif($field=="tieups")
{
   $title=@mysqli_real_escape_string($con,$_POST['title']);
   $message=@mysqli_real_escape_string($con,$_POST['message']);

   image1();image2();
   
   $str="insert into sce_tieups values('','$dept_id_db','$title','$image1','$image2','$message')";
   
   
   

}
elseif($field=="lab")
{
   
  $title=@mysqli_real_escape_string($con,$_POST['title']);
   $message=@mysqli_real_escape_string($con,$_POST['message']);
   image1();image2();image3();image4();
    
$str="insert into sce_lab values('','$dept_id_db','$message','$image1','$image2','$image3','$image4','$title')";
}

elseif($field=="achievements")
{
   
   
   $title=@mysqli_real_escape_string($con,$_POST['title']);
   $name=@mysqli_real_escape_string($con,$_POST['achieversname']);
   $date=$_POST['date'];
   $message=@mysqli_real_escape_string($con,$_POST['message']);
   $gain=@mysqli_real_escape_string($con,$_POST['gain']);
   $organization=@mysqli_real_escape_string($con,$_POST['organization']);

   image1();
       $str="insert into sce_achievement values('','$dept_id_db','$name','$title','$gain','$message','$date','$image1','$organization')";
   }   
elseif($field=="testimonials")
{
   
   
   $title=@mysqli_real_escape_string($con,$_POST['title']);
   $name=@mysqli_real_escape_string($con,$_POST['name']);
   $date=$_POST['date'];
   $role=@mysqli_real_escape_string($con,$_POST['role']);
   $message=@mysqli_real_escape_string($con,$_POST['message']);

   image1();
  $str="insert into sce_testimonials values('','$dept_id_db','$name','$role','$title','$message','$date','$image1')";
}
elseif($field=='faculty')
{
$fname=@mysqli_real_escape_string($con,$_POST['name']);
$degree=$_POST['degree'];
$designation=$_POST['designation'];
 $str="insert into sce_faculty_details values('','$dept_id_db','$fname','$degree','$designation')";
}
elseif($field=="news_events")
{   
      $title=@mysqli_real_escape_string($con,$_POST['title']);
      $message=@mysqli_real_escape_string($con,$_POST['message']);
      $date=$_POST['date'];
        image1();image2();image3();image4();image5();image6();image7();image8();image9();image0();
            $str="insert into sce_newsandevents values('','$dept_id_db','$title','$message','$date','$image1','
            $image2','$image3','$image4','$image5','$image6','$image7','$image8','$image9','$image0')";
}
elseif($field=="facility")
{
   $title=$_POST['title'];
  
      $message=@mysqli_real_escape_string($con,$_POST['message']);
      image1();image2();image4();image5();image6();

      $str="insert into sce_facilities values('','$dept_id_db','$title','$image1','$image2','$image4','$image5','$image6','$message')";
      
}
elseif($field=="advertisement")
{
   $title=@mysqli_real_escape_string($con,$_POST['title']);
  
      $message=@mysqli_real_escape_string($con,$_POST['message']);
      $date=$_POST['date'];
      $reglink=$_POST['reglink'];
      image1();image2();image3();

      $str="insert into sce_advertisement values('','$dept_id_db','$title','$message','$date','$image1','$image2','$image3','$reglink')";
      
}
$query=@mysqli_query($con,$str);


if($query)
{
   echo "<script type=\"text/javascript\">window.alert('Data Inserted successfully');
window.location.href = 'option.php?field=$field';</script>"; 
}
else
{
   echo "<script type=\"text/javascript\">window.alert('Error on inserting data');
window.location.href = 'option.php?field=$field';</script>"; 
}
?>