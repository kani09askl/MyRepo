<?php
require 'db.php';
session_start();
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];

    $_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;

	if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}

$id=$_GET['id'];
$field=$_GET['field'];
?>
<head>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery.min.js"> </script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script>
</head> 

<?php
if($field=="dept_details")
{
$id=$_GET['id'];

$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];
$v4=$_POST['v4'];
$v5=$_POST['v5'];
$v6=$_POST['v6'];
$v7=$_POST['v7'];
$v8=$_POST['v8'];
$v9=$_POST['v9'];
?>
<html>
<head>
<title>Dept_details</title>
</head>
<body style="background-color: white;"><form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>"  method="POST" enctype="multipart/form-data">
<center>
<table>
<tr>
<td id="td">About the Course</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_message" required style="background-color: white;">
<?php echo $v1; ?></textarea></td>
</tr>
<tr>
<td id="td">Long Term Goal</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message1" required style="background-color: white;">
<?php echo $v2; ?></textarea></td>
</tr>
<tr>
<td id="td">Short Term Goal</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message2" required style="background-color: white;">
<?php echo $v3; ?></textarea></td>
</tr>
<tr>
<td id="td">Programme Educational Objective</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message3" required style="background-color: white;">
<?php echo $v4; ?></textarea></td>
</tr>
<tr>
<td id="td">Programme Outcomes</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message4" required style="background-color: white;">
<?php echo $v5; ?></textarea></td>
</tr>
<tr>
<td id="td">Department Quote</td>
<td><textarea rows="7" cols="60" id="msg" name="dept_sub_message5" required style="background-color: white;">
<?php echo $v6; ?></textarea></td>
</tr>
<tr>
<td id="td">Dept_hod_name </td>
<td><textarea rows="2" cols="45" id="msg" name="dept_hod_name" required style="background-color: white;">
<?php echo $v7; ?></textarea></td>
</tr>
<tr>
<td id="td">Dept_hod_address </td>
<td><textarea rows="7" cols="60" id="msg" name="dept_hod_address" required style="background-color: white;">
<?php echo $v8; ?></textarea></td>
</tr>
<tr>
<td id="td">Image </td>
<td><input type="file"  id="img" name="image1" value="<?php echo $v9;?>" ></td>
</tr>
</table>
<input type="submit" value="update" id="dsub">
</center>
</form>
</body>
</html>

 <?php
}
elseif($field=="lab")
{
$id=$_GET['id'];
$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];
$v4=$_POST['v4'];
$v5=$_POST['v5'];
$v6=$_POST['v6'];
//echo $v6;
?>
<html>
<head><title>Lab_Details</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>"  method="POST" enctype="multipart/form-data">
<center>
<table>
<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;">
					<?php echo $v1; ?>
				</textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file"  id="img" name="image1" value="<?php echo $v2;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file"  id="img" name="image2" value="<?php echo $v3;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" id="img" name="image3" value="<?php echo $v4;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image4</td>
				<td><input type="file"  id="img" name="image4" value="<?php echo $v5;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title"  required><?php echo $v6;?></textarea></td>
			</tr>
</table>
</center>
<input type="submit" value="UPDATE" id="nsub" style="margin-left: 500px">
</form>
</body>
</html>

<?php
}
elseif($field=="rnd")
{
$id=$_GET['id'];
$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];
$v4=$_POST['v4'];
//echo $v2;
?>
<html><head>
<title>Research and Developement Center</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>"  method="POST" enctype="multipart/form-data">
<center>
		<table>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required><?php echo $v1; ?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file"  id="img" name="image1" value="<?php echo $v2;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" id="img" name="image2" value="<?php echo $v3;?>" ></td>
			</tr><tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"><?php echo $v4; ?></textarea></td>
			</tr>
		</table>
		<input type="submit" value="UPDATE" id="dsub">
	</center>
	</form>
</body>
</html>

<?php
}
elseif($field=="tieups")
{
$id=$_GET['id'];
$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];
$v4=$_POST['v4'];
?>
<html>
<head><title>Tieups</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>"  method="POST" enctype="multipart/form-data">
<center>
		<table>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required><?php echo $v1; ?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" id="img" name="image1" value="<?php echo $v2;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file"  id="img" name="image2" value="<?php echo $v3;?>" ></td>
			</tr><tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;" ><?php echo $v4; ?></textarea></td>
			</tr>
		</table>
		<input type="submit" value="UPDATE" id="dsub">
	</center>

</form>
</body>
</html>

<?php
}
elseif($field=="achievements")
{
$id=$_GET['id'];
$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];
$v4=$_POST['v4'];
$v5=$_POST['v5'];
$v6=$_POST['v6'];
$v7=$_POST['v7'];
?>
<html>
<head><title>Achievements</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>" method="post" enctype="multipart/form-data">
<center>
		<table>
			<tr>
				<td id="ftd">Achievers name </td>
				<td><input type="text" id="name" name="achieversname" value="<?php echo $v1;?>" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required><?php echo $v2;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Prize Gain </td>
				<td><textarea  id="title" name="gain" required><?php echo $v3;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"><?php echo $v4;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Date </td>
				<td><input type="date" id="date" name="date" value="<?php echo $v5;?>" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Image</td>
				<td><input type="file" id="img" name="image1" value="<?php echo $v6;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Organization</td>
				<td><textarea  id="title" name="organization" required><?php echo $v7;?></textarea></td>
			</tr>
		</table>
		<input type="submit" value="UPDATE" id="nsub">
	</center>
</form>
</body>
</html>


<?php
}
elseif($field=="testimonials")
{
$id=$_GET['id'];
$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];
$v4=$_POST['v4'];
$v5=$_POST['v5'];
$v6=$_POST['v6'];
?>
<html>
<head><title>Testmonials</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>" method="post" enctype="multipart/form-data">
<center>
		<table>
			<tr>
				<td id="ftd">Name:</td>
				<td><input type="text" id="name" name="name" value="<?php echo $v1;?>" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Role:</td>
				<td><textarea id="name" name="role" required style="background-color: white;"><?php echo $v2;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Date:</td>
				<td><input type="date" id="name" name="date" value="<?php echo $v5;?>" required style="background-color: white;"></td>
			</tr>
			<tr>
				<td id="ftd">Title:</td>
				<td><textarea  id="name" name="title" required style="background-color: white;"><?php echo $v3;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image</td>
				<td><input type="file" name="image1" id="img" value="<?php echo $v6;?>"></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"><?php echo $v4;?></textarea></td>
			</tr>
		</table>
		<input type="submit" value="UPDATE" id="dsub">
	</center>
</form>
</body>
</html>

<?php
}
elseif($field=="faculty"){
$id=$_GET['id'];
$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];

?>
<html>
<head><title>Faculty</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>" method="post" enctype="multipart/form-data">
<center>
	<table>
		<tr>
<td id="td1">Name </td>
<td><input type="text" id="fname" name="name" value="<?php echo $v1;?>" required style="background-color: white;"></td>
</tr>
<tr>
<td id="td2">Degree </td>
<td><input type="text" id="deg" name="degree" value="<?php echo $v2;?>" required style="background-color: white;"></td>
</tr>
<tr>
<td id="td3">Designation</td>
<td><select name="designation" value="<?php echo $v3;?>" id="des" required style="background-color: white;">
    <option></option>
    <option value="hod">HOD</option>
    <option value="Assistant Professor">Assistant Professor</option>
     <option value="Associate Professor">Associate professor</option>
      <option value="librarian">Librarian</option>
       <option value="staff">Staff</option>
        <option value="pt">Pysical Trainner</option>
  </select></td>
</tr>
</table>
<input type="submit" value="UPDATE" id="nsub">	
</center>
</form>
</body></html>
<?php
}
elseif($field=="news_events")
{
	$title=$_POST['title'];
	$message=$_POST['message'];
	$date=$_POST['date'];
	$v1=$_POST['v1'];
	$v2=$_POST['v2'];
	$v3=$_POST['v3'];
	$v4=$_POST['v4'];
	$v5=$_POST['v5'];
	$v6=$_POST['v6'];
	$v7=$_POST['v7'];
	$v8=$_POST['v8'];
	$v9=$_POST['v9'];
	$v0=$_POST['v0'];
?>
<html>
<head><title>News_Events</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>" method="post" enctype="multipart/form-data">
	<center>
		<table>
			<tr>
				<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required><?php echo $title;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"><?php echo $message;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Date </td>
				<td><input type="date" id="date" name="date" value="<?php echo $date;?>" required ></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" name="image1" id="img"  value="<?php echo $v1;?>"  ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" name="image2" id="img" value="<?php echo $v2;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" name="image3" id="img" value="<?php echo $v3;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image4</td>
				<td><input type="file" name="image4" id="img" value="<?php echo $v4;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image5</td>
				<td><input type="file" name="image5" id="img" value="<?php echo $v5;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image6</td>
				<td><input type="file" name="image6" id="img" value="<?php echo $v6;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image7</td>
				<td><input type="file" name="image7" id="img" value="<?php echo $v7;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image8</td>
				<td><input type="file" name="image8" id="img" value="<?php echo $v8;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image9</td>
				<td><input type="file" name="image9" id="img" value="<?php echo $v9;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image10</td>
				<td><input type="file" name="image0" id="img" value="<?php echo $v0;?>" ></td>
			</tr>
		</table>
		<input type="submit" value="UPDATE" id="nsub">
	</center>
	</form>
</body>
</html>
<?php
}
if($field=="facility"){
	$title=$_POST['title'];
	$v1=$_POST['v1'];
	$v2=$_POST['v2'];
	$v3=$_POST['v3'];
	$v4=$_POST['v4'];
	$v5=$_POST['v5'];
	$message=$_POST['message'];
?>
<html>
<head><title>Facility</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>" method="post" enctype="multipart/form-data">
	<center>
		<table>
			<tr>
			<td id="ftd">Title </td>
				<td><textarea  id="title" name="title" required ><?php echo $title;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" name="image1" id="img" value="<?php echo $v1;?>"  ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" name="image2" id="img" value="<?php echo $v2;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" name="image4" id="img" value="<?php echo $v3;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image4</td>
				<td><input type="file" name="image5" id="img"   value="<?php echo $v4;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image5</td>
				<td><input type="file" name="image6" id="img"  value="<?php echo $v5;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"><?php echo $message;?></textarea></td>
			</tr>
			</table>
			<div>
		<input type="submit" value="UPDATE" id="nsub">
	</center>
	</form>
</body>
</html>
<?php
}
if($field=="advertisement"){
	$title=$_POST['title'];
	$message=$_POST['message'];
	$date=$_POST['date'];
	$v1=$_POST['v1'];
	$v2=$_POST['v2'];
	$v3=$_POST['v3'];
	$v4=$_POST['v4'];
?>
<html>
<head><title>Advertisement</title></head>
<body style="background-color: white;">
<form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>" method="post" enctype="multipart/form-data">
	<center>
		<table>
			<tr>
				<td id="ftd">Event Name:</td>
				<td><textarea  id="title" name="title" required><?php echo $title;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd" >Message</td>
				<td><textarea rows="7" cols="60" id="fmsg" name="message" required style="background-color: white;"><?php echo $message;?></textarea></td>
			</tr>
			<tr>
				<td id="ftd">Date </td>
				<td><input type="date" id="date" name="date" value="<?php echo $date;?>" required></td>
			</tr>
			<tr>
				<td id="ftd">Image1</td>
				<td><input type="file" name="image1" id="img"  value="<?php echo $v1;?>"  ></td>
			</tr>
			<tr>
				<td id="ftd">Image2</td>
				<td><input type="file" name="image2" id="img" value="<?php echo $v2;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Image3</td>
				<td><input type="file" name="image3" id="img" value="<?php echo $v3;?>" ></td>
			</tr>
			<tr>
				<td id="ftd">Registration_link </td>
				<td><textarea  id="title" name="reglink" required><?php echo $v4;?></textarea></td>
			</tr>
			</table>
			<div>
		<input type="submit" value="UPDATE" id="nsub">
	</center>
	</form>
</body>
</html>
<?php
}
?>