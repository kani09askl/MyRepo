<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.min.js"> </script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script>
</head>
<frameset rows="100,*,90" cols="0,"  frameborder="0" border="0" framespacing="0">
  <frame name="topNav" src="navbar.php">
<frameset cols="200,*" rows="" frameborder="0" border="0" framespacing="0">
	<frame name="menu" src="menu.php" marginheight="0" marginwidth="0" scrolling="auto" noresize>
	<frame name="content" src="content.php" marginheight="0" marginwidth="0" scrolling="auto" noresize>
</frameset>

  <frame name="footer" src="footer.php">

<noframes>
<p>This section (everything between the 'noframes' tags) will only be displayed if the users' browser doesn't support frames. You can provide a link to a non-frames version of the website here. Feel free to use HTML tags within this section.</p>
</noframes>

</frameset>



</html>










