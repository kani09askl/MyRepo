<?php
session_start();
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];
$_SESSION["dept_name"]=$dept_name_db;
$_SESSION["username"]=$username_db;
$_SESSION["dept_id"]=$dept_id_db;
if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
  $_SESSION["dept_name"]=$dept_name_db;
  $_SESSION["username"]=$username_db;
  $_SESSION["dept_id"]=$dept_id_db;
}
?>

<html>
<head>
<title>HTML Frames Example - Menu 2</title>
</style>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/menu.css">
<script type="text/javascript" src="js/jquery.js"> </script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script>
</head>
<body id="body" style="background-color:white;">
<center><h3 id="h3">DashBoard</h3></center>
<?php if($dept_id_db!=106 && $dept_id_db!=107 && $dept_id_db!=108 && $dept_id_db!=109 && $dept_id_db!=110){ ?>
<div class="dropdown" id="div">
    
   <div class="btn  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Facility
  </div>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
   <li> <a class="dropdown-item" href="option.php?field=lab" target="content">Lab</a></li>
    <li><a class="dropdown-item" href="option.php?field=rnd" target="content">R&D</a></li>
    <li><a class="dropdown-item" href="option.php?field=tieups" target="content">Tieups</a></li>
  </div>
  <?php 
  }else
  {?>
  <div id="div">
    <a href="option.php?field=facility" target="content">
   <button class="btn" type="button" id="btn1">Facility
  </button></a>
  </div>
  <?php

    }?>
</div>

<div id="div">
<a href="option.php?field=faculty" target="content"><div class=" btn " id="btn1">Faculty</div></a>
</div>

<div id="div">
<a href="option.php?field=dept_details" target="content"><div class=" btn " id="btn2">DepartmentDetails</div></a>
</div>


  <?php if($dept_id_db!=107 && $dept_id_db!=110){ ?>
<div class="dropdown" id="div">
    
   <div class="btn  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Activity
  </div>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
   <li> <a class="dropdown-item" href="option.php?field=news_events" target="content">News&Events </a></li>
    <li><a class="dropdown-item" href="option.php?field=advertisement" target="content">Advertisement</a></li>
	 <li><a class="dropdown-item" href="option.php?field=testimonials" target="content">Testimonials</a></li>
  </div>
  </div>
<div id="div">
<a href="option.php?field=achievements" target="content"><div class=" btn " id="btn4">Achivements</div></a>
</div>
<div id="div">
<a href="alumnitable.php?field=alumni_detail" target="content"><div class=" btn " id="btn2">Alumni Details</div></a>
</div>


 <?php }?>



</body>
</html>




