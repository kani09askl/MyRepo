<html>
<head>

  
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet"s href="css/content1.css">
<script type="text/javascript" src="js/jquery.min.js"> </script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script>

<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrapnew.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body >

           
  <div id="main" >

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators 
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <h1 id="h1">VISION</h1>

                   <p id="p1">Our ambition is to develop a centre for imparting technical education<br>
                    with creativity and performre search with practical values to meet challenges of <br>
                engineering environment and to achieve rural empowerment.</p>

      </div>

      <div class="item">
       <h1 id="h1">MISSION</h1>

                     <p id="p1">The institute aims to produce innovative professionals with sound subject knowledge,<br>
                     research experience and social character for a sustainable growth of the nation by<br>
                      providing adequate training to develop education with leadership qualities. </p>
      </div>
    
      <div class="item">
        <h1 id="h1">OBJECTIVE</h1>

                   <p id="p1">Quality policy of Sasurie College of Engineering is  Eminence in teaching through <br>
                      quality programs to make the young professionals self sustained and adaptable to<br>
                       the ever changing global impacts and need of the industry with social relevance"</p>
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

   
</body>
</html>
<style type="text/css">
    #p1{
  font-weight: 300;
    font-size: 18px;
    line-height: 26px;
    font-style: italic;
    margin-left:300px;
    color:white;

 }
 .row{
  margin-left:0%;
 }
#d1{
  margin-left: 15%;
}
#main{
  margin-top:5%;
}
.container{
  height:500%;
}
.carousel-inner{

  
  margin-top:10%;
  border-radius:5px;
}
#h1{
 margin-left:300px;
 color:white;
}

.item{
  padding-top:5%;
  border-radius:5px;
}
body{
  background-image:url(images/lawn.jpg);
  background-size:200% 200%;
  background-repeat: no-repeat;
  
}


</style>




