-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 20, 2019 at 10:08 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sasurie_engg`
--

-- --------------------------------------------------------

--
-- Table structure for table `sce_achievement`
--

CREATE TABLE IF NOT EXISTS `sce_achievement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `achieversname` varchar(60) NOT NULL,
  `title` varchar(70) NOT NULL,
  `gain` tinyint(4) DEFAULT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `image1` blob,
  `organization` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_sce_achievement` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `sce_achievement`
--

INSERT INTO `sce_achievement` (`id`, `dept_id`, `achieversname`, `title`, `gain`, `message`, `date`, `image1`, `organization`) VALUES
(1, 108, 'Rajesh Kumar.R', 'IVTL infoview', 1, 'Placed in IVTL infoview', '2019-01-17', 0x75706c6f6164732f3130385f72616a6573686b756d61722e6a7067, 'IVTL infoview'),
(2, 108, 'Tendulkar.P', 'IVTL Infoview', 1, 'Placed in IVTL Infoview', '2019-01-17', 0x75706c6f6164732f3130385f54656e64756c6b61722e6a7067, 'IVTL Infoview'),
(3, 108, 'Arun Kumar.A', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f6172756e6b756d61722e6a7067, 'Shinelogics'),
(4, 108, 'Dinesh Kumar.S', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f64696e657368206b756d6172532e6a7067, 'Shinelogics'),
(5, 108, 'Divya.G', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f44697679612e6a7067, 'Shinelogics'),
(6, 108, 'Ganeshan.G', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f67616e657368616e2e6a7067, 'Shinelogics'),
(7, 108, 'Indhumathi.K', 'Shinelogics', 1, 'placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f696e6468756d617468692e6a7067, 'Shinelogics'),
(8, 108, 'Kaviraj.S', 'Shinelogics', 1, 'placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f4b61766972616a2e6a7067, 'Shinelogics'),
(9, 108, 'Kavitha.S', 'Shinelogics', 1, 'placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f6b6176697468612e6a7067, 'Shinelogics'),
(10, 108, 'Kowsalya.S', 'Shinelogics', 1, 'Placed in Shinelogics ', '2019-01-17', 0x75706c6f6164732f3130385f6b6f7773616c79612e6a7067, 'Shinelogics'),
(11, 108, 'Mangayakarasi.M', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f4d616e67617961726b61726173692e6a7067, 'Shinelogics'),
(12, 108, 'Mohana Priya.S', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f6d6f68616e6170726979612e6a7067, 'Shinelogics'),
(13, 108, 'Mythili.P', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f6d797468696c692e6a7067, 'Shinelogics'),
(14, 108, 'Om Shakthi', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f4f6d5368616b7468692e6a7067, 'Shinelogics'),
(15, 108, 'Rajesh Kumar.R', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f72616a6573686b756d61722e6a7067, 'Shinelogics'),
(16, 108, 'Sharmila.M', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f736861726d696c612e6a7067, 'Shinelogics'),
(17, 108, 'Sivasankari.S', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f7369766173616e6b617261692e6a7067, 'Shinelogics'),
(18, 108, 'Suriya.S', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f537572696979612e6a7067, 'Shinelogics'),
(19, 108, 'Vignesh.V', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f5669676e6573682e6a7067, 'Shinelogics'),
(21, 108, 'Yasoda.S', 'Shinelogics', 1, 'Placed in Shinelogics', '2019-01-17', 0x75706c6f6164732f3130385f7961736f6468612e6a7067, 'Shinelogics'),
(22, 108, 'Revathi.R', 'Vivid Infotech', 1, 'Placed in Vivid Infotech', '2019-01-17', 0x75706c6f6164732f3130385f726576617468692e6a7067, 'Vivid Infotech'),
(23, 108, 'Balaabirami.B', 'Technosys', 1, 'Placed in Technosys', '2019-01-17', 0x75706c6f6164732f3130385f62616c6161626972616d692e6a7067, 'Technosys'),
(24, 108, 'Divya.G', 'Technosys', 1, 'Placed in Technosys', '2019-01-17', 0x75706c6f6164732f3130385f44697679612e6a7067, 'Technosys'),
(25, 108, 'Kamaleshwari.M', 'Technosys', 1, 'Placed in Technosys', '2019-01-17', 0x75706c6f6164732f3130385f6b616d616c657368776172692e6a7067, 'Technosys'),
(26, 108, 'Keerthana.M', 'Technosys', 1, 'placed in Technosys', '2019-01-17', 0x75706c6f6164732f3130385f6b6565727468616e612e4a5047, 'Technosys'),
(27, 108, 'Mythili.P', 'Technosys', 1, 'Placed in Technosys', '2019-01-17', 0x75706c6f6164732f3130385f6d797468696c692e6a7067, 'Technosys'),
(28, 108, 'Sivasankari.S', 'Technosys', 1, 'Placed in Technosys', '2019-01-17', 0x75706c6f6164732f3130385f7369766173616e6b617261692e6a7067, 'Technosys'),
(29, 108, 'Ganeshan.G', 'Uniq', 1, 'Placed in Uniq', '2019-01-17', 0x75706c6f6164732f3130385f67616e657368616e2e6a7067, 'Uniq'),
(30, 108, 'Kaviraj.S', 'uniq', 1, 'Placed in Uniq', '2019-01-17', 0x75706c6f6164732f3130385f4b61766972616a2e6a7067, 'Uniq'),
(31, 108, 'Krishnakumar.K', 'IBIRDS', 1, 'Placed in IBIRDS', '2019-01-17', 0x75706c6f6164732f3130385f6b726973686e616b756d61722e6a7067, 'IBIRDS'),
(32, 108, 'Murugalakshmi.M', 'IBIRDS', 1, 'Placed in IBIRDS', '2019-01-17', 0x75706c6f6164732f3130385f6d75727567616c616b73686d692e6a7067, 'IBIRDS'),
(33, 108, 'Ragubalagi.K', 'IBIRDS', 1, 'Placed in IBIRDS', '2019-01-17', 0x75706c6f6164732f3130385f7261677562616c6167692e6a7067, 'IBIRDS'),
(34, 106, 'M.Suthan', 'Erode District level Body Building Competition', 3, 'M.Suthan,IV Mech  got third place in Erode District level Body Building Competition.', '2014-08-15', 0x75706c6f6164732f3130365f362e4a5047, 'Anthiyur'),
(35, 106, 'Ms.E.Ramya Ms.K.Immaculate Kavipriya S.Vaishnavi', 'Zone-12\r\nInter college Badminton tournament for Women', 3, 'Ms.E.Ramya Ms.K.Immaculate Kavipriya and  S.Vaishnavi won third place Zone-12\r\nInter college Badminton tournament for Women', '2014-09-05', 0x75706c6f6164732f3130365f7061322e6a7067, 'KS RANGASAMY College of Technology,Thiruchengode'),
(36, 106, 'Mr. V.Muthu Pandi', 'State level JKK NATARAJA Trophy KABADDI Tournament for Men', 1, 'Mr. V.Muthu Pandi won Best APPANCE Player Award in State level JKK NATARAJA Trophy KABADDI Tournament for Men', '2014-09-25', 0x75706c6f6164732f3130365f322e6a7067, 'JKK NATARAJA College of Engineering,Komarapalayam'),
(37, 101, 'C.SHARVIKA', 'PAPER PRESENTATION', 1, 'C.SHARVIKA won first prize in paper presentation.', '2015-01-19', '', 'MUTHAYAMMAL ENGINEERING COLLEGE'),
(38, 101, 'JOSNA HOSEPH', 'PAPER PRESENTATION', 1, 'Josna Hoseph won first prize in PPT', '2015-01-19', '', 'MUTHAYAMMAL ENGINEERING COLLEGE'),
(39, 101, 'B.SENTHIL KUMAR', 'CODE DEBUGGING', 2, 'senthil kumar won second prize in code debugging', '2015-01-19', '', 'S.N.S COLLEGE OF ENGINEERING'),
(40, 101, 'G.RAMESH', 'CODE DEBUGGING', 2, 'Ramesh won second prize in code debugging', '2015-01-19', '', 'S.N.S COLLEGE OF ENGINEERING'),
(41, 101, 'R.RANJITH KUMAR', 'TECHNICAL QUIZ,BEST MANAGER', 2, 'Ranjith kumar won second prize quiz', '2015-01-19', '', 'KARPAGAM COLLEGE OF ENGINEERING'),
(42, 101, 'K.S.RAGAVENDIRAN', 'TECHNICAL QUIZ,BEST MANAGER', 2, 'K.S.Ragavendiran won  second prize in Quiz', '2015-01-19', '', 'KARPAGAM COLLEGE OF ENGINEERING'),
(43, 101, 'T.SYED MUBARAK', 'BEST MANAGER', 2, 'Syed Mubarak won second prize in best manager', '2015-01-19', '', 'ANGEL COLLEGE OF ENGINEERING'),
(44, 101, 'T.VIVEKANADHAN ', 'BEST MANAGER', 2, 'Vivekandhan won second prize in best manager', '2015-01-19', '', 'ANGEL COLLEGE OF ENGINEERING'),
(45, 101, 'B.SENTHIL KUMAR 	', 'PAPER PRESENTATION', 2, 'Kumar Senthil won  second prize PPT', '2013-01-19', '', 'M.P.N.M.J ENGINEERING COLLEGE'),
(46, 101, 'R.RANJITH KUMAR', 'PAPER PRESENTATION', 2, 'Ranjith kumar won second prize in PPT', '2013-01-19', '', 'M.P.N.M.J ENGINEERING COLLEGE'),
(47, 101, 'P.GOKUL KRISHNAN', 'PAPER PRESENTATION', 2, 'Gokul krishnan won second prize in PPT', '2013-01-18', '', 'TEJAA SAKTHI ENGINEERING COLLEGE'),
(48, 101, 'P.GOKUL KRISHNAN 	', 'TECHNICAL QUIZ', 2, 'Gokul krishna won second prize in Quiz', '2013-01-19', '', 'TEJAA SAKTHI ENGINEERING COLLEGE'),
(49, 101, 'P.GOKUL KRISHNAN', 'PAPER PRESENTATION', 1, 'Gokul krishnan won first in PPT', '2013-01-19', '', 'SRI KRISHNA ENGINEERING COLLEGE'),
(50, 101, 'P.GOKUL KRISHNAN', 'CODE DEBUGGING 	', 2, 'Gokul krishnan won second prize in code debugging', '2013-01-19', '', 'SRI KRISHNA ENGINEERING COLLEGE'),
(51, 102, 'C.SHARVIKA', 'PAPER PRESENTATION', 1, 'sharvika won first prize in  PPT', '2015-03-15', '', 'MUTHAYAMMAL ENGINEERING COLLEGE'),
(52, 102, 'JOSNA HOSEPH', 'PAPER PRESENTATION', 1, 'Josna Hoseph won first prize in PPT', '2015-03-15', '', 'MUTHAYAMMAL ENGINEERING COLLEGE'),
(53, 102, 'B.SENTHIL KUMAR', 'CODE DEBUGGING', 2, 'Senthil kumar won second prize in code debugging', '2015-03-15', '', 'S.N.S COLLEGE OF ENGINEERING'),
(54, 102, 'G.RAMESH', 'CODE DEBUGGING', 2, 'Ramesh won second prize in code bugging', '2015-03-15', '', 'S.N.S COLLEGE OF ENGINEERING'),
(55, 102, 'R.RANJITH KUMAR', 'TECHNICAL QUIZ,BEST MANAGER', 2, 'Ranjith kumar won second prize in Quiz', '2015-03-15', '', 'KARPAGAM COLLEGE OF ENGINEERING'),
(56, 105, 'C.SHARVIKA', 'PAPER PRESENTATION', 1, 'sharvika won first prize in PPT', '2015-04-01', '', 'MUTHAYAMMAL ENGINEERING COLLEGE'),
(57, 105, 'B.SENTHIL KUMAR', 'CODE DEBUGGING', 2, 'Senthil kumar won second prize in code debugging', '2015-04-01', '', 'S.N.S COLLEGE OF ENGINEERING'),
(58, 105, 'R.RANJITH KUMAR', 'TECHNICAL QUIZ,BEST MANAGER', 2, 'Ranjith kumar won second prize in quiz', '2015-04-01', '', 'KARPAGAM COLLEGE OF ENGINEERING'),
(59, 105, 'T.SYED MUBARAK', 'BEST MANAGER', 2, 'Syed Mubarak won second prize in best manager', '2015-04-01', '', 'ANGEL COLLEGE OF ENGINEERING'),
(60, 105, 'T.VIVEKANADHAN', 'Best manager', 2, 'vivekanadhan won second prize in best manager', '2015-04-01', '', 'ANGEL COLLEGE OF ENGINEERING'),
(61, 103, 'B.SENTHIL KUMAR', 'PAPER PRESENTATION', 2, 'Senthil Kumar won second place in PPT', '2015-01-20', '', 'M.P.N.M.J ENGINEERING COLLEGE'),
(62, 103, 'R.RANJITH KUMAR', 'PAPER PRESENTATION	', 2, 'Ranjith kumar won second place in PPT', '2015-01-20', '', 'M.P.N.M.J ENGINEERING COLLEGE'),
(63, 104, 'K.S.RAGAVENDIRAN	', 'TECHNICAL QUIZ', 2, 'Ragavendiran won second place in technical quiz', '2015-01-20', '', 'KARPAGAM COLLEGE OF ENGINEERING'),
(64, 104, 'R.RANJITH KUMAR', 'TECHNICAL QUIZ', 2, 'Ranjith Kumar won second place in Technical Quiz', '2015-01-20', '', 'KARPAGAM COLLEGE OF ENGINEERING');

-- --------------------------------------------------------

--
-- Table structure for table `sce_admin`
--

CREATE TABLE IF NOT EXISTS `sce_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k_deptid` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `sce_admin`
--

INSERT INTO `sce_admin` (`id`, `dept_id`, `username`, `password`) VALUES
(1, 101, 'aaa101@gmail.com', 'aaa101'),
(2, 101, 'bbb101@gmail.com', 'bbb101'),
(3, 102, 'arun102@gmail.com', 'arun102'),
(4, 102, 'kani102@gmail.com', 'kani102'),
(5, 103, 'rajesh103@gmail.com', 'rajesh103'),
(6, 103, 'priya103@gmail.com', 'priya103'),
(7, 104, 'gayu103@gmail.com', 'gayu104'),
(8, 104, 'dinesh104@gmail.com', 'dinesh104'),
(9, 105, 'ranju105@gmail.com', 'ranju105'),
(10, 105, 'pavi105@gmail.com', 'pavi105'),
(11, 106, 'mythili106@gmail.com', 'mythili106'),
(12, 107, 'sowrabi105@gmail.com', 'sowrabi105'),
(13, 108, 'aaa108@gmail.com', 'aaa108'),
(14, 109, 'ttt109@gmail.com', 'ttt109'),
(15, 110, 'kani110@gmail.com', 'kani110'),
(16, 111, 'ranju111@gmail.com', 'ranju111'),
(19, 111, 'pavi111@gmail.com', 'pavi111'),
(20, 112, 'arun112@gmail.com', 'arun112'),
(21, 113, 'rajesh113@gmail.com', 'rajesh113'),
(22, 114, 'niki114@gmail.com', 'niki114'),
(24, 116, 'priya116@gmail.com', 'priya116'),
(25, 115, 'kani115@gmail.com', 'kani115');

-- --------------------------------------------------------

--
-- Table structure for table `sce_advertisement`
--

CREATE TABLE IF NOT EXISTS `sce_advertisement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(70) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `image3` blob,
  `reglink` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_sce_advertisement` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `sce_advertisement`
--

INSERT INTO `sce_advertisement` (`id`, `dept_id`, `title`, `message`, `date`, `image1`, `image2`, `image3`, `reglink`) VALUES
(1, 101, 'Tezfuerza 18.2 Grand Gala Technical Symposium', 'We the department of Computer Science and Engineering is organizing a Grand Gala Technical Symposium TEZFUERZA v 18.2 partnered with VIVO a Smart phone brand on Febuary 16, 2018. ', '2018-02-09', 0x75706c6f6164732f3130315f726573697a655f313531393930323137342d62616e6e65722d313532303036373131322e6a7067, 0x75706c6f6164732f3130315f726573697a655f313531393930323137342d62616e6e65722d313532303036373131322e6a7067, 0x75706c6f6164732f3130315f726573697a655f313531393930323137342d62616e6e65722d313532303036373131322e6a7067, ''),
(3, 109, '13th Graduation day ', 'Sasurie College of Engineering, Vijayamangalam organized 13thgraduation day function for the new graduates on 8th September 2018. ', '2017-09-08', 0x75706c6f6164732f3130395f477261645f70686f746f2e706e67, '', '', ''),
(4, 109, 'SalesForce Trailhead  Learnathon of India.', 'It is informed that, the ICT Academy in collaboration with Sasurie College of Engineering is conducting Salesforce Trailhead for Students Championship-2018 The largest Learnathon of India, on 2nd and  3rd February 2018. ', '2018-07-02', 0x75706c6f6164732f3130395f494d472d32303138303230332d5741303032362d62616e6e65722d313531383039313432372e6a7067, '', '', ''),
(5, 109, '4th International Yoga Day  Inauguration', 'Sasurie College of Engineering celebrates 4th International Yoga Day \r\non 21.06.2018', '2018-06-23', 0x75706c6f6164732f3130395f796f67615f6461792e6a7067, 0x75706c6f6164732f3130395f796f67615f646179322e6a7067, '', ''),
(6, 109, 'Shahitya 18-A Poetic Festival of Joy', 'Shahitya 18-A poetic Festival of joy,A state level Inter coleege cultural fest.', '2018-09-12', 0x75706c6f6164732f3130395f73686168697479612e706e67, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sce_alumni_form`
--

CREATE TABLE IF NOT EXISTS `sce_alumni_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(40) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `batch` varchar(20) DEFAULT NULL,
  `occupation` varchar(30) DEFAULT NULL,
  `company_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_alumni_key_dept` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `sce_alumni_form`
--

INSERT INTO `sce_alumni_form` (`id`, `dept_id`, `name`, `email`, `contact`, `message`, `date`, `batch`, `occupation`, `company_name`) VALUES
(1, 101, 'Arun Kumar', 'arunkumar@sasurieinfo.tech', '7374752382', 'good', '2015-01-20', '2014-2018', 'Software Engineer', 'Shinelogics'),
(2, 102, 'priyanka', 'priyanka@gmail.com', '7234537762', 'good', '2015-01-20', '2014-2018', 'Software Engineer', 'Shinelogics'),
(3, 103, 'swathi', 'swathi@gmail.com', '7256352621', 'good', '2015-01-20', '2014-2018', 'tester', 'Shinelogics'),
(4, 104, 'prabhu', 'prabhu@gmail.com', '7266354125', 'good', '2015-01-20', '2014-2018', 'automobile engineer', 'TCS'),
(5, 105, 'Thyagu', 'Thyagu@gmail.com', '7265326342', 'good', '2015-01-20', '2014-2018', 'architect', 'TCS'),
(6, 112, 'Rajesh', 'Rajesh@gmail.com', '7265341264', 'good', '2015-01-20', '2014-2018', 'entrepreneur', 'New ideas'),
(7, 111, 'vignesh', 'vignesh@gmail.com', '7364526364', 'good', '2015-01-20', '2014-2018', 'Software Engineer', 'Shinelogics'),
(8, 113, 'sankar', 'sankar@gmail.com', '7363264222', 'good', '2015-01-20', '2014-2018', 'logic design ', 'HCL'),
(9, 114, 'madhan', 'madhan@gmail.com', '7365426323', 'good', '2015-01-20', '2014-2018', 'engineer', 'HCL'),
(10, 115, 'Radha', 'Radha@gmail.com', '7364554273', 'good', '2015-01-20', '2014-2018', 'Engineer', 'Tech Mahindra'),
(11, 116, 'Nishanth', 'Nishanth@gmail.com', '8732462351', 'good', '2015-01-20', '2014-2018', 'Software Engineer', 'TCS');

-- --------------------------------------------------------

--
-- Table structure for table `sce_course_offered`
--

CREATE TABLE IF NOT EXISTS `sce_course_offered` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `course_name` varchar(80) DEFAULT NULL,
  `course_started` int(11) DEFAULT NULL,
  `intake` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_sce_course_offered` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `sce_course_offered`
--

INSERT INTO `sce_course_offered` (`id`, `dept_id`, `course_name`, `course_started`, `intake`) VALUES
(1, 105, 'Civil engineering', 2011, 60),
(2, 101, 'Computer Science and Engineering', 2001, 120),
(3, 102, 'Electronics and Communication Engineering', 2001, 180),
(4, 103, 'Electrical and Electronics Engineering', 2002, 60),
(5, 104, 'Mechanical Engineering', 2004, 180),
(6, 116, 'M.Tech Information Technology', 2010, 18),
(7, 111, 'M.E Computer Science and Engineering', 2008, 30),
(8, 113, 'VLSI', 2008, 30),
(9, 112, 'MBA', 2006, 60),
(10, 115, 'Applied Electronics', 2011, 18),
(11, 114, 'Power Electronics and Device', 2010, 18);

-- --------------------------------------------------------

--
-- Table structure for table `sce_department`
--

CREATE TABLE IF NOT EXISTS `sce_department` (
  `dept_id` int(11) NOT NULL DEFAULT '0',
  `dept_name` varchar(40) NOT NULL,
  `dept_type` varchar(3) NOT NULL,
  `starting_year` int(20) DEFAULT NULL,
  `app_intake` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sce_department`
--

INSERT INTO `sce_department` (`dept_id`, `dept_name`, `dept_type`, `starting_year`, `app_intake`) VALUES
(101, 'CSE', 'UG', NULL, NULL),
(102, 'ECE', 'UG', NULL, NULL),
(103, 'EEE', 'UG', NULL, NULL),
(104, 'MECH', 'UG', NULL, NULL),
(105, 'CIVIL', 'UG', NULL, NULL),
(106, 'Sports Department', 'SD', NULL, NULL),
(107, 'Transport Department', 'TD', NULL, NULL),
(108, 'Placement Department', 'PD', NULL, NULL),
(109, 'Administration Department', 'AD', NULL, NULL),
(110, 'Library Department', 'LD', NULL, NULL),
(111, 'ME(CSE)', 'PG', NULL, NULL),
(112, 'MBA', 'PG', NULL, NULL),
(113, 'VLSI', 'PG', NULL, NULL),
(114, 'PED', 'PG', NULL, NULL),
(115, 'Applied Electronics', 'PG', NULL, NULL),
(116, 'M.Tech(IT)', 'PG', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sce_department_details`
--

CREATE TABLE IF NOT EXISTS `sce_department_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `dept_message` longtext,
  `dept_sub_message1` longtext,
  `dept_sub_message2` longtext,
  `dept_sub_message3` longtext,
  `dept_sub_message4` longtext,
  `dept_sub_message5` longtext,
  `dept_hod_name` varchar(60) NOT NULL,
  `dept_hod_address` longtext NOT NULL,
  `image1` blob,
  PRIMARY KEY (`id`),
  KEY `k_deptid` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sce_department_details`
--

INSERT INTO `sce_department_details` (`id`, `dept_id`, `dept_message`, `dept_sub_message1`, `dept_sub_message2`, `dept_sub_message3`, `dept_sub_message4`, `dept_sub_message5`, `dept_hod_name`, `dept_hod_address`, `image1`) VALUES
(1, 101, 'The CSE Department has outstanding faculty expertise supporting a wide range of research and instruction in traditional and emerging areas of computer science and engineering. The department continues to grow at a rapid pace in terms of academic activities, publications, and national and international service and recognition. Our rich academic environment directly contributes to the high quality of our undergraduate and graduate programs, supporting world-class education at all levels (B.E and M.E). The Department regularly organizes a series of lectures by academicians and professionals of the highest repute, which lay stress on the latest innovative technologies in the field of Computer Science and Engineering and Information Technology. The Department is partnered by IIT-Bombay for setting up laboratory and organizing workshop and seminar designed with world class curriculum. It provides the state-of-the-art research, instructional, and laboratory facilities.', ' Department imparts value education in the field of Computer Science and Engineering to confer deep insights of the rapid advancements in the changing domain.', 'To provide knowledge in the field of Computer Science and Engineering that will develop professional behavior and leadership abilities in the young minds, by promoting practical teaching and research oriented activities. To produce successful engineers with social and professional responsibilities for commitment to lifelong learning.', 'To prepare students with good ability to design and construct a hardware and software system components and to derive solutions for real life problems. To inculcate students with professional skills that prepares them for immediate employment and for life-long learning in advanced areas of computer science & related fields. To prepare students to get involved in post graduate programme in computer science and engineering and make them to work productively in computing industry. To develop an ability to analyze the requirements of the software, understand the technical specifications, design and provide engineering solutions and efficient product designs.', 'Ability to understand varying complexities in the design, analysis and construction of different software systems. Ability to analyze a problem, identify and define the computing requirements for the software. Ability to realize the techniques, interpersonal skills and modern engineering tools which are necessary for engineering practices. Ability to design new software by their own.', 'THA TECHNOCRATS OF THE SOCIETY', 'Mr.G.Revathy', 'Department of Computer Science and Engineering,Sasurie College of Engineering.', ''),
(2, 102, 'The department of Electronics and Communication Engineering was established during the inception of the institute in the year 2001 to produce competent engineers in the field of Electronics and Communication Engineering. At present, the intake is 180 students since 2013.The department offers undergraduate degree programme of B.E Electronics and Communication Engineering & and postgraduate degree programme of M.E Applied electronics & VLSI Design. The department has state-of-the-art laboratory facilities to infuse practical knowledge to the students on par with academic excellence. The department has excellent and consistent placement record and most of the students are placed in reputed organizations. The department actively involved in teaching and research in disparate subfields of Electronics, Telecommunication, Signal Processing and Embedded Systems.', ' \r\nTo endeavor the department as a centre of excellence in offering quality education, technically competent and research focus in catering with high pattern of discipline through our dedicated faculty members in order to meet the challenges of industries in the area of Electronics and Communication Engineering.', 'To educate the students with the state of art technologies to meet the growing challenges of the industry. To make research culture among the faculty members and students. To provide ethical and value based education by promoting activities addressing the societal needs.', 'Make the graduates to acquire strong in subject fundamentals which facilitate them to solve complex engineering problems for betterment of society. Make the graduates for active participation in co-curricular activities which enable them to get exposure in knowledge sharing, novel ideas and leadership skills. Make the graduates to exhibit professional and ethical outlook, effective communication, team work and multidisciplinary approach. Make the graduates to excel in higher studies and competitiveness in technical profession.', 'The graduates will be able to acquire knowledge in mathematics, Engineering Sciences and Fundamentals of Electronics and Communication Engineering. The graduates will be able to identify, formulate to design electronic circuits and interpret data. The graduates will be able to use modern electronic equipments and softwares to analyze Engineering problems. The graduates will be able to communicate effectively in both verbal and written form. The graduates will be able to understand the professional, ethical and social responsibilities. The graduates will be able to analyze the contemporary issues on electronics and provide the necessary solutions to the society.\r\n\r\n', 'WORLD OF CIRCUTS', 'Mr.Gladson.\r\n', 'Department of Electronic and Communication engineering.', ''),
(3, 103, 'The department of Electrical and Electronics Engineering is one of the vibrant departments of Sasurie College of Engineering, offers B.E. Electrical and Electronics Engineering and M.E. Power Electronics and drives. UG course was established in the year 2002 with an annual intake of 60 students and PG course was established in the year 2010 with an annual intake of 18+2. It has state of art laboratories for AC Machines lab, DC Machines lab, Engineering practices Lab, Control and instrumentation Lab, Power Electronics lab, Power Electronics and Drives lab, Power system simulation Lab. The department has highly qualified and experienced faculties with different Specialization. The department has organized several national level seminars, symposiums, Conferences and workshops for the benefit of the students, faculty members and researchers. The department offers value added courses apart from the regular subject which enable the students acquire marketable skills. The department library and central library has 4298 volume of books, 6 national journals, and 5 international Journals. The department has liberally been producing efficient engineers with outstanding academic and overall performance. The Electrical Engineering is one of the major department in the engineering profession and its principles are involved in design, study, development and construction of nearly all of the Electrical devices and Electronic devices. Continued research and development have led to better machines and processes helping the mankind. Electrical engineers are employed in an enormous range of technical areas including: Electrical Maintenance, Power Plants, Automatic Controls, Electrical Computer-Aided Design, Energy Management, Facilities maintenance, just to name a few. Electrical engineering is a challenging, rewarding, and highly respected profession. The Department regularly organizes a series of lectures by academicians and professionals of the highest repute, which lay stress on the latest innovative technologies in the field of Electrical Engineering.', ' To impart education to become highly competent professional in Electrical and Electronics Engineering with trained skills to meet contemporary and upcoming challenges to serve the society.', 'To create technical manpower for meeting the current and future demands of industry. To develop students with innovative skills and positive attitude through effective teaching learning process. Provide advanced engineering research for the graduates to equip with broad intellectual spectrum for diverse and competitive career paths.', 'To provide good knowledge in engineering fundamentals and energy auditing. Better competent with good communication skills and desire knowledge. Students to become outstanding professionals with ethics to solve the problems of society. To create a green and renewable energy environment.', 'Graduate will have the ability to apply knowledge of mathematics, science and engineering. Ability to design circuits, conduct field experiments and analyze data related to field of Electrical Engineering. Ability to design a system, component, or process to meet desired needs of society within realistic constraints such as Economy & Environment', 'COMMUNITY OF POWER', 'Mr.Johny', 'Electrical and Electronics Engineering', ''),
(4, 104, 'The Mechanical Engineering is one of the major activities in the engineering profession and its principles are involved in the design, study, development and construction of nearly all of the physical devices and systems. Continued research and development have led to better machines and processes helping the mankind. The many engineering disciplines, mechanical engineering are the broadest, encompassing a wide variety of engineering fields at many specialties. Although it is commonly assumed that mechanical engineers are automotive engineers, in fact, mechanical engineers are employed in an enormous range of technical areas including: acoustics, air conditioning, automatic controls, computer-aided design, energy management, fluid dynamics, tribology, robotics, biomechanics, and turbo machinery, just to name a few. Mechanical engineering is a challenging, rewarding, and highly respected profession.The Department regularly organizes a series of lectures by academicians and professionals of the highest repute, which lay stress on the latest innovative technologies in the field of Mechanical Engineering.', 'The program strives to be excellent in Education, training and innovation leading to well-qualified engineers and successful in the field of Mechanical Engineering', 'Graduates of the program will be prepared to:\r\nExpertise the students in designing and analyzing a range of systems based on sound principles considering functionality, aesthetics, safety, cost effectiveness and sustainability. Continuously improve and expand their technical and professional skills through formal as well as informal self-study. Advance themselves professionally and personally by accepting professional and societal responsibilities and pursuing leadership roles.', 'Expertise the students in designing and analyzing a range of systems based on sound principles considering functionality, aesthetics, safety, cost effectiveness and sustainability. Continuously improve and expand their technical and professional skills through formal as well as informal self-study. Advance themselves professionally and personally by accepting professional and societal responsibilities and pursuing leadership roles.', 'Graduates will be able to apply technical facts in design and product development. Graduated Professionals can proficient to Identify, formulate and solve engineering problems related to various materials and their properties using skills, techniques and Engineering tools. Young technocrats will have ability to apply principles, suitable process and modern engineering tools to design, analysis and manufacturing sound components which can be assembled into systems. Graduates will be operational in multi-disciplinary teams and able to communicate effectively. Young Minds will recognize the need of professional development, continued learning and self motivation. An understanding of professional and ethical responsibility.', 'Engine World', 'Mr.V.P.krishnamurthy', 'department of Mechanical engineering', ''),
(5, 105, 'TThe Civil Engineering is a four year full time course spread over eight semester and is started in the year 2011.The programme is duly approved by AICTE, New Delhi and affiliated to the Anna university Chennai. To enlighten and explore every mind technically, a National level technical symposium is being organized.', ' To create resposible civil engineers with technical competence and managerical skills for nation building.\r\n', 'To produce Civil Engineers of high caliber with ethical values to serve the society. To promote innovative and original thinking in the minds of budding Engineers to face future challenges.', 'Provide opportunities for students to communicate effectively in the current technology to the civil engineering community. To be successful practicing engineers in the areas of design,analysis and realization of design in one or more of the major areas of civil engineering.', 'Graduates will have ability to apply knowledge of mathematics, science and engineering. Graduates will complete a civil engineering design to meet desired needs within realistic constrains such as economic, social, political, ethical, health and safety and sustainability. Graduates will have the understanding of practical issues. Graduates will use the techniques, skills and modern engineering tools in civil engineering domain.\r\n\r\nCivil Engineering \r\nAbout the Department\r\nLabs Facilities\r\nClass Room Facilities\r\nFaculty Profile\r\nAssociation Activities\r\nLaurels Won by Students\r\nAlumini Students\r\nExtra Curricular Activities\r\nE-Course Material\r\nNPTEL VIDEO\r\n', 'Builders of Society', 'Ms.Pujitha', 'Department of Civil Engineering', ''),
(6, 112, 'The Department of Management Sciences (MBA) in Sasurie had been debuted in the year 2006. The MBA program in SACE is housed within one of the finest propose to build learning facilities of budding Entrepreneurs and the Administrators.\r\nThe SACE MBA itself offers a unique combination of cutting-edge, business-oriented skill development, rigorous of teaching of evidence-based Management research and the benefit of Tailor-Made Support.\r\nWe are passionate about increasing the employability of our students and look forward for meeting and working in the key employer to increase the opportunities for placement and projects.\r\nOur MBA department achieves maximum placement record in every year.\r\nWe also seek to be World-Class in embedding sustainable development within our teaching and culture.', 'To emerge as a center of academic excellence by developing future managers and entrepreneurs with sound professional knowledge and quality leadership.', 'To enable the students in improving their competencies to face today’s challenges in business environment.\r\nTo impart value-based education and training to enhance the knowledge of the students.\r\nTo develop the skills of budding managers as full-fledged professionals with creativity, innovation, self-confidence, courage and ethical standards. ', 'Describe current practices, issues and concerns in business administration.\r\nHands-on learning experiences combined with practical classroom instruction provide students with the essential business skills needed to effectively manage and lead organizations.\r\nStudents will analyze problems by applying generally accepted theory, best practices and leadership/management skills in the business environment.\r\nDevise appropriate strategies for their own ongoing professional development and implementation of these strategies upon successful completion of MBA', 'Graduates are able to synthesize the knowledge, skills and tools acquired in the program, which enable them to design a real micro business.\r\nGraduates are able to excel in their chosen career paths by learning on how to live, adapt and manage business environmental change.\r\nStudents graduating from the MBA program have the necessary attitudes and skills to become more productive employees.', 'THE CHANAKYAS OF BUSINESS\r\n', 'HOD of Master of Business Administration', 'HOD of Master of Business Administration', ''),
(7, 106, 'The college provides varied extracurricular activities in Sports for training the students in Physical Education & Gymnasium for both hostlers and dayscholars.\r\nThe college offers free admission for the students to practice sports and athletics in the non-working days.\r\nWe offer regular and standard coaching for the students through qualified Physical Director & qualified Physical Trainee team of faculties.', 'The college provides varied extracurricular activities in Sports for training the students in Physical Education & Gymnasium for both hostlers and dayscholars.\r\nThe college offers free admission for the students to practice sports and athletics in the non-working days.\r\nWe offer regular and standard coaching for the students through qualified Physical Director & qualified Physical Trainee team of faculties.', 'The college provides varied extracurricular activities in Sports for training the students in Physical Education & Gymnasium for both hostlers and dayscholars.\r\nThe college offers free admission for the students to practice sports and athletics in the non-working days.\r\nWe offer regular and standard coaching for the students through qualified Physical Director & qualified Physical Trainee team of faculties.', 'The college provides varied extracurricular activities in Sports for training the students in Physical Education & Gymnasium for both hostlers and dayscholars.\r\nThe college offers free admission for the students to practice sports and athletics in the non-working days.\r\nWe offer regular and standard coaching for the students through qualified Physical Director & qualified Physical Trainee team of faculties.', 'The college provides varied extracurricular activities in Sports for training the students in Physical Education & Gymnasium for both hostlers and dayscholars.\r\nThe college offers free admission for the students to practice sports and athletics in the non-working days.\r\nWe offer regular and standard coaching for the students through qualified Physical Director & qualified Physical Trainee team of faculties.', 'JUST PLAY', 'HOD of Sports Department', 'HOD of Sports Department', ''),
(11, 108, 'At Sasurie, we always believe in equipping our students with the right talent and personality to meet the industry requirements. Our focus on placement centers on creating new approaches to attract the best from the industry to our campus. At Sasurie, Placement time is not a mere annual ritual; it is a time for showcasing the very best in our young engineers to the industrial and corporate world. The Department Placement & Career Development (DPCD) functions with the primary objective of placing students in top-notch companies even before they have completed their courses. The DPCD goes all out to train the students to meet the high industry expectations. This department is run by a Placement Director and a full time permanent coordinator. The placement office ensures and takes care to provide the best arrangements and hospitality for the visiting company officials. The placement office, functions in a separate air conditioned block with all audio visual facilities for PPT, written test, group discussions and interviews and has rapidly progressed over the years in enhancing the placement potential effectively. It plays a vital role in counseling and guiding the students of the college for their successful career placement', 'Developing the students Technical knowledge and soft skills to meet the corporate recruitment process Grooming the students to acquire the best Interpersonal Skills, Self Presentation, Positive Attitude, Highest Aptitude, Career Planning and Goal Setting Aiming to place the maximum number of students through campus & off-campus in the top notch companies.', 'The highlights of the department are Industry Institutions Interaction Session Full time trainers for Soft Skill and Aptitude Soft skills training by the Experts from outside Workshops for Aptitude In-plant Training', 'The highlights of the department are Industry Institutions Interaction Session Full time trainers for Soft Skill and Aptitude Soft skills training by the Experts from outside Workshops for Aptitude In-plant Training', 'The highlights of the department are Industry Institutions Interaction Session Full time trainers for Soft Skill and Aptitude Soft skills training by the Experts from outside Workshops for Aptitude In-plant Training', 'THE AREA OF DREAMS', 'Mr.M.Thivyaprakash', 'HOD of Placement Department', 0x75706c6f6164732f3130385f726573697a655f313533363536303030322e6a7067),
(10, 108, 'At Sasurie, we always believe in equipping our students with the right talent and personality to meet the industry requirements. Our focus on placement centers on creating new approaches to attract the best from the industry to our campus. At Sasurie, Placement time is not a mere annual ritual; it is a time for showcasing the very best in our young engineers to the industrial and corporate world. The Department Placement & Career Development (DPCD) functions with the primary objective of placing students in top-notch companies even before they have completed their courses. The DPCD goes all out to train the students to meet the high industry expectations. This department is run by a Placement Director and a full time permanent coordinator. The placement office ensures and takes care to provide the best arrangements and hospitality for the visiting company officials. The placement office, functions in a separate air conditioned block with all audio visual facilities for PPT, written test, group discussions and interviews and has rapidly progressed over the years in enhancing the placement potential effectively. It plays a vital role in counseling and guiding the students of the college for their successful career placement', 'Developing the students Technical knowledge and soft skills to meet the corporate recruitment process Grooming the students to acquire the best Interpersonal Skills, Self Presentation, Positive Attitude, Highest Aptitude, Career Planning and Goal Setting Aiming to place the maximum number of students through campus & off-campus in the top notch companies.', 'The highlights of the department are Industry Institutions Interaction Session Full time trainers for Soft Skill and Aptitude Soft skills training by the Experts from outside Workshops for Aptitude In-plant Training', 'The highlights of the department are Industry Institutions Interaction Session Full time trainers for Soft Skill and Aptitude Soft skills training by the Experts from outside Workshops for Aptitude In-plant Training', 'The highlights of the department are Industry Institutions Interaction Session Full time trainers for Soft Skill and Aptitude Soft skills training by the Experts from outside Workshops for Aptitude In-plant Training', 'THE AREA OF DREAMS', 'Mr.M.Thivyaprakash', 'HOD of Placement Department', 0x75706c6f6164732f3130385f726573697a655f313533363536303030322e6a7067),
(12, 116, 'Applied Probability and Statistics\r\nAdvanced Data Structures and Algorithms\r\nMulticore Architectures\r\nInternetworking Technologies\r\nObject Oriented Software Engineering\r\nAdvanced Databases\r\nAdvanced Data Structures Laboratory\r\nInternetworking Laboratory\r\nMini Project\r\nWeb Technologies\r\nCloud Computing\r\nNetwork and Information Security\r\nData Warehousing and Data Mining\r\nElective I\r\nElective II\r\nWeb Technology Laboratory\r\nCloud Computing Laboratory\r\nTechnical Seminar\r\nSoft Computing\r\nElective III\r\nElective IV\r\nproject Work (Phase I)\r\nproject Work (Phase II)\r\n', '\r\n    Software Metrics and Reliability\r\n    Network Management\r\n    Bio Informatics\r\n    XML and Web Services\r\n    Enterprise Application Integration\r\n    Video Analytics\r\n    Software Project Management\r\n    Mobile and Pervasive Computing\r\n    Principles of Programming Languages\r\n    Multimedia Technologies\r\n    Automata Theory and Compiler Design\r\n    Big Data Analytics\r\n    Software Quality and Testing\r\n    Wireless Adhoc and Sensor Networks\r\n    Web Mining\r\n    Image Processing and Pattern Analysis\r\n    Intelligent Agents\r\n    Internet of Things\r\n    Web Engineering\r\n    Parallel Programming Paradigms\r\n    Social Network Analysis\r\n    Knowledge Engineering\r\n    Energy Aware Computing\r\n    4G Technologies\r\n    Performance Evaluation of Computer Systems\r\n \r\n', '    Web Engineering\r\n    Parallel Programming Paradigms\r\n    Social Network Analysis\r\n    Knowledge Engineering\r\n    Energy Aware Computing\r\n    4G Technologies\r\n    Performance Evaluation of Computer Systems', ' 1. Core competency\r\nTo apply their basic knowledge in Mathematics, Science and Engineering and to expose to the recent Information Technologies to analyze and solve real world problems.\r\n2.Innovation\r\nTo be competent in the IT segments and to bring out novel ideas by exploring the multiple solutions for the given problem.\r\n3.AdaptiveLearning\r\nTo engage in sustained learning for the career opportunities in industries, research divisions, and academics so that they can adapt to ever-changing technological and societal requirements.\r\n4.Team spirit\r\nTo mould the students to be ethically committed towards team work for producing quality output with the aim of developing our nation.\r\n', '1. An ability to apply knowledge of mathematics, science and information science in advance level\r\n\r\n2. An ability to design a Information system with components and processes to meet desired needs within realistic constraints such as economic, environmental, social, political, ethical, health and safety, manufacturability, and sustainability\r\n\r\n3. An ability to identify and modify the functions of the internals of information processing system\r\n\r\n4. An ability to apply Software Engineering principles, techniques and tools in software development\r\n\r\n5. An ability to create, collect, process, view, organize, store, mine and retrieve information both in local and remote locations in a secure and effective manner\r\n\r\n6. An ability to design and conduct experiments, as well as to analyze and interpret information to lay a foundation for solving complex problems\r\n\r\n7. An ability to engage in life-long learning to acquire knowledge of contemporary issues in IT domain to meet the challenges in the career\r\n\r\n8. An ability to apply the skills and techniques in information technology and interdisciplinary domains for providing solutions in a global, economic, environmental, and societal context\r\n\r\n9. An ability to develop IT research skills and innovative ideas\r\n\r\n10. An ability to model the IT real world problems and to address and share the research issues\r\n\r\n11. An ability to share their IT knowledge and express their ideas in any technical forum\r\n\r\n12. An ability to present their ideas to prepare for a position to educate and guide others.', 'MTech(IT)', 'HOD of MTech(IT)', 'HOD of MTech(IT)', ''),
(13, 111, 'Semester I\r\nTheory\r\nApplied Probability and Statistics\r\nDesign and Management of Computer Networks\r\nAdvanced Data Structures and Algorithms\r\nMulticore Architectures\r\nElective I\r\nElective II\r\nPractical\r\nAdvanced Data Structures Laboratory\r\nCase Study - Network Design (Team Work)\r\nSemester II\r\nTheory\r\nTheoretical Foundations of Computer Science\r\nAdvanced Databases\r\nPrinciples of Programming Languages\r\nAdvanced Operating Systems\r\nElective III\r\nElective IV\r\nPractical\r\nAdvanced Databases Laboratory\r\nCase Study - Operating Systems Design (Team Work)\r\nSemester III\r\nTheory\r\nSoftware Process and Project Management\r\nElective V\r\nElective VI\r\nElective VII\r\nPractical\r\nProject Work (Phase I)\r\nSemester IV\r\nPractical\r\nProject Work (Phase II)', 'Semester I\r\nTheory\r\nApplied Probability and Statistics\r\nDesign and Management of Computer Networks\r\nAdvanced Data Structures and Algorithms\r\nMulticore Architectures\r\nElective I\r\nElective II\r\nPractical\r\nAdvanced Data Structures Laboratory\r\nCase Study - Network Design (Team Work)\r\nSemester II\r\nTheory\r\nTheoretical Foundations of Computer Science\r\nAdvanced Databases\r\nPrinciples of Programming Languages\r\nAdvanced Operating Systems\r\nElective III\r\nElective IV\r\nPractical\r\nAdvanced Databases Laboratory\r\nCase Study - Operating Systems Design (Team Work)\r\nSemester III\r\nTheory\r\nSoftware Process and Project Management\r\nElective V\r\nElective VI\r\nElective VII\r\nPractical\r\nProject Work (Phase I)\r\nSemester IV\r\nPractical\r\nProject Work (Phase II)', 'Electives\r\nSemester I\r\nElective-I\r\nFormal Models of Software Systems\r\nPerformance Evaluation of Computer Systems\r\nProbabilistic Reasoning Systems\r\nData Analysis and Business Intelligence\r\nImage Processing and Analysis\r\nSensing Techniques and Sensors\r\nElective-II\r\nRandomized Algorithms\r\nMobile and Pervasive Computing\r\nParallel Programming Paradigms\r\nSoftware Requirements Engineering\r\nSpeech Processing and Synthesis\r\nMachine Learning Techniques\r\nSemester II\r\nElective-III\r\nConcurrency Models\r\nReal Time Systems\r\nComputer Vision\r\nNetwork and Information Security\r\nDesign and Analysis of Parallel Algorithms\r\nSoftware Architectures\r\nElective-IV\r\nModel Checking and Program Verification\r\nEmbedded Software Development\r\nCloud Computing\r\nData Visualization Techniques\r\nProtocols and Architecture for Wireless Sensor Networks\r\nLanguage Technologies\r\nSemester III\r\nElective-V\r\nSocial Network Analysis\r\nManaging Big Data\r\nMobile Application Development\r\nBio-inspired Computing\r\nMedical Image Processing\r\nSoftware Design\r\nElective-VI\r\nReconfigurable Computing\r\nEnergy Aware Computing\r\nInformation Retrieval Techniques\r\nData Mining Techniques\r\nBio Informatics\r\nSoftware Quality Assurance\r\nElective-VII\r\nMultiobjective Optimization Techniques\r\nEnterprise Application Integration\r\nInformation Storage Management\r\nRobotics\r\nCompiler Optimization Techniques', 'Graduates of this M. E. Computer Science and Engineering will be able to\r\n\r\n1. Apply the necessary mathematical tools and fundamental & advanced knowledge of computer science & engineering\r\n\r\n2. Develop computer/software/network systems understanding the importance of social\r\n\r\nbusiness, technical, environmental, and human context in which the systems would work\r\n\r\n3. Articulate fundamental concepts, design underpinnings of computer/software/network systems, and research findings to train professionals or to educate engineering students\r\n\r\n4. Contribute effectively as a team member/leader, using common tools and environment, in computer science and engineering projects, research, or education\r\n\r\n5. Pursue life-long learning and research in selected fields of computer science & engineering and contribute to the growth of those fields and society at large', 'Apply knowledge of mathematics, science, engineering fundamentals and an engineering specializationto the conceptualization of engineering models.\r\n\r\n1.Identify, formulate, research literature and solve complexengineering problems reaching substantiated conclusions using first principles of mathematics andengineering sciences.\r\n\r\n2.Design solutions for complexengineering problems and designsystems, components or processes thatmeet specifiedneeds withappropriate consideration for public health and safety,cultural, societal, and environmental considerations.\r\n\r\n3.Conduct investigations of complex problems including design of experiments, analysis and interpretation ofdata, and synthesis ofinformationto provide validconclusions.\r\n\r\n4.Create, select and apply appropriate techniques,resources, and modernengineeringtools, includingprediction and modeling, to complexengineering activities, withan understanding of the limitations.\r\n\r\n5.Function effectively asan individual, and asa member or leaderin diverseteams and in multi-disciplinary settings.\r\n\r\n6.Communicate effectively on complexengineering activities with the engineering community and with societyat large,suchas beingable tocomprehend and write effectivereportsand design documentation, makeeffective presentations, and giveand receive clear instructions.\r\n\r\n7.Demonstrate understanding ofthe societal,health, safety,legal and cultural issues and the consequent responsibilities relevant toengineering practice.', 'M.E Computer Science', 'HOD of M.E Computer Science', 'HOD of M.E Computer Science', ''),
(14, 113, 'Semester I\r\nApplied Mathematics for Electronics Engineers\r\nVLSI Signal Processing\r\nVLSI Design Techniques\r\nSolid State Device Modeling and Simulation\r\nElective I\r\nElective II\r\nVLSI Design Laboratory I', 'Semester I\r\nApplied Mathematics for Electronics Engineers\r\nVLSI Signal Processing\r\nVLSI Design Techniques\r\nSolid State Device Modeling and Simulation\r\nElective I\r\nElective II\r\nVLSI Design Laboratory I', 'Semester II\r\nAnalysis and Design of Analog Integrated Circuits\r\nCAD for VLSI Circuits\r\nLow Power VLSI Design\r\nElective III\r\nElective IV\r\nElective V\r\nAnalysis and Design of Analog Integrated Circuits\r\n', 'Semester III\r\nTesting of VLSI Circuits\r\nElective VI\r\nElective VII\r\nProject Work (Phase I)', 'Semester IV\r\nProject Work (Phase II)', 'M.E VLSI', 'HOD of M.E VLSI', 'HOD of M.E VLSI', ''),
(15, 114, 'I Semester\r\nTheory\r\nApplied Mathematics for Electrical Engineers.\r\nAnalysis of Electrical Machines.\r\nAnalysis of Power Converters\r\nAnalysis and Design of Inverters\r\nAdvanced Power Semiconductor Devices\r\nElective I\r\nSystem Theory\r\nMicrocontroller Based System Design\r\nElectromagnetic Field Computation and Modelling', 'II Semester\r\nTheory\r\nSolid State DC Drives\r\nSolid State AC Drives\r\nSpecial Electrical Machines\r\nPower Quality\r\nElective II & III\r\nSoft Computing Techniques\r\nDigital Simulation of Power Electronic Circuits\r\nVLSI Architecture and Design Methodologies\r\nFlexible AC Transmission Systems\r\nEnergy Management and Auditing\r\nSMPS and UPS\r\nPractical\r\nPower Electronics and Drives Laboratory.', 'III Semester\r\nPractical\r\nElectromagnetic Interference and Electromagnetic Compatibility\r\nWind Energy Conversion Systems\r\nHigh Voltage Direct Current Transmission\r\nPower Electronics for Renewable Energy Systems\r\nSystem Identification and Adaptive control\r\nProgramming with VHDL\r\nAdvanced digital signal processing\r\nApplications of MEMS Technology\r\nModern Rectifiers and resonant Converters\r\nSoft Computing Techniques\r\nPractical\r\nProject – ( Phase I )\r\nIV Semester\r\nPractical\r\nProject – ( Phase II )', 'III Semester\r\nPractical\r\nElectromagnetic Interference and Electromagnetic Compatibility\r\nWind Energy Conversion Systems\r\nHigh Voltage Direct Current Transmission\r\nPower Electronics for Renewable Energy Systems\r\nSystem Identification and Adaptive control\r\nProgramming with VHDL\r\nAdvanced digital signal processing\r\nApplications of MEMS Technology\r\nModern Rectifiers and resonant Converters\r\nSoft Computing Techniques\r\nPractical\r\nProject – ( Phase I )\r\nIV Semester\r\nPractical\r\nProject – ( Phase II )', 'III Semester\r\nPractical\r\nElectromagnetic Interference and Electromagnetic Compatibility\r\nWind Energy Conversion Systems\r\nHigh Voltage Direct Current Transmission\r\nPower Electronics for Renewable Energy Systems\r\nSystem Identification and Adaptive control\r\nProgramming with VHDL\r\nAdvanced digital signal processing\r\nApplications of MEMS Technology\r\nModern Rectifiers and resonant Converters\r\nSoft Computing Techniques\r\nPractical\r\nProject – ( Phase I )\r\nIV Semester\r\nPractical\r\nProject – ( Phase II )', 'M.E PED', 'HOD of M.E PED', 'HOD of M.E PED', ''),
(16, 115, 'Semester I\r\nApplied Mathematics for Electronics Engineers.\r\nAdvanced Digital Signal Processing.\r\nAdvanced Digital Logic System Design\r\nAdvanced Microprocessor and Microcontroller\r\nElective I\r\nElective II\r\nElectronics System Design Laboratory I', 'Semester I\r\nApplied Mathematics for Electronics Engineers.\r\nAdvanced Digital Signal Processing.\r\nAdvanced Digital Logic System Design\r\nAdvanced Microprocessor and Microcontroller\r\nElective I\r\nElective II\r\nElectronics System Design Laboratory I', 'Semester II\r\nAnalysis and Design of Analog Integrated Circuits\r\nASIC and FPGA Design\r\nEmbedded Systems\r\nMulticore Architectures\r\nElective III\r\nElective IV\r\nElectronics System Design Laboratory II', 'Semester III\r\nElectromagnetic Interference and Compatibility\r\nElective V\r\nElective VI\r\nProject Work (Phase I)\r\nSemester IV\r\nProject Work (Phase II)', 'Semester III\r\nElectromagnetic Interference and Compatibility\r\nElective V\r\nElective VI\r\nProject Work (Phase I)\r\nSemester IV\r\nProject Work (Phase II)', 'M.E Applied Electronics', 'HOD of M.E Applied Electronics', 'HOD of M.E Applied Electronics', '');

-- --------------------------------------------------------

--
-- Table structure for table `sce_facilities`
--

CREATE TABLE IF NOT EXISTS `sce_facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(30) NOT NULL,
  `image1` blob,
  `image2` blob,
  `image4` blob,
  `image5` blob,
  `image6` blob,
  `message` longtext,
  PRIMARY KEY (`id`),
  KEY `k_sce_facilities` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sce_facilities`
--

INSERT INTO `sce_facilities` (`id`, `dept_id`, `title`, `image1`, `image2`, `image4`, `image5`, `image6`, `message`) VALUES
(1, 109, 'Alumini page image', '', '', '', '', '', 'Alumini page image');

-- --------------------------------------------------------

--
-- Table structure for table `sce_faculty_details`
--

CREATE TABLE IF NOT EXISTS `sce_faculty_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `degree` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k_faculty_dept` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `sce_faculty_details`
--

INSERT INTO `sce_faculty_details` (`id`, `dept_id`, `name`, `degree`, `designation`) VALUES
(1, 106, 'Dr.P.Murugan', 'M.Phil.,Ph.D.,', 'Asst.Physical Director'),
(2, 106, 'Mr.P. Rajesh Giridhavan', 'B.P.Ed, M.P.Ed', 'Asst.Physical Director'),
(3, 106, 'Mr.C.MuthuKrishnan 	', 'B.A.,B.P.Ed', 'Asst.Physical Director');

-- --------------------------------------------------------

--
-- Table structure for table `sce_lab`
--

CREATE TABLE IF NOT EXISTS `sce_lab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `message` longtext NOT NULL,
  `image1` blob,
  `image2` blob,
  `image3` blob,
  `image4` blob,
  `title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_sce_lab` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `sce_lab`
--

INSERT INTO `sce_lab` (`id`, `dept_id`, `message`, `image1`, `image2`, `image3`, `image4`, `title`) VALUES
(1, 103, 'This is Electronics Laboratory								', 0x75706c6f6164732f3130335f65656c312e6a7067, 0x75706c6f6164732f3130335f65656c322e6a7067, 0x75706c6f6164732f3130335f65656c332e6a7067, 0x75706c6f6164732f3130335f65656c342e6a7067, 'Electronics Laboratory	'),
(2, 103, 'This is Linear and Digital Integrated Circuits Laboratory', 0x75706c6f6164732f3130335f65656c312e6a7067, '', '', '', 'Linear and Digital Integrated Circuits Laboratory'),
(3, 103, 'This is Object Oriented Programming Laboratory		', 0x75706c6f6164732f3130335f65656c322e6a7067, '', '', '', 'Object Oriented Programming Laboratory'),
(4, 101, 'This is Programming and Data Structure laboratory-I		', 0x75706c6f6164732f3130315f636c322e6a7067, 0x75706c6f6164732f3130315f636c312e6a7067, 0x75706c6f6164732f3130315f636c332e6a7067, 0x75706c6f6164732f3130315f636c342e6a7067, 'Programming and Data Structure Laboratory-I'),
(5, 101, 'This is Database Management Laboratory', 0x75706c6f6164732f3130315f636c342e6a7067, 0x75706c6f6164732f3130315f636c332e6a7067, '', '', 'Database Management Laboratory'),
(54, 101, 'This is Internet Programming laboratory			', '', '', '', '', 'Internet Programming Laboratory'),
(7, 101, 'This is Operating System Lab', '', '', '', '', 'Operating System Laboratory'),
(8, 101, 'This is Mobile Application Development Laboratory				', '', '', '', '', 'Mobile Application Development Laboratory'),
(9, 101, 'This is Compiler Laboratory				', '', '', '', '', 'Compiler Laboratory'),
(10, 101, 'This is Communication and Soft Skills Laboratory			', '', '', '', '', 'Communication and Soft Skills Laboratory'),
(11, 101, 'This is Microprocessor and Microcontroller                                               Laboratory				', '', '', '', '', 'Microprocessor and Microcontroller Laboratory'),
(12, 102, 'This is Analog and Digital Circuits Laboratory', 0x75706c6f6164732f3130325f656c312e6a7067, 0x75706c6f6164732f3130325f656c332e6a7067, 0x75706c6f6164732f3130325f656c322e6a7067, 0x75706c6f6164732f3130325f656c342e6a7067, 'Analog and Digital Circuits Laboratory'),
(13, 102, 'This is Circuit and Simulation Integrated Laboratory', 0x75706c6f6164732f3130325f656c312e6a7067, '', '', '', 'Circuit and Simulation Integrated Laboratory'),
(14, 102, 'This is Microprcessor and Microcontroller Laboratory', 0x75706c6f6164732f3130325f656c332e6a7067, '', '', '', 'Microprcessor and Microcontroller Laboratory'),
(15, 102, 'This is Digital Signal Processing Laboratory', 0x75706c6f6164732f3130325f656c322e6a7067, '', '', '', 'Digital Signal Processing Laboratory'),
(16, 102, 'This is Communication System Laboratory', '', '', '', '', 'Communication System Laboratory'),
(17, 105, 'This is Computer Aided Drafting and Modelling Laboratory', 0x75706c6f6164732f3130355f63656c312e6a7067, 0x75706c6f6164732f3130355f436976696c2d456e67696e656572696e672d436f75727365732e6a7067, '', '', 'Computer Aided Drafting and Modelling Laboratory'),
(18, 105, 'This is Computer Aided Building Drawing', '', '', '', '', 'Computer Aided Building Drawing'),
(19, 105, 'This is Soil Mechanics Laboratory', '', '', '', '', 'Soil Mechanics Laboratory'),
(20, 105, 'This is Strength of Materials Laboratory', '', '', '', '', 'Strength of Materials Laboratory'),
(21, 105, 'This is Environmental Engineering Laboratory', '', '', '', '', 'Environmental Engineering Laboratory'),
(22, 104, 'This is Manufacturing Technology Laboratory-1', 0x75706c6f6164732f3130345f6d6c352e6a7067, 0x75706c6f6164732f3130345f6d6c342e6a7067, 0x75706c6f6164732f3130345f6d6c332e6a7067, 0x75706c6f6164732f3130345f6d6c322e6a7067, 'Manufacturing Technology Laboratory-1'),
(23, 104, 'This is Fluid Mechanics and Mechinery Laboratory', 0x75706c6f6164732f3130345f6d6c312e6a7067, '', '', '', 'Fluid Mechanics and Mechinery Laboratory'),
(24, 104, 'This is Electrical Engineering Laboratory', 0x75706c6f6164732f3130345f6d6c322e6a7067, '', '', '', 'Electrical Engineering Laboratory'),
(25, 104, 'This is Manufacturing Technology Laboratory-II', 0x75706c6f6164732f3130345f6d6c332e6a7067, '', '', '', 'Manufacturing Technology Laboratory-II'),
(26, 104, 'This is Thermal Engineering Laboratory', '', '', '', '', 'Thermal Engineering Laboratory'),
(27, 104, 'This is Strength of Materials Laboratory', '', '', '', '', 'Strength of Materials Laboratory'),
(28, 104, 'This is Dynamics Laboratory', '', '', '', '', 'Dynamics Laboratory'),
(29, 104, 'This is Thermal Engineering Laboratory-II', '', '', '', '', 'Thermal Engineering Laboratory-II'),
(30, 104, 'This is Metrology and Measurements Laboratory', '', '', '', '', 'Metrology and Measurements Laboratory'),
(31, 104, 'This is C.A.D/C.A.M Laboratory', '', '', '', '', 'C.A.D/C.A.M Laboratory'),
(32, 104, 'This is Design and Fabrication Laboratory', '', '', '', '', 'Design and Fabrication Laboratory'),
(33, 104, 'This is Communication and Soft Skills Laboratory', '', '', '', '', 'Communication and Soft Skills Laboratory'),
(34, 103, 'This is Electrical Machines Laboratory-I', 0x75706c6f6164732f3130335f65656c332e6a7067, '', '', '', 'Electrical Machines Laboratory-I'),
(35, 103, 'This is Control and Instrumentation Laboratory', 0x75706c6f6164732f3130335f65656c342e6a7067, '', '', '', 'Control and Instrumentation Laboratory'),
(36, 103, 'This is Communication and Soft Skills Laboratory', '', '', '', '', 'Communication and Soft Skills Laboratory'),
(37, 103, 'This is Electrical Machines Laboratory-II', '', '', '', '', 'Electrical Machines Laboratory-II'),
(38, 103, 'This is Power Electronics and Drives Laboratory', '', '', '', '', 'Power Electronics and Drives Laboratory'),
(39, 103, 'This is Microprocessor and Microcontroller Laboratory', '', '', '', '', 'Microprocessor and Microcontroller Laboratory'),
(40, 103, 'This is Presentation Skills  and Technical Seminar', '', '', '', '', 'Presentation Skills  and Technical Seminar'),
(41, 101, 'This is Programming and Data Structures Laboratory-II', '', '', '', '', 'Programming and Data Structures Laboratory-II'),
(42, 101, 'This is Networks Laboratory', '', '', '', '', 'Networks Laboratory'),
(43, 101, 'This is Computer Graphics Laboratory', '', '', '', '', 'Computer Graphics Laboratory'),
(44, 101, 'This is Security Laboratory', '', '', '', '', 'Security Laboratory'),
(45, 101, 'This is Grid and Cloud Computing Laboratory', '', '', '', '', 'Grid and Cloud Computing Laboratory'),
(46, 102, 'This is OOPS and Data Structures Laboratory', '', '', '', '', 'OOPS and Data Structures Laboratory'),
(47, 102, 'This is Linear Integrated Circuit Laboratory', '', '', '', '', 'Linear Integrated Circuit Laboratory'),
(48, 102, 'This is Electrical Engineering and Control System Laboratory', '', '', '', '', 'Electrical Engineering and Control System Laborato'),
(49, 102, 'This is Computer Networks Laboratory', '', '', '', '', 'Computer Networks Laboratory'),
(50, 102, 'This is VLSI Design Laboratory', '', '', '', '', 'VLSI Design Laboratory'),
(51, 102, 'This is Communication and Soft Skills Laboratory', '', '', '', '', 'Communication and Soft Skills Laboratory'),
(52, 102, 'This is Embedded Laboratory', '', '', '', '', 'Embedded Laboratory'),
(53, 102, 'This is Optical and Microwave Laboratory', '', '', '', '', 'Optical and Microwave Laboratory');

-- --------------------------------------------------------

--
-- Table structure for table `sce_newsandevents`
--

CREATE TABLE IF NOT EXISTS `sce_newsandevents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(70) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `image3` blob,
  `image4` blob,
  `image5` blob,
  `image6` blob,
  `image7` blob,
  `image8` blob,
  `image9` blob,
  `image0` blob,
  PRIMARY KEY (`id`),
  KEY `k_sce_newsandevents` (`dept_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `sce_newsandevents`
--

INSERT INTO `sce_newsandevents` (`id`, `dept_id`, `title`, `message`, `date`, `image1`, `image2`, `image3`, `image4`, `image5`, `image6`, `image7`, `image8`, `image9`, `image0`) VALUES
(1, 101, 'Oracle Academy -Java Fundamentals and Programming', 'Java Fundamentals and Programming in association with Oracle Academy\r\nIt’s informed that the department of Computer Science and Engineering going to organize a training program on Java Fundamentals and Programming in association with Oracle Academy. On successful completion of the course, Oracle Academy issue the certificates based on the online test results.\r\n\r\nggfuefff\r\nwewgwegg\r\newwgwgg\r\nwegwgwg\r\nweggg', '2016-08-22', 0x75706c6f6164732f3130315f726573697a655f313437313836393331382e706e67, '', '', '', '', '', '', '', '', ''),
(5, 101, 'Guest Lecture - Internet of Things - 23.08.2016', 'The Department of Computer Science and Engineering is conducting Internet of Things (IoT) Guest Lecture on 23.08.2016 (Tuesday) at 10.00 AM in Abinantham Hall, Sasurie College of Engineering.', '2016-08-22', 0x75706c6f6164732f3130315f315f7458387545695f733948785f4d475f447139417348772e706e67, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(4, 101, 'Guest Lecture - PHP and Phython Programming', 'The Department of Computer Science and Engineering is conducting PHP and Phython Programming Guest Lecture on 22.08.2016 (Monday) at 10.00 AM in Abinantham Hall, Sasurie College of Engineering.', '2016-08-22', 0x75706c6f6164732f3130315f5048502d56732d507974686f6e2e706e67, '', '', '', '', '', '', '', '', ''),
(6, 101, 'One Day Seminar on Web Technology', 'Department of Computer Science and Engineering\r\nCordially Invites you for \r\nOne day Seminar \r\non \r\nWeb Technology\r\nResource Person: Mr. P. Gokul Krishnan, System Analyst, Vernalis Systems, Chennai\r\n\r\n', '2016-09-01', 0x75706c6f6164732f3130315f726573697a655f313437323732363432392e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(7, 101, 'Engineers’ Day Celebration, Centre for Excellence & Inauguration of Io', 'The Department of Computer Science and Engineering is organizing “Engineers’ Day Celebration, Centre for Excellence & Inauguration of IoT Laboratory, Cloud Computing Laboratory and Oracle Academy workspace” on 15.09.2016 Friday 10.00 AM at Sasurie College of Engineering.', '2016-09-12', 0x75706c6f6164732f3130315f726573697a655f313437333638363938322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(8, 101, 'Tezfuerza V 18.2 - Grand Gala Technical Symposium - Computer Science a', 'Greetings from Sasurie College of Engineering\r\n\r\nWe the department of Computer Science and Engineering is organizing a Grand Gala Technical Symposium "TEZFUERZA v 18.2" partnered with VIVO a Smart phone brand on Febuary 16, 2018. The day will be filled with Techno-fun events, games, conclave, etc. We also partnered with corporate companies like Shinelogics, 3vays Technologies, Pencil Budha, myanatomy, retail insights, Zorog, Daze corp, Random Researc, Bluez Infomatics, Bankbuzz.in. ', '2018-09-02', 0x75706c6f6164732f3130315f726573697a655f313531383136363031312e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(9, 101, 'nauguration of Tactician - 2017 -  Association of CSE Department', 'Tactician - 2017\r\nAssociation of CSE Department\r\n\r\nWe the department of Computer Science and Engineering Inaugurated our students’ Association “TACTCIANS - 2017”. The TACTICIANS Association invited our beloved Chairman, Management Trustee, Principal, HDs of all the departments and Placement Director.\r\n\r\nThe Event begin with prayer song (Tamil Thai Vazthu) followed by lighting the kuthuvizakku. Welcome address given by Mr. P.N. Renjith (Assistant HD of CSE Department). Motto of the Association and Introduction of Office bearers by Mr. Srikanth J (Associate Professor of CSE Department). Ms. S. Sivasankari (President of TACTICIANS Association - 2017 read the pledge and repeated by other office bearers). Our beloved Principal has given special address with loads of input about Networking. He delivered the origin and meaning of the word ‘TACTICIAN’. Participants feel celebrated when he addressed the importance of International certifications and scope of IT jobs. Subsequently the session owed to the resource person of the day, Shri. Srinivas Pasupulati, Founder and CEO, Trecis Consultancy, delivered an effective lecture on Java programming and insights of IT sectors and job.', '2018-07-21', 0x75706c6f6164732f3130315f6373655f6173736f5f696e617567312e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(10, 101, 'International Seminar on BlockChain Technology', 'The Department of Computer Science & Engineering organized one-day international seminar on BlockChain Technology on 23rd July 2018.\r\nThe Resource persons are\r\nMr.Vijaykumar, Founder & CEO, Cryptonaiers, USA\r\nMr. Senthil K Chinnasamy, CEO, Shinelogics InfoTech, Chennai', '2018-07-25', 0x75706c6f6164732f3130315f626c6f636b636861696e5f73656d696e6172322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(11, 101, 'National Seminar on Bigdata Programming & Analytics', 'The Department of CSE organized a national seminar on Bigdata Programming & Analytics on 6th August 2018. ', '2018-08-15', 0x75706c6f6164732f3130315f726573697a655f313533343335363333352e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(12, 102, 'Sasurie Leadership Forum Skill Masters - 2 days workshop on PCB Design', 'The Management, Principal, Faculty and team of skill masters cordially invite you for workshop on PCB design\r\nResource Person:\r\nMr. V. ChandraSekaran\r\nManaging Director, Idea Zone\r\nPresided over By:\r\nHonorable Chairman Shri. A.M. Kandhaswami\r\nChairman, Sasurie Groups of Institutions.\r\nFelicitation by:\r\nShrimathi. K. Savitha Mohanraj\r\nCEO, Sasurie group of Institutions\r\nDr. R. Radhakrishnan\r\nPrincipal, Sasurie College of Engineering', '2016-08-27', 0x75706c6f6164732f3130325f726573697a655f313437323236343734352e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(22, 102, 'Master of Cellphone services and training .', 'ECE and  EEE Association cordially invites you to the two day workshop on master of Cellphone services', '2016-09-03', 0x75706c6f6164732f3130325f726573697a655f313437323837333532322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(23, 103, 'Master of Cellphone services and training .', 'ECE and EEE association cordially invites you to the two day workshop on master of /cellphone services and training', '2016-09-03', 0x75706c6f6164732f3130335f726573697a655f313437323837333532322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(14, 109, 'LET’S SAVE THE FOOD ', 'SAVE FOOD FOR LIFE\r\nAccording to the UN report, published in the media, every year, nearly one-third of all foodstuffs intended for human consumption (around 1.3 billion tons), is thrown out. Almost 30% of agricultural land in the world is vain, and food in the form of waste produced more greenhouse gases than any country except China and the United States. UN experts have warned that food waste pose a danger to the planet’s climate and are advised to encourage users in developed countries to buy only the products and be practical in using left-over food.Reducing food waste will not only help avoid contamination and decreasing natural resources, but also reduces the need to increase food production to meet the demand of the growing population in the future.\r\nThe good news: there’s something we can do. The better news: it’s easy. And we’ve already got everything we need.\r\nPlease join us in save food mission by NSS, YRC and RRC club.', '2016-08-27', 0x75706c6f6164732f3130395f726573697a655f313437323236353231382e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(15, 106, 'Gobi Marathon 2017', 'Sasurie Group of Institutions Cordially invites you for the \r\nGobi Marathon 2017', '2016-12-10', 0x75706c6f6164732f3130365f726573697a655f313438313334373530342e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(16, 104, 'One Day workshop on Intellectual Property Right & Innovations', 'Department of Mechanical Engineering\r\n\r\nCordially invite you for the \r\n\r\nOne day Workshop on\r\n\r\nIntellectual Property Right and Innovations\r\non 25 November 2016\r\n\r\nat Mahidara Hall\r\n\r\nResource Person:\r\nDr. M. Kantha Babu\r\n\r\nDirector, Centre for Intellectual Right,\r\n\r\nCollege of Engineering, Guindy,\r\n\r\nAnna University Chennai,\r\n\r\nPresidential Address:\r\n\r\nShri. A.M. Kandaswami,\r\n\r\nChairman, Sasurie Group of Institutions\r\nSpecial Address:\r\nShrimathi. Savitha Mohanraj\r\nCEO, Sasurie Group of Institutions\r\nFelicitation:\r\nDr. R. Radhakrishnan\r\nPrincipal, Sasurie College of Engineering', '2016-11-24', 0x75706c6f6164732f3130345f726573697a655f313437393938303837392e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(17, 105, 'Hands on Training on Fire Safety - Civil Engineering Department', 'The Civil Engineering Department is organizing Hands on Training on Fire Safety at Aunugraha Hall, 23rd August 2016.\r\nTopic: Hands on Training on Fire Safety\r\nResource Persons :\r\n       Mr. V. Vishnuvarthan ,Chief Executive Officer, V-safe Industries, Dubai\r\n     Mr. Sairam. V,General Safety Officer, ELL Composites- Dubai\r\n     Mr. Krishnaraj,Senior-General Safety Officer, Qatar Electricity - Qutar', '2016-08-22', '', 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(18, 102, 'Faculty Training Program  - “Teaching Learning Process”', 'Department of Electronics & Communication Engineering\r\ncordially invite you for the Faculty Training Program on\r\n“Teaching Learning Process”\r\nChief Guest:\r\nProf Dr.R.Raghavan\r\n Advisor-Academics\r\nPreside Over by:\r\nShri. A.M. Kandaswami\r\nFelicitate by:\r\nShrimathi. Savitha Mohanraj\r\n\r\n', '2016-11-02', 0x75706c6f6164732f3130325f726573697a655f313437383038353134382e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(19, 112, 'MBA Department - Association Inaugural Function - ESTILO 2016', 'Department of Mangement Science and the Management, Principal, Faculty and Students\r\n\r\ncordially invites you to the Association Inagural Function\r\n\r\nESTILO - 2016\r\nChief Guest:\r\nShri. D. Baskar Raj\r\n\r\nManaging Partner, SRS Lungies, Erode\r\n\r\n\r\n\r\nPreside Over by:\r\nShri. A. M . Kandaswami\r\n\r\nChairman, Sasurie Group of Institutions\r\n\r\n\r\n\r\nFelicitation by:\r\nShrimathi. K. Savitha Mohanraj\r\n\r\nCEO, Sasurie Group of Institutions\r\n\r\n\r\n\r\nDr. R. Radhakrishnan,\r\n\r\nPrincipal, Sasurie College of Engineering\r\n\r\n\r\n\r\nMr. Arun Kumar, \r\n\r\nHD, MBA Department, Sasurie College of Engineering\r\n\r\n', '2016-08-27', '', 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(20, 112, 'Guest Lecture on Recent Trends in Capital Market', 'Department of Business Administration\r\n\r\nCordially invites you for the \r\n\r\nGuest Lecture on \r\n\r\n"Recent Trends in Capital Market"\r\n\r\n\r\n\r\nKeynote Address:\r\nMr. R. Senthil Murugan\r\n\r\nDepty Manager,\r\n\r\nBusiness Development,\r\n\r\nNational Stock Exchange (NSE)\r\n\r\nChennai\r\n\r\n\r\n\r\nPresidential Address:\r\nShri. A. M. Kandaswami,\r\n\r\nChairman, Sasurie Group of Institutions\r\n\r\n\r\n\r\nSpecial Address:\r\nShrimathi. K. Savitha Mohanraj,\r\n\r\nCEO, Sasurie Group of Institutions\r\n\r\n\r\n\r\nFelication:\r\nDr. R. Radhakrishnan,\r\n\r\nPrincipal, Sasurie College of Engineering\r\n\r\n', '2016-10-19', 0x75706c6f6164732f3131325f726573697a655f313437363837323538382e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(21, 109, 'Anna University Practical Examinations ', 'Anna University Practical Examination for 2nd, 3rd and 4th year will commence from 24.10.2016 Monday. Detailed timetable is displayed on respective Department Notice Board. ', '2016-10-19', 0x75706c6f6164732f3130395f726573697a655f313437363837323132332e706e67, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(24, 109, 'Ponnonam - 2016 ', 'On behalf of all Kerala Students we cordially invite\r\n\r\nyou for the celebration of\r\n\r\nPonnonam - 2016', '2016-09-08', 0x75706c6f6164732f3130395f726573697a655f313437333331373638372e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(25, 103, 'advanced embedded system ', 'Tesla students association cordially invites you  for the invited talk on advanced embedded system', '2016-09-14', '', '', '', '', '', '', '', '', '', ''),
(26, 109, 'Invited Talk - Financial Literacy ', 'It is informed that, Mr. Muruganandham, Counselor from Financial Literacy Club, Erode will be delivering a invited Talk on 17.09.2016 (Saturday), 10.30 AM at Samarparna Hall. All the intrested final year students are instructed to register their name with Mr. V. P. Krishnamurrty,AP of Mech .', '2016-09-15', '', '', '', '', '', '', '', '', '', ''),
(27, 109, 'Panel Discussion on “DATA MINING and BIG DATA  A Research Perspective', 'About the Panel Discussion:\r\n\r\nThis panel explores different opportunities in Data mining and Big data. The issues may include Big data analytics and Data mining in network mining, network\r\nsecurity and business development opportunities. The discussion includes a review of state-of-theart frameworks and platforms for processing and managing big data as well as the efforts expected on big data mining. We hope our effort will help reshape the subject area of today’s data mining technology toward solving tomorrow’s bigger challenges emerging in accordance with big data.\r\n\r\nHow to Big Data is becoming the new Final Frontier for scientific data research and for business applications?\r\nWhat are the salient issues around the intersection of big data engineering and data science?\r\nWhat case studies exist as examples of success or failure in analytics?\r\nWhat commonalities and differences exist between the software engineer and the data scientist?\r\nWe analyze the challenging issues in the datadriven model and also in the Big Data revolution.\r\nHow to manage the multiple security policy in data mining?\r\nHow to increase the performance in social networking services?\r\nDifferent techniques and Algorithms used to achieve better reliability, scalability and performance for processing big data.\r\nWhat are the various challenges and new security threats in Big Data?\r\nWhat are the treats and complexity of various Query processing techniques?\r\n\r\nPANEL MEMBERS\r\n\r\nCHAIR 1: \r\nDr. Priti Srinivas Sajja\r\nProfessor at Post Graduate, Department of Computer Science,\r\nSardar Patel University. Gujarat.\r\n\r\nShe is specialized in Artificial Intelligence especially in knowledge-based systems, soft computing and multi-agent systems. \r\nShe is co-author of Intelligent Techniques for data science (2016), Intelligent Technologies for web applications (2012) and Knowledge-Based systems (2009) published at Switzerland and USA.\r\nShe has 168 publications in books, book chapters and journals.\r\nShe was Principal investigator of a major research project funded by UGC, India. \r\nCHAIR 2: \r\n\r\nShri. D. Rajamanickam\r\nGlobal Chief Technology Officer.\r\n\r\nWorked with clients like AT&T, Verizon, Bell Atlantic, GTE, EBay, Motorola, Ericson, Nokia, Samsung, Alcatel, NEC, Lucent, ST Microelectronics, Huawei, Samsung, Affinity, Arbitron, ESPN, Comcast, Bell Canada, MTS Allstream, Comcast, Charter Communication etc. \r\nAn Expert in Domains like Mobile, VAS, Content Data Platform Development for Mobile, Telecom, OSS/BSS, CRM, Datacom, Embedded Systems, Retail, Healthcare, Media And Entertainment, GISRaster and Vector, BFSI.\r\nMeta data app, Customer Manager, CRM, ERP, Inventory management tools for Telecom domain. \r\nRe-engineering of world’s largest web portal Ebay from v2.0 to v3.0. 40 million lines of code in C++ to J2EE.\r\nIndia’s first regional language IDE, ascii printing using Indian language fonts, contribution to the Microsoft Indian language using Unicode.\r\nDeveloped a Data warehousing suite for Affinity using Enhydra Octobus – an open source ETL tool.\r\nCHAIR 3: \r\nDr. S. Palanivel\r\nProfessor, CSE Department,\r\nAnnamalai University.\r\n\r\nQualification-B.E (Honours)., M.E., Ph.D (IIT Madras).He is specialized in Speech, Image and video processing.\r\nHe has 22 years teaching experience and 14 years Research Experience.\r\nHe has 91 publications in National and International.\r\nHe was guided in many Research Scholar and Funded projects.\r\n', '2016-09-22', 0x75706c6f6164732f3130395f726573697a655f313437343534373837342e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(28, 109, 'Workshop - Financial Education ', 'Department of Management Sciences \r\n\r\nCordially invite you for the \r\n\r\nWorkshop on Financial Education \r\n\r\nin Association with\r\n\r\nSecurities Exchange Board of India Chennai\r\n\r\n', '2016-09-23', 0x75706c6f6164732f3130395f726573697a655f313437353634333230372e6a7067, '', '', '', '', '', '', '', '', ''),
(29, 109, 'World Space Week 2016 - ISRO & Sasurie Group of Institutions', 'Sasurie College of Engineering\r\nAnd\r\nSatish Dhawan Space Centre, SHAR, ISRO\r\nJointly Organizing\r\n\r\nWorld Space Week 2016\r\n\r\nCelebrations during\r\n\r\n4th – 10th October 2016\r\n\r\nEvents\r\n\r\nPreliminary Rounds of:\r\n\r\nQuiz\r\nElocution\r\nDrawing / Painting\r\nScience Experiments\r\n', '2016-10-05', 0x75706c6f6164732f3130395f726573697a655f313437353634333230372e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(30, 103, 'FDP on Sponsored Research Projects ', 'Sasurie College of Engineering\r\n\r\nand\r\nDepartment of Electrical & Electronics Engineering\r\n\r\nWe cordially invites you to the\r\nFaculty Development Program \r\non\r\n\r\n“Sponsored Research Projects”\r\n11.30 a.m, 16 December 2016, at Mahidhara Hall\r\n\r\nDr.N.Vijayan\r\nSenior Scientist\r\nNational Physical Laboratory, New Delhi\r\nhas kindly consented to be the Chief Guest\r\nand deliver keynote address', '2016-12-15', 0x75706c6f6164732f3130335f726573697a655f313438313830363430302e706e67, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(31, 109, 'Sasurie Institutions conducted Clean Tiruppur initiative as a part of ', 'Clean Tiruppur \r\nSwatchh Bharath Mission\r\nOrganized by \r\nSasurie Institutions\r\nSasurie Institutions conducted Clean Tiruppur initiative as a part of Swatchh Bharath Mission on 24/12/2016 at Nanjappa Municipal Higher Secondary School Ground, Tiruppur. Around 800 Students and 200 Faculty members participated in this event. Shri C P Radhakrishnanan, Chairman, Coir Board, inaugurated the “Clean Tiruppur” drive and motivated the students to practice the cleaning the environment right from schooldays. He also quoted that Father of Our Nation Mahathma Gandhiji and Kasthuribaj Gandhi had a habit of cleaning the toilets which they were using. Exlan Ramasamy and Amstrong E Palanisamy felicitated the students. Sasurie group of institutions Chairman Shri A M Kandasamy presided over the function. Earlier Dr R Radhakrishnan, Principal, Sasurie College of Engineering welcomed the gathering. Later the students had taken the pledge to keep Tiruppur Clean. All the VIPs participated in the cleaning drive at Nanjappa Municipal Higher Secondary School.', '2016-12-25', 0x75706c6f6164732f3130395f726573697a655f313438323638343036372e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(32, 102, 'FAER Scholar Awards Program ', 'PROJECT GRANDS - FAER Scholar Awards Program: 2016-2017 The Sasurie College of Engineering wishes to congratulate Ms. N Hemala (IV ECE), Ms.T Sathiya Priya (IV ECE), Ms.V Thamilarasi (IV ECE), Ms. L.Gayathri (IV ECE) and the project guide Prof. M. Devanathan, ECE Department,  who have been awarded  FAER Scholar Awards Program : 2016-2017,  to develop projects Wireless security system featured with UWB sensor and Android application. Congratulations to the successful teams and thank you to all proposers', '2017-01-21', 0x75706c6f6164732f3130325f726573697a655f313438353031373439302e6a7067, '', '', '', '', '', '', '', '', ''),
(33, 105, 'Civil Engineering students won Overall Championship in National Level ', 'Congratulations to Civil Engineering students who won the following events and “Overall Championship “  in National Level Technical Symposium organised by Venkateshwara\r\n\r\nHi-Tech Engineering College, Othakudirai, Gobi.\r\n\r\n', '2017-03-13', 0x75706c6f6164732f3130355f726573697a655f313438393337393638342e6a7067, '', '', '', '', '', '', '', '', ''),
(34, 101, 'Technical discussion with the MD and CEO of Helyxon Healthcare Solutio', 'With the eminent presence of CEO, Principal, Head of Departments, faculty members and students of CSE and ECE Department, has shared a brainstorming session with Mr.Vijai Shankar Raja, MD and CEO of Helyxon Healthcare Solutions pvt.ltd, about the entrepreneurial opportunities for budding engineers. The gathering was exposed to untraversed opportunities in the field of Internet of Things(IoT).', '2017-03-02', 0x75706c6f6164732f3130315f726573697a655f313438383436313034342e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(35, 102, 'Technical discussion with the MD and CEO of Helyxon Healthcare Solutio', 'With the eminent presence of CEO, Principal, Head of Departments, faculty members and students of CSE and ECE Department, has shared a brainstorming session with Mr.Vijai Shankar Raja, MD and CEO of Helyxon Healthcare Solutions pvt.ltd, about the entrepreneurial opportunities for budding engineers. The gathering was exposed to untraversed opportunities in the field of Internet of Things(IoT).', '2017-03-02', 0x75706c6f6164732f3130325f726573697a655f313438383436313034342e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(36, 109, 'Honorable C.E.O Shrimathi. Savitha Mohanraj receiving award at bridge ', 'Our esteemed C.E.O. Shrimathi. Savitha Mohanraj honoured during BRIDGE 2017 - best practice on skill development award. The objective of this 25th edition of BRIDGE is to create cognizance about the various new initiatives of the Government and to prepare the people for the journey of transforming India. This conference will develop a platform to share best practices and innovative ways in creating a new journey towards transforming India.\r\n\r\nMany aspects of Indian society appear transformed by this new prosperity with a new class of young, urban Indians challenging the stereotypes of life in their country. As the world and India need a skilled workforce, ICT Academy is working towards in making India the skill capital of the world and thereby paving a path for the journey of Transforming India.\r\n\r\nThe 25th Edition of BRIDGE is a 2 day conference hosting India Leadership Summit 2017 on the first day and India Convergence 2017 on the second day. This conference will be a milestone in creating a vision of hope in turning India’s vision into reality. Join us at this historic event, demonstrate your confidence in transforming India through your presence and engagement.', '2017-05-03', 0x75706c6f6164732f3130395f726573697a655f313438383637373339302e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(37, 109, 'Sasurie Honoring Academic Rewards Program (SHARP)', 'The Management, Principal, Staff and Students of\r\nSasurie College of Engineering cordially invites you to the\r\nSasurie Honoring Academic Rewards Programs (SHARP)', '2017-03-10', 0x75706c6f6164732f3130395f726573697a655f313438393133383739352e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(38, 109, 'Sasurie Women’s Day celebration ', 'Sasurie Institutions celebrated International Women’s day on 8th March 2017 at Abinandham Hall, Sasurie College of Engineering. With the esteemed presence of Ms. Sangeeta Singh, DGM, Essar Groups, Ms. Uma Maheswari, Sr. Manager- Purchase & Travel, Prodapt Solutions Pvt. ltd., Ms. Asmitha Aggarwal, Entrepreneur, Tiruppur and our CEO Smt. Savitha Moganraj inaugurated Sasurie Girls Forum. This forum focus on Women Empowerment, Entrepreneurial opportunities for Women and Women Safety. The day filled with technical & fun events.', '2017-03-09', 0x75706c6f6164732f3130395f726573697a655f313438393035373638362e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(39, 105, 'Achievements of our civil department students', 'Congratulations to third year Civil Engineering students for their following achievements in National level Symposium.\r\n(1) United Institute of technology, First prize in Poster presentation and Second prize in paper presentation by K. Viji and M. Devendran\r\n(2) Nehru Institute of technology, Second prize in Brick bonding and poster presentation\r\n(3) Excel Engineering College, First prize in Technical Quiz and Second prize in Paper Presentation by M. Gnanamani, B. Ramya. First prize in Word Cracking by R. Karthick, S. Karpagaselvan, Third prize in Poster Presentation by K. Viji, M. Devendran and overall championship', '2017-03-25', 0x75706c6f6164732f3130355f726573697a655f313439303433343137382e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(40, 101, 'Technical discussion ', 'Technical discussion with Mr.Arunkumar ,CTO,3vays technologies pvt ltd ,coimbatore.50 budding software engineers from second and third year of cse department intracted with the entrepreneur about effective utialization of enterprise framework and role play by the architecture and industries  current requirement', '2017-03-31', 0x75706c6f6164732f3130315f726573697a655f313439303933303735322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(41, 101, 'Technical discussion', 'On 2nd April 2017, a technical discussion was organised with Mr Jeyabalaji, CEO, MD and CEO, Neemshade info services private limited, coimbatore and Sasurie Info Tech. Mr.Jeyabalaji agreed to provide Summer internship to our students. 55 budding software engineers attended the technical discussion.', '2017-04-03', 0x75706c6f6164732f3130315f726573697a655f313439313231383834302e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(42, 109, 'Center of Excellence - Helyxon Healthcare Solutions Private Limited - ', 'Happiness is when an institution joins a hand with an industry in congruence to become a Centre of Excellence(CoE). Yes! Sasurie Institution is happy to have a productive association with Helyxon Healthcare Solutions private limited, Chennai. \r\n\r\nHelyxon is an IoT-based healthcare company located at IIT Madras Research Park, Taramani, Chennai. Helyxon is a product based company, known for a product called “98.6 Fever Watch- A continuous compact fever monitoring system”. This centre of excellence brings in a good mix of research and academics...\r\n\r\nSasurians will definitely be the benefactors of this association and will experience a tinge of the IITan flavour too', '2017-04-06', 0x75706c6f6164732f3130395f726573697a655f313439313438383037392e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(43, 109, 'Sasurie talent Examination', 'Life of success emerges out from healthy and sound competitions. Competition is the only way for the students to shake lethargy; it is only a way of life to get introduced for manly worthiness. Standard height of healthy education the competition is the tonic for the promising and talented future.Sasurie Talent Exam (STE) was conducted in our campus on 9th April 2017. The young blossoms from various schools had attended the exam and the total number of students who appeared for the exam was 150. The performance of the students in this examination was outstanding. Later our principal Dr.R.Radhakrishnan and our adviser Mr. Vijayan Rajkumar explained the benefits of attending talent exam and about MERIT scholarship worth&nbsp;INR 2 Crores. Later they were addressed by our students who got placed in top companies particularly Susmitha Palanisamy (Final year ECE Student who got placed in IVTL with the package of 5.5 lakhs per annum) motivated them and also gave the awareness about the placements. Next to that HODs from various departments had explained their benefits and opportunities behind their department. Next to that we proudly took them to our stalls where we showcased our projects that we have developed so far. This event was a platform where we also self-motivated and the young blossoms were also get motivated to develop many projects. We thank all the young blossoms who visited on that day', '2017-04-19', 0x75706c6f6164732f3130395f726573697a655f313439323539333138322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(44, 109, 'Britinity 2017 - IoT Workshop', 'Britinity 2017 - IoT Workshop - Transforming your mind towards technology  is an Event to Provide Awareness about IoT Not only Students even Staffs and New Admission +2 Students can also Participate in this event .Open Departments (Any Departments can Participates ).Certificates will be provided for all Participants.Their is No Registration Fee only criteria is they should have any one of this Gadgets like Smartphones/Tab/Laptops\r\n\r\n', '2017-05-11', 0x75706c6f6164732f3130395f726573697a655f313439343437313031362e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(45, 109, '16 th Annual day and Sports day celebration', 'The Annual and Sports fest was held in the college premises in a befitting manner on 8th April 2017. The event was diligently organised and there was a soul to it. A soul that was vibrant, contagious and exuberant. At the entrance of the building of the College, there was a huge poster denoting the Annual and Sports fest. It was planned for about a week to make the day specialised. Presided over by the Principal of the college, the function was attended by the Mr Muralidharan Palanisamy CTO, Payoda Technologies, Coimbatore and Ms.Neoline john District Sports and Youth Welfare Officer, Tiruppur was present as the special guests. Distinguished guests, elite guardians, and the students of the college also attended the inaugural function. The function started at 4.00 pm with the devotional song. The evening was made more colourful by inaugurating the 16th Annual and Sports day followed by principal annual report in which he gave a detailed account of the activities, achievements and the work done by us. Then came to our supporter CEO Smt.Savitha Moganraj, she encouraged us to achieve more and also created a grit in us. The chief guests also delivered the valuable speech. Then the honouring ceremony began with presenting the mementoes to the chief guests. Then came the time of prize distribution for the Annual day. The chief guest gave away the prizes. Prizes were given for best student achievers, 100% attendance, best faculty, the centre of excellence, best department and so on. Then came the prize distribution for sports day. All the winners were presented with the trophies and the rest of people encouraged them with the high applause. In the end, our principal congratulated the prize winners and wished them all success in life. Lastly, he praised the CEO Smt.Savitha Moganraj for her admirable administration. In this way, the function came to an end. We all felt that the function was a grand success. We had enjoyed the day and now returned home happily', '2017-04-12', 0x75706c6f6164732f3130395f726573697a655f313439313938393131342e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(46, 101, 'Technical Discussion', 'About the Event:\r\n\r\nWe the Department of Computer Science and Engineering arranged an invited talk of Mr.Shyam Velumani, Global Director of Sales & Marketing, Venpep Solutions through our beloved principal Dr.R.Radhakrishnan sir. Mr.Shyam is a student of our principal. The target audience of the event is Sasurie Geeks Forum members. \r\n\r\nThe Event begins with a short introduction about Mr.Shyam by Mr. Srikanth J (Associate Professor of CSE Department). Mr.Shyam completed his undergrad at Sri Ramakrishna Engineering College, 2002-2006 Batch of B.Tech. and Masters with Hult International Business School and Harvard University. Mr.Shyam serves for various IT companies viz. IBM, Syntel, Procter  and Gamble, VigCampaign and VenPEP Solutions.  \r\n\r\nMr. Shyam took the floor and addressed his personal experience with various industries and the present facet of IT Industry. Subsequently, he handled Q&A session. Ms.Mythili P of Final CSE concluded the event with a vote of thanks. \r\n\r\nMr.Shyam visits Sasurie InfoTech(SIT)- A Software Development Cell passionately run by the CSE students of Sasurie College of Engineering and shares about skillset required these days in Industry. ', '2017-07-11', 0x75706c6f6164732f3130315f726573697a655f313439393735303534392e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(47, 106, 'Sasurie Cricket Academy', 'Sasurie Institutions in its endeavor to promote and develop quality cricket among the students of our institutions has set up Cricket Academy with the following objectives:\r\n\r\nTo develop, endorse and promote excellence in young cricketers\r\nTo uphold the spirit of cricket through tough competition and fair play\r\nTo provide an additional path for identifying talented cricketers\r\nInterested students can enroll their name by filling the application form in the link below and submit the same to the concerned department HODs on or before 6 September 2017', '2017-09-01', 0x75706c6f6164732f3130365f726573697a655f313530343233343232382e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(48, 103, 'INAGURATION OF TESLA', 'The association function of the department of Electrical and Electronics Engineering named TESLA has been inaugurated successfully at Sasurie college of Engineering, Vijayamangalam on 26th July 2017. The chief guest for this grand occasion was Mr. S.Sundara Rajan who is designated as the General Manager of Sree Rangaraj ISPAT Industries PVT Ltd. The honorable Chairman Shri. A.M. Kandaswami and the respected CEO of the institution Mrs.Saveetha Moganraj presided over the gathering. The function was a grand success under the moral support of the Principal Dr. R.Radha Krishnan and the HOD Mr. K.Paul Joshua. The welcome address was given by the HOD Mr. K.Paul Joshua.  Chief Guest motivated by delivering his industrial experience, current scenario of industry expatiation and Role play of Electrical Engineers for our society.', '2017-09-01', 0x75706c6f6164732f3130335f726573697a655f313530343233343930322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(49, 102, 'Research center for pursuing Ph.D / M.S. by Research Anna University,C', 'Department of Electronics and Communication Engineering of Sasurie College of Engineering is recognized as research center for pursuing Ph.D / M.S. by research, Anna University, Chennai.\r\n\r\nBoard Members\r\n\r\nDr. R. Radhakrishnan, Principal, \r\nSasurie College of Engineering\r\n\r\nDr. P. Pandiyarajan, Head of the Department  and Dean (Research), \r\nElectronics and Communication Engineering, Sasurie College of Engineering.\r\n\r\nMr. Devanathan, Associate Professor,\r\nElectronics and Communication Engineering, Sasurie College of Engineering', '2017-10-09', 0x75706c6f6164732f3130325f726573697a655f313530373534383639322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(50, 104, 'Auto desk Fusion 360 competition', 'Mr. R.Gowtham of Final year Mechanical Engineering student won the first prize in Auto desk Fusion 360 competition Conducted by ICT Academy.', '2017-11-30', 0x75706c6f6164732f3130345f726573697a655f313531323033323836392e706e67, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(51, 104, 'ICTACT  AUTODESK Fusion 360 Workshop', 'The Department of Mechanical Engineering is conducting the ICTACT  AUTODESK Fusion 360 Workshop in Language laboratory on 22.2.2017 at 9.30 AM', '2017-02-22', 0x75706c6f6164732f3130345f726573697a655f313438373635363431372e6a7067, '', '', '', '', '', '', '', '', ''),
(63, 109, 'Techie-elite18 Project Expo', 'The management, Principal, Faculty and students of the Sasurie College of Engineering cordially invites you for the \r\nTechie-elite 18 \r\nproject expo\r\norganized by Internal Quality Assuarance Cell\r\non 16-April 2018\r\nVenue : Abinandham Hall\r\n\r\nChief guest\r\nMr. S. SathishKumar, \r\nDeputy Director, \r\nMSME-D1,\r\nCoimbatore.\r\nShri. A. M. Kandaswami, Chairman ,Sasurie Institutions\r\nSmt. K. Savitha Moganraj, CEO,Sasurie Institutions\r\nWill preside over the function.', '2018-04-13', 0x75706c6f6164732f3130395f726573697a655f313532333538393939302e676966, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(52, 109, 'Foundation for Advancement of Education and Research', 'The following students had presented a project titled “Wireless Security System featured with UWB/PIR Sensor and android application” organized by Foundation for Advancement of Education and Research, Bangalore. Ms.T.Sathya Priya, Ms.N.Hemala, Ms.V.Thamilarasi, Ms..L.Gayathri were highly appreciated by the jury panel and got Rs.5000 as Prize money.', '2017-11-30', '', 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(53, 105, 'Technical Symposium', 'Mr.M.Devendran IV year civil won the second prize in Design context  and third prize in poster presentation held among various colleges.\r\n\r\nMr.P.Deepan IV year civil has won third prize in poster presentation held at national level technical fest.\r\n\r\nMs.A.Karthi, Mr.S.Nandhakumaran,Mr. N.Manikandan & Mr.V.Yuvaraj of second year ECE had won second prize in project presentation in National Level technical Symposium.\r\n\r\nMs.M.Padma Priya & Ms.N.Janaki of third year ECE had won first prize in paper presentation in National Level technical Symposium', '2017-11-30', '', 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(54, 102, 'Foundation for Advancement of Education and Research', 'The following students had presented a project titled Wireless Security System featured with UWB/PIR Sensor and android application organized by Foundation for Advancement of Education and Research, Bangalore. Ms.T.Sathya Priya, Ms.N.Hemala, Ms.V.Thamilarasi, Ms..L.Gayathri were highly appreciated by the jury panel and got Rs.5000 as Prize money', '2017-11-13', '', 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(55, 109, 'Salesforce - Trialhead -Learnathon - 2018 ', 'It is informed that, the ICT Academy in collaboration with Sasurie College of Engineering is conducting “Salesforce Trailhead for Students Championship-2018” The largest Learnathon of India, on 2nd & 3rd February 2018. We request the interested students to attend pre-Learnathon presentation at abinantham hall by 1.30 pm on 29.01.2018.', '2018-02-07', 0x75706c6f6164732f3130395f726573697a655f313531383030313137302e706e67, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(56, 102, 'International Seminar ', '    We would like to invite you all for the International Seminar on IoT & Machine Learning to be held on 06.02.2018 (Tuesday). ', '2018-02-07', 0x75706c6f6164732f3130325f726573697a655f313531383030313438362e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(57, 105, 'Sasurie Constro Vista', 'The Management, Principal, Faculty and Students of Department of Civil Engineering Cordially invite you.', '2018-02-09', 0x75706c6f6164732f3130355f726573697a655f313531383134353839302e6a7067, '', '', '', '', '', '', '', '', ''),
(58, 103, 'Technical Symposium - Energia18', 'Department of Electrical and Electronics Engineering and Association of TESLA presents National Level Technical Symposium ENERGIA 18 on march, 03, 2018.', '2018-02-18', 0x75706c6f6164732f3130335f726573697a655f313531383931373531382e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(59, 109, 'WOMEN DEVELOPMENT CELL - International Womens day celebrations', 'Management, Faculty members, students and Sasurie Women Development Cell proudly presents International Women Day Celebrations on 06 March 2018.We kindly request all the girls students to register and participate in the following events 1.Quiz</p>\r\n\r\n<p>2. Connection</p>\r\n\r\n<p>3. Elocution</p>\r\n\r\n<p>4. Dance and Drama</p>\r\n\r\n<p>\r\n5. Mehandi</p>\r\n\r\n<p>6. Ms. Sasurie', '2018-03-03', 0x75706c6f6164732f3130395f726573697a655f313532303036393038342e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(60, 102, 'A  National Level Project Competition', 'Sasurie College of Engineering Department of Electronics  and Communication Engineering and  Electrical and Electronics Engineering jointly Organize\r\nSASURIE INNVOVATION EXPEDITION SIE - 2018\r\nCircuit Branches\r\n1st. Prize - 5,000\r\n2nd Prize - 3000\r\n3rd Prize - 2,000\r\n\r\n\r\n\r\nNon Circuit Branches\r\n\r\n1st Prize - 5,000\r\n\r\n2nd Prize - 3,000\r\n\r\n3rd Prize - 2,000', '2018-03-03', 0x75706c6f6164732f3130325f726573697a655f313532303036393236362e6a7067, '', '', '', '', '', '', '', '', ''),
(61, 103, 'A National Level Project Competition', 'Sasurie College of Engineering Department of Electronics  and Communication Engineering and  Electrical and Electronics Engineering jointly Organize\r\nSASURIE INNVOVATION EXPEDITION SIE - 2018\r\nCircuit Branches\r\n1st. Prize - 5,000\r\n2nd Prize - 3000\r\n3rd Prize - 2,000\r\n\r\n\r\n\r\nNon Circuit Branches\r\n\r\n1st Prize - 5,000\r\n\r\n2nd Prize - 3,000\r\n\r\n3rd Prize - 2,000', '2018-03-03', 0x75706c6f6164732f3130335f726573697a655f313532303036393236362e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(62, 104, 'One day International Seminar on Recent Trend', 'Department of Mechanical Engineering  The management, Principal, Faculty and students of the Department of Mechanical Engineering cordially invites you for the  International Seminar on \r\nRecent Trends in Mechanical Engineering 21st March 2018, \r\nAbinandam Hall Chief Guests :\r\nDr. Kumaran \r\nDr. Ngui Wai Keng \r\nDr. Mahendran Samkano\r\nDr. Sudhakar\r\nFaculty of Mechanical Engineering, \r\nUniversiti Malaysia Pahang,have kindly concerned to be the resource person\r\nShri. A. M. Kandaswami, Chairman\r\nSmt. K. Savitha Moganraj, CEO,Sasurie Institutions', '2018-03-21', 0x75706c6f6164732f3130345f726573697a655f313532313632363438322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(64, 109, 'Fourth International Yoga Day (YDI)', 'Management, Principal, Staff and Students of  Sasurie College of Engineering celebrates 4th International Yoga Day on 21.06.2018\r\nat Abinandam Hall, Sasurie College of Engineering, by Tirupur Amarjothi Nagar, Manavalakkalai Mandra Arakkattalai,Tiruppur.', '2018-06-23', 0x75706c6f6164732f3130395f726573697a655f313532393734313134392e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(65, 109, 'Women Development Cell Inaguration.', 'The Management, Women Faculty & Staff members, Female Students of  Sasurie College of Engineering Inaugurated Women Development Cell on 05th July 2018 at Abinandham Hall, Sasurie College of Engineering', '2018-07-05', 0x75706c6f6164732f3130395f7764632e706e67, 0x0d0a20202020202020202020202075706c6f6164732f3130395f776463312e706e67, '', '', '', '', '', '', '', ''),
(66, 105, 'Civil Engineering Association Inauguration and Workshop', 'Civil Legenders Association Inauguration and Workshop on Developing skills in Modern Surveying instruments and its uses', '2018-07-21', 0x75706c6f6164732f3130355f636976696c5f6173736f5f696e617567332e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(67, 102, 'Electronics & Communication Engineering Association Inauguration', 'Electronics & Communication Engineering "EPANO" Association Inauguration', '2018-07-21', 0x75706c6f6164732f3130325f6563655f6173736f5f696e617567312e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(68, 105, 'District Level Elocution competition', 'Ms. Priyanka of III Civil has won II place in district level elocution competition. We the management wishes all the very best for next level selection gonna happen state level at 18th August 2018. ', '2018-08-16', 0x75706c6f6164732f3130355f656c6f637574696f6e2e6a706567, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(69, 109, 'Independence Day celebrations 2018 ', 'Sasurie College of Engineering happily celebrates 72nd Independence day. Our beloved principal Dr.K.Pandiarajan hoists the national flag as the faculty members gathered in the event. ', '2018-08-16', 0x75706c6f6164732f3130395f696e6469312e6a706567, 0x0d0a20202020202020202020202075706c6f6164732f3130395f696e6469322e6a706567, '', '', '', '', '', '', '', ''),
(70, 109, 'Graduation Day 2018-Invitation', 'The Students, Staffs, Faculty Members and the Management cordially inviting all the Graduants for 13th Convocation Day scheduled on 8th September 2018. ', '2018-09-06', 0x75706c6f6164732f3130395f726573697a655f313533363231343038312e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', ''),
(72, 108, 'Graduation Day 2018', 'Sasurie College of Engineering, Vijayamangalam organized 13thgraduation day function for the new graduates on 8th September 2018. \r\nShri. A.M. Kandaswami, Chairman and Smt. A.K. Swathi Hariharasudhan, Secretary presided over the function. Smt. Savitha Moganraj, CEO and Mr. N. Sathiyamoorthi, Management Trustee of Sasurie Institutions lead the function.\r\nDr. K. Pandiarajan, Principal, Sasurie College of Engineering welcomed the gathering. Mr. K. Purushothaman, Regional Director, NASSCOM and Mr. Vijayan Rajkumar, HR-Head, Prodapt Solutions, distributed certificates to the Graduands. Mr. K. Purushothaman emphasized cutting-edge technologies ruling the industry. Mr. Vijayan Rajkumar narrated the job opportunities for engineering graduates across the world. About 200 candidates received certificates and medals.', '2018-09-10', 0x75706c6f6164732f3130385f726573697a655f313533363536303030322e6a7067, 0x0d0a202020202020202020202020, '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sce_rd`
--

CREATE TABLE IF NOT EXISTS `sce_rd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `message` longtext,
  PRIMARY KEY (`id`),
  KEY `k_sce_rd` (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sce_rd`
--


-- --------------------------------------------------------

--
-- Table structure for table `sce_request_form`
--

CREATE TABLE IF NOT EXISTS `sce_request_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(40) NOT NULL,
  `message` longtext NOT NULL,
  `date_time` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k_requeast_key_dept` (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sce_request_form`
--


-- --------------------------------------------------------

--
-- Table structure for table `sce_testimonials`
--

CREATE TABLE IF NOT EXISTS `sce_testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `role` varchar(90) DEFAULT NULL,
  `title` varchar(70) NOT NULL,
  `message` longtext NOT NULL,
  `date` date DEFAULT NULL,
  `image1` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sce_testimonials`
--

INSERT INTO `sce_testimonials` (`id`, `dept_id`, `name`, `role`, `title`, `message`, `date`, `image1`) VALUES
(1, 111, 'Prof. M. Vijayalakshmi', 'Principal, U.O.A.School', 'Computer Training', 'Thanks for the 4 days Computer training by faculties of CSE department for our school teachers.  We are extremely satisfied by your valuable sessions. Thanks a lot.', '2014-05-01', 0x75706c6f6164732f3130315f726573697a655f313531353233353435312e6a7067),
(3, 102, 'Mr Stanley George', 'Vice President ,HR(South India),Hexaware Technologies,Chennai.', 'Graduation Ceremony', 'An exciting day presenting degree to the students.Joy to see glow in he students eyes.Keep up the good work that your doing in  this region.Wish you all the best.', '2014-06-09', 0x75706c6f6164732f3130315f726573697a655f313430323332313732342e6a7067),
(5, 101, 'Mr S Bhanu Kumar', 'Vice president,Cloud infrastructure  services,NTT Data global delivery  Services  limited', 'Graduation Ceremony', 'Vice president,Cloud infrastructure  services,NTT Data global delivery  Services  limited', '2014-06-09', 0x75706c6f6164732f3130315f726573697a655f313430323332313638342e6a7067),
(6, 109, 'Shri T.S.Rangarajan', 'Chair Person,IEEE Madras Section,Principal & Consultant,TCS.', 'IEEE Paper Submission Events', 'ICICIC 13 Conference was a massive events and 1300 paper submission but managed very meticulously,collaboratively and quitely!\r\nWell Done Team. ', '2014-06-09', 0x75706c6f6164732f3130395f726573697a655f313430323332313630392e6a7067),
(7, 108, 'Mr Timothy Samsom', 'Human Resources-Campus Recruitment,Tech Mahindra', 'Campus Recruitment', 'Sasurie Seems to be a good place for learning where recruiters can do their maximum quality harvest in the near future. Hearty wishes from Tech Mahindra for the greatest success to be achieved. Work on accepting No limits, alternative thinking, driving positive change to Grow with us to Touch the Rise.', '2014-06-09', 0x75706c6f6164732f3130395f726573697a655f313430323332313531342e6a7067),
(9, 105, 'Mrs.Savitha Mohanraj', 'CEO of Sasurie INstitution', 'Sasurie Constro Vista', 'Good Event', '2010-01-02', 0x75706c6f6164732f3130355f726573697a655f313531383134353839302e6a7067),
(10, 103, 'Mr.Rajesh Kumar', 'Tesla Association Head', 'advanced embedded system', 'Tesla students association cordially invites you  for the invited talk on advanced embedded system', '2007-02-01', ''),
(11, 104, 'Mr.Ranjith', 'Member of ICTACT', 'ICTACT  AUTODESK Fusion 360 Workshop', 'The Department of Mechanical Engineering is conducting the ICTACT  AUTODESK Fusion 360 Workshop in Language laboratory on 22.2.2017 at 9.30 AM', '2009-01-02', 0x75706c6f6164732f3130345f726573697a655f313438373635363431372e6a7067),
(12, 112, 'Shri. D. Baskar Raj', 'Managing Partner, SRS Lungies, Erode\r\n', 'ESTILO - 2016', 'Department of Mangement Science and the Management, Principal, Faculty and Students\r\n\r\ncordially invites you to the Association Inagural Function\r\n\r\nESTILO - 2016\r\nChief Guest:\r\nShri. D. Baskar Raj\r\n\r\nManaging Partner, SRS Lungies, Erode\r\n\r\n\r\n\r\nPreside Over by:\r\nShri. A. M . Kandaswami\r\n\r\nChairman, Sasurie Group of Institutions\r\n\r\n\r\n\r\nFelicitation by:\r\nShrimathi. K. Savitha Mohanraj\r\n\r\nCEO, Sasurie Group of Institutions\r\n\r\n\r\n\r\nDr. R. Radhakrishnan,\r\n\r\nPrincipal, Sasurie College of Engineering\r\n\r\n\r\n\r\nMr. Arun Kumar, \r\n\r\nHD, MBA Department, Sasurie College of Engineering\r\n\r\n', '2009-02-23', ''),
(13, 113, 'Mr.Ranjith', 'CEO', 'Workshop on Financial Education', 'Department of Management Sciences \r\n\r\nCordially invite you for the \r\n\r\nWorkshop on Financial Education \r\n\r\nin Association with\r\n\r\nSecurities Exchange Board of India Chennai\r\n\r\n', '2005-07-04', 0x75706c6f6164732f3131335f726573697a655f313437353634333230372e6a7067),
(14, 114, 'Mr.Santhosh Kumar', 'CEO', 'Workshop on Power Electronics', 'Workshop on Power Electronics', '2008-03-12', ''),
(15, 115, 'Ms.Aarthy', 'Member of HCL company', 'Seminar on Applied Electronics', 'Seminar on Applied Electronics', '2007-03-04', ''),
(16, 116, 'Mr.Santhosh', 'CEO', 'Seminar on Cloud Computing', 'Seminar on Cloud Computing', '2009-09-03', '');

-- --------------------------------------------------------

--
-- Table structure for table `sce_tieups`
--

CREATE TABLE IF NOT EXISTS `sce_tieups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `image1` blob,
  `image2` blob,
  `message` longtext,
  PRIMARY KEY (`id`),
  KEY `k_sce_tieups` (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sce_tieups`
--

