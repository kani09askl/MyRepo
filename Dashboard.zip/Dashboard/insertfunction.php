<?php


$field=$_GET['field'];
require 'insertview.php';
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];
$_SESSION["dept_name"]=$dept_name_db;
$_SESSION["username"]=$username_db;
$_SESSION["dept_id"]=$dept_id_db;
if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}

?>
<?php
if($field=="dept_details")
{
?>
<html>
<div><?php dept_details();?></div>
</html>
<?php
}
elseif ($field=="lab") {
?>
<html>
<div><?php lab_details();?></div>
</html>
<?php
}
elseif ($field=="rnd") {

?>
<html>
<div><?php rnd();?></div>
</html>

<?php
}
elseif ($field=="tieups") {
?>
<html>
<div><?php tieups();?></div>
</html>
<?php
}
elseif ($field=="achievements") {
?>
<html>
<div><?php achievements();?></div>
</html>
<?php
}
elseif ($field=="testimonials") {
?>
<html>
<div><?php testimonials();?></div>
</html>
<?php
}
elseif ($field=="faculty") {
?>

<html>
<div><?php faculty();?></div>
</html>

<?php
}
elseif($field=="news_events"){
?>
<html>
<div><?php news_events();?></div>
</html>
<?php
}
elseif($field=="facility"){
?>
<html>
<div><?php facility();?></div>
</html>
<?php
}
elseif($field=="advertisement"){
?>
<html>
<div><?php advertisement();?></div>
</html>
<?php
}
?>

