<html>
<head>
<title>HTML Frames Example - Footer</title>
<style type="text/css">
body {
	font-family:verdana,arial,sans-serif;


	background-color:#c68c53;
 	color:white;
	}
a {
	color:white;
	}
	img{
		margin-top:-10px;
		margin-left:86%;
		width:100px;
		height:60px;
	}
	#text{
		margin-left:1060px;
		margin-top:-20px;
	}
</style>
</head>
<body>
<div>
	<img src="images/sit.png" >
</div>
<div id="text">
	<p>Developded by Sasurie Info Tech</p>
</div>
</body>
</html>