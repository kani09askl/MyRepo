<?php
require 'db.php';
session_start();
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];

    $_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;

	if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}

$id=$_GET['id'];
$field=$_GET['field'];
?>
<head>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery.min.js"> </script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script>
</head> 

<?php
if($field=="alumni_detail")
{
$id=$_GET['id'];

$v1=$_POST['v1'];
$v2=$_POST['v2'];
$v3=$_POST['v3'];
$v4=$_POST['v4'];
$v5=$_POST['v5'];
$v6=$_POST['v6'];
$v7=$_POST['v7'];
$v8=$_POST['v8'];

?>
<html>
<head>
<title>Alumni_details</title>
</head>
<body style="background-color: white;"><form action="dbupdation.php?field=<?php echo $field.'&id='.$id;?>"  method="POST" enctype="multipart/form-data">
<center>
<table>
<tr>
<td id="td">Name</td>
<td><textarea rows="2" cols="45" id="msg" name="name" required style="background-color: white;" disabled>
<?php echo $v1; ?></textarea></td>
</tr>
<tr>
<td id="td">Email-id</td>
<td><textarea rows="2" cols="45" id="msg" name="email" required style="background-color: white;" disabled>
<?php echo $v2; ?></textarea></td>
</tr>
<tr>
<td id="ftd">Contact:</td>
<td><input type="text" id="name" name="contact" value="<?php echo $v3;?>" required style="background-color: white;" disabled></td>
</tr>
<tr>
<td id="td">Message</td>
<td><textarea rows="2" cols="45" id="msg" name="message" required style="background-color: white;" disabled>
<?php echo $v4; ?></textarea></td>
</tr>
<tr>
<td id="ftd">Date:</td>
<td><input type="date" id="name" name="date" value="<?php echo $v5;?>" required style="background-color: white;" disabled>
</td>
</tr>
<tr>
<td id="ftd">Batch:</td>
<td><input type="text" id="name" name="batch" value="<?php echo $v6;?>" required style="background-color: white;" disabled></td>
</tr>
<tr>
<td id="td">Occupation</td>
<td><textarea rows="2" cols="45" id="msg" name="occupation" required style="background-color: white;" disabled>
<?php echo $v7; ?></textarea></td>
</tr>
<tr>
<td id="td">Company Name</td>

<td><textarea rows="2" cols="45" id="msg" name="company_name" required style="background-color: white;" disabled>
<?php echo $v8; ?></textarea></td>
</tr>
<?php
}
?>