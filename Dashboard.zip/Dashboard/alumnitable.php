<?php
session_start();
require 'db.php';
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];
$field = $_GET["field"];

    $_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;

	if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}
?>
<head>
<title>Table</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/stylesheet.css">
<script type="text/javascript" src="js/jquery.js"> </script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script></head>

<?php
if($field=="alumni_detail")
{

$str="select * from sce_alumni_form where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);

?>

<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th>S.No</th>
<th>Name</th>
<th>Email-Id</th>
<th>Contact</th>
<th>Message</th>
<th>Date</th>
<th>Batch</th>
<th>Occupation</th>
<th>Company name</th>
<th></th>
</tr>

<?php
for($i=0;$i<=$len;$i++)
{
while($row=@mysqli_fetch_assoc($result))
{
$id=$row['id'];
$v1=$row['name'];
$v2=$row['email'];
$v3=$row['contact'];
$v4=$row['message'];
$v5=$row['date'];
$v6=$row['batch'];
$v7=$row['occupation'];
$v8=$row['company_name'];
?>
<form action="alumniview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">
<tr>
<td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>" ><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>" ><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3"  value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4"  value="<?php echo $v4;?>"><input  name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" name="v5" value="<?php echo $v5;?>" ><input  name="v5" value="<?php echo $v5;?>" disabled></td>
<td><input type="hidden" name="v6" value="<?php echo $v6;?>" ><input  name="v6" value="<?php echo $v6;?>" disabled></td>
<td><input type="hidden" name="v7" value="<?php echo $v7;?>" ><input  name="v7" value="<?php echo $v7;?>" disabled></td>
<td><input type="hidden" name="v8" value="<?php echo $v8;?>" ><input  name="v8" value="<?php echo $v8;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="view"  name="edit"></td>
</form>

</tr>

<?php
}
}
}
?>