<?php 
// db Connectivity in seperate file it is common for all files both //engg website and dashboard

$con = @mysqli_connect("localhost","root", "","sasurie_engg");

?>