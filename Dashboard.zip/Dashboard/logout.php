<?php

session_start();

$_SESSION['username']=null;
$_SESSION['dept_name']=null;
$_SESSION['dept_id']=null;

session_destroy();


echo "<script>window.location='index.php';</script>";

?>