<?php
session_start();

require 'db.php';
$dept_id_db=$_SESSION['dept_id'];
$field=$_GET['field'];
$id=$_GET['id'];
?>
<?php

$image1=$image2=$image3=$image4=$image5=$image6=$image7=$image8=$image9=$image0="";

function image1()
{
   global $image1;global $dept_id_db;
        
        if(basename( $_FILES['image1']['name'])==true){
         $path = "uploads/";
        $image1 = $path .$dept_id_db."_" . basename( $_FILES['image1']['name']);
        move_uploaded_file($_FILES['image1']['tmp_name'], $image1);
        //echo $image1;
      }

}
function image2()
{
   global $image2;global $dept_id_db;
       
        if(basename( $_FILES['image2']['name'])==true){
        $path = "uploads/";
        $image2 = $path .$dept_id_db."_" . basename( $_FILES['image2']['name']);
        move_uploaded_file($_FILES['image2']['tmp_name'], $image2);
       // echo $image2;
      }
    }
function image3()
{
   global $image3;global $dept_id_db;
       
        if(basename( $_FILES['image3']['name'])==true){
        $path = "uploads/";
        $image3 = $path .$dept_id_db."_" . basename( $_FILES['image3']['name']);
        move_uploaded_file($_FILES['image3']['tmp_name'], $image3);
        //echo $image3;
      }
    }
    function image4()
{
   global $image4;global $dept_id_db;
       
        if(basename( $_FILES['image4']['name'])==true){
        $path = "uploads/";
        $image4 = $path .$dept_id_db."_" . basename( $_FILES['image4']['name']);
        move_uploaded_file($_FILES['image4']['tmp_name'], $image4);
        //echo $image4;
      }
    }
    function image5()
{
   global $image5;global $dept_id_db;
       
        if(basename( $_FILES['image5']['name'])==true){
        $path = "uploads/";
        $image5 = $path.$dept_id_db."_" . basename( $_FILES['image5']['name']);
        move_uploaded_file($_FILES['image5']['tmp_name'], $image5);
        //echo $image5;
      }
    }


    function image6()
{
   global $image6;global $dept_id_db;
       
        if(basename( $_FILES['image6']['name'])==true){
        $path="uploads/";
        $image6=$path.$dept_id_db."_".basename( $_FILES['image6']['name']);
        move_uploaded_file($_FILES['image6']['tmp_name'],$image6);
        //echo $image6;
      }
    }
function image7()
{
   global $image7;global $dept_id_db;
       
        if(basename( $_FILES['image7']['name'])==true){
        $path = "uploads/";
        $image7=$path.$dept_id_db."_".basename( $_FILES['image7']['name']);
        move_uploaded_file($_FILES['image7']['tmp_name'],$image7);
        //echo $image7;
      }
    }
function image8()
{
   global $image8;global $dept_id_db;
       
        if(basename( $_FILES['image8']['name'])==true){
        $path = "uploads/";
        $image8=$path.$dept_id_db."_".basename( $_FILES['image8']['name']);
        move_uploaded_file($_FILES['image8']['tmp_name'],$image8);
        //echo $image8;
      }
    }    
                                  
function image9()
{
   global $image9;global $dept_id_db;
       
        if(basename( $_FILES['image9']['name'])==true){
        $path = "uploads/";
        $image9=$path.$dept_id_db."_".basename( $_FILES['image9']['name']);
        move_uploaded_file($_FILES['image9']['tmp_name'],$image9);
        //echo $image9;
      }
    }
 function image0()
{
   global $image0;global $dept_id_db;
       
        if(basename( $_FILES['image0']['name'])==true){
        $path = "uploads/";
        $image0=$path.$dept_id_db."_".basename( $_FILES['image0']['name']);
        move_uploaded_file($_FILES['image0']['tmp_name'], $image0);
        //echo $image0;
      }
    }   
?>
<?php
if($field=="dept_details")
{
$dept_message=@mysqli_real_escape_string($con,$_POST['dept_message']);
$dept_sub_message1=@mysqli_real_escape_string($con,$_POST['dept_sub_message1']);
$dept_sub_message2=@mysqli_real_escape_string($con,$_POST['dept_sub_message2']);
$dept_sub_message3=@mysqli_real_escape_string($con,$_POST['dept_sub_message3']);
$dept_sub_message4=@mysqli_real_escape_string($con,$_POST['dept_sub_message4']);
$dept_sub_message5=@mysqli_real_escape_string($con,$_POST['dept_sub_message5']);
$dept_hod_name=@mysqli_real_escape_string($con,$_POST['dept_hod_name']);
$dept_hod_address=@mysqli_real_escape_string($con,$_POST['dept_hod_address']);

image1();

$str="update sce_department_details set dept_message='$dept_message',dept_sub_message1='$dept_sub_message1',dept_sub_message2='$dept_sub_message2',dept_sub_message3='$dept_sub_message3',dept_sub_message4='$dept_sub_message4',dept_sub_message5='$dept_sub_message5',dept_hod_name='$dept_hod_name',dept_hod_address='$dept_hod_address',image1='$image1' where id='$id'";


}
elseif($field=="lab")
{
$message=@mysqli_real_escape_string($con,$_POST['message']);
$title=@mysqli_real_escape_string($con,$_POST['title']);

image1();image2();image3();image4();
$str="update sce_lab set message='$message',image1='$image1',image2='$image2',image3='$image3',image4='$image4',title='$title' where id='$id'";

}
elseif($field=="rnd")
{
	$message=@mysqli_real_escape_string($con,$_POST['message']);
	$title=@mysqli_real_escape_string($con,$_POST['title']);
image1();image2();
$str="update sce_rd set title='$title',image1='$image1',image2='$image2',message='$message' where id='$id'";


}
elseif($field=="tieups")
{
$message=@mysqli_real_escape_string($con,$_POST['message']);
$title=@mysqli_real_escape_string($con,$_POST['title']);
image1();image2();
$str="update sce_tieups set title='$title',image1='$image1',image2='$image2',message='$message' where id='$id'";

}
elseif($field=="achievements")
{
$message=@mysqli_real_escape_string($con,$_POST['message']);
$name=@mysqli_real_escape_string($con,$_POST['achieversname']);
$title=@mysqli_real_escape_string($con,$_POST['title']);
$date=$_POST['date'];
$gain=@mysqli_real_escape_string($con,$_POST['gain']);
$organization=@mysqli_real_escape_string($con,$_POST['organization']);
image1();
$str="update sce_achievement set achieversname='$name',title='$title',gain='$gain',message='$message',date='$date',image1='$image1',organization='$organization' where id='$id'";
}
elseif($field=="testimonials")
{
$message=@mysqli_real_escape_string($con,$_POST['message']);
$name=@mysqli_real_escape_string($con,$_POST['name']);
$title=@mysqli_real_escape_string($con,$_POST['title']);
$date=$_POST['date'];
$role=@mysqli_real_escape_string($con,$_POST['role']);
image1();
$str="update sce_testimonials set name='$name',role='$role',title='$title',message='$message',date='$date',image1='$image1' where id='$id'";
}
elseif($field=="faculty")
{
 	$name=@mysqli_real_escape_string($con,$_POST['name']);
 	$degree=$_POST['degree'];
 	$designation=$_POST['designation'];

$str="update sce_faculty_details set name='$name',degree='$degree',designation='$designation' where id=$id";
}
elseif($field=="news_events")
{

	$title=@mysqli_real_escape_string($con,$_POST['title']);
	$message=@mysqli_real_escape_string($con,$_POST['message']);
	$date=$_POST['date'];
	
	image1();image2();image3();image4();image5();image6();image7();image8();image9();image0();
$str="update sce_newsandevents set title='$title',message='$message',date='$date', image1='$image1',image2='$image2',image3='$image3',image4='$image4',image5='$image5',image6='$image6',image7='$image7',image8='$image8',image9='$image9',image0='$image0' where id='$id'";
}
elseif($field=="facility")
{
	$title=@mysqli_real_escape_string($con,$_POST['title']);
	$message=@mysqli_real_escape_string($con,$_POST['message']);
	
	
	image1();image2();image4();image5();image6();
	$str="update sce_facilities set title='$title',image1='$image1',image2='$image2',image4='$image4',image5='$image5',image6='$image6',message='$message' where id='$id'";
}
elseif($field=="advertisement")
{

	$title=@mysqli_real_escape_string($con,$_POST['title']);
	$message=@mysqli_real_escape_string($con,$_POST['message']);
	$date=$_POST['date'];
	$reglink=$_POST['reglink'];
	
	image1();image2();image3();
$str="update sce_advertisement set title='$title',message='$message',date='$date', image1='$image1',image2='$image2',image3='$image3',reglink='$reglink' where id='$id'";
}
$query=@mysqli_query($con,$str);
if($query)
{
	echo "<script type=\"text/javascript\">window.alert('Data updated successfully');
window.location.href = 'option.php?field=$field';</script>"; 
}
else
{
	echo "<script type=\"text/javascript\">window.alert('Error on updating data');
window.location.href = 'listview.php?field=$field';</script>"; 
}
?>