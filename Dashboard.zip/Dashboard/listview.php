<?php
session_start();
require 'db.php';
$dept_name_db=$_SESSION["dept_name"];
$username_db=$_SESSION["username"];
$dept_id_db=$_SESSION["dept_id"];
$field = $_GET["field"];

    $_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;

	if($_SESSION["dept_name"] && $_SESSION["username"] && $_SESSION["dept_id"])

{
	$_SESSION["dept_name"]=$dept_name_db;
	$_SESSION["username"]=$username_db;
	$_SESSION["dept_id"]=$dept_id_db;
	//echo "session validate";
}

?>
<head>
<title>Table</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/stylesheet.css">
<script type="text/javascript" src="js/jquery.js"> </script>
<script type="text/javascript" src="js/bootstrap.min.js" ></script></head>

<?php
if($field=="dept_details")
{

$str="select * from sce_department_details where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);

?>
<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th>S.No</th>
<th>About the Course:</th>
<th>Long Term Goal:</th>
<th>Short Term Goal:</th>
<th>Programme Educational Objective:</th>
<th>Programme Outcomes</th>
<th>Department Quote</th>
<th>Dept_hod_name</th>
<th>Dept_hod_address</th>
<th>Image</th>
<th></th>
<th></th>
</tr>
<?php
for($i=0;$i<=$len;$i++)
{
	
while($row=@mysqli_fetch_assoc($result))
{
$id=$row['id'];
$v1=$row['dept_message'];
$v2=$row['dept_sub_message1'];
$v3=$row['dept_sub_message2'];
$v4=$row['dept_sub_message3'];
$v5=$row['dept_sub_message4'];
$v6=$row['dept_sub_message5'];
$v7=$row['dept_hod_name'];
$v8=$row['dept_hod_address'];
$v9=$row['image1'];
?>
<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">
<tr>
<td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>" ><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>" ><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3"  value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4"  value="<?php echo $v4;?>"><input  name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" name="v5" value="<?php echo $v5;?>" ><input  name="v5" value="<?php echo $v5;?>" disabled></td>
<td><input type="hidden" name="v6" value="<?php echo $v6;?>" ><input  name="v6" value="<?php echo $v6;?>" disabled></td>
<td><input type="hidden" name="v7" value="<?php echo $v7;?>" ><input  name="v7" value="<?php echo $v7;?>" disabled></td>
<td><input type="hidden" name="v8" value="<?php echo $v8;?>" ><input  name="v8" value="<?php echo $v8;?>" disabled></td>
<td><input type="hidden" name="v9"  value="<?php echo $v9;?>"><input  name="v9" value="<?php echo $v9;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td>
</form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" name="delete"> <input type="submit" value="delete"  name="delete"></td>
</tr>
<?php
}
}
}
if($field=="lab") {
	
$str="select * from sce_lab where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th></th>
<th>message</th>
<th>image1</th>
<th>image2</th>
<th>image3</th>
<th>image4</th>
<th>Title</th>
<th></th>
<th></th>
</tr>
<?php
for($i=0;$i<=$len;$i++)
{
	
while($row=@mysqli_fetch_assoc($result))
{
$id=$row['id'];
$v1=$row['message'];
$v2=$row['image1'];
$v3=$row['image2'];
$v4=$row['image3'];
$v5=$row['image4'];
$v6=$row['title'];

?><form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">
<tr>
<td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>" ><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>" ><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3"  value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4"  value="<?php echo $v4;?>"><input  name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" name="v5"  value="<?php echo $v5;?>"><input  name="v5" value="<?php echo $v5;?>" disabled></td>
<td><input type="hidden" name="v6" value="<?php echo $v6;?>" ><input  name="v6" value="<?php echo $v6;?>" disabled></td>

<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td>
</form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" name="delete"> <input type="submit" value="delete"  name="delete"></td>
</tr>
<?php
}
}
}
if($field=="rnd") {
	
$str="select * from sce_rd where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th></th>
<th>Title</th>
<th>image1</th>
<th>image2</th>
<th>message</th>

<th></th>
<th></th>
</tr>
<?php
for($i=0;$i<=$len;$i++)
{
	
while($row=@mysqli_fetch_assoc($result))
{
$id=$row['id'];
$v1=$row['title'];
$v2=$row['image1'];
$v3=$row['image2'];
$v4=$row['message'];

?>
<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">

<tr><td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>" ><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>" ><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3"  value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4"  value="<?php echo $v4;?>"><input  name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td>
</form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" name="delete"> <input type="submit" value="delete"  name="delete"></td>
</tr>
<?php
}
}
}
if($field=="tieups") {
	
$str="select * from sce_tieups where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th></th>
<th>Title</th>
<th>image1</th>
<th>image2</th>
<th>message</th>

<th></th>
<th></th>
</tr>
<?php
for($i=0;$i<=$len;$i++)
{
	
while($row=@mysqli_fetch_assoc($result))
{
$id=$row['id'];
$v1=$row['title'];
$v2=$row['image1'];
$v3=$row['image2'];
$v4=$row['message'];
?>
<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">
<tr><td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>" ><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>" ><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3"  value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4"  value="<?php echo $v4;?>"><input  name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td>
</form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" name="delete"> <input type="submit" value="delete"  name="delete"></td>
</tr>
<?php
}
}
}
if($field=="achievements") {
	
$str="select * from sce_achievement where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th></th>
<th>Name</th>
<th>title</th>
<th>Gain</th>
<th>message</th>
<th>date</th>
<th>image1</th>
<th>Organization</th>
<th></th>
<th></th>
</tr>

<?php
for($i=0;$i<=$len;$i++)
{
	
while($row=@mysqli_fetch_assoc($result))
{
$id=$row['id'];
$v1=$row['achieversname'];
$v2=$row['title'];
$v3=$row['gain'];
$v4=$row['message'];
$v5=$row['date'];
$v6=$row['image1'];
$v7=$row['organization'];

?>
<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">
<tr><td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>" ><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>" ><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3"  value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4"  value="<?php echo $v4;?>"><input  name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" name="v5"  value="<?php echo $v5;?>"><input  name="v5" value="<?php echo $v5;?>" disabled></td>
<td><input type="hidden" name="v6"  value="<?php echo $v6;?>"><input  name="v6" value="<?php echo $v6;?>" disabled></td>
<td><input type="hidden" name="v7"  value="<?php echo $v7;?>"><input  name="v7" value="<?php echo $v7;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td>
</form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" name="delete"> <input type="submit" value="delete"  name="delete"></td>
</tr>
<?php
}
}
}
if($field=="testimonials") {
	
$str="select * from sce_testimonials";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th></th>
<th>Name</th>
<th>role</th>
<th>title</th>
<th>message</th>
<th>date</th>
<th>image1</th>
<th></th>
<th></th>
</tr>

<?php
for($i=0;$i<=$len;$i++)
{
	
while($row=@mysqli_fetch_assoc($result))
{
$id=$row['id'];
$v1=$row['name'];
$v2=$row['role'];
$v3=$row['title'];
$v4=$row['message'];
$v5=$row['date'];
$v6=$row['image1'];
?>
<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">
<tr><td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>" ><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>" ><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3"  value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4"  value="<?php echo $v4;?>"><input  name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" name="v5"  value="<?php echo $v5;?>"><input  name="v5" value="<?php echo $v5;?>" disabled></td>
<td><input type="hidden" name="v6" value="<?php echo $v6;?>" ><input  name="v6" value="<?php echo $v6;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td>
</form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" name="delete"> <input type="submit" value="delete"  name="delete"></td>
</tr>
<?php
}
}
}
if($field=='faculty'){
$str="select * from sce_faculty_details where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5">
<tr>
<th>id</th>
<th>name</th>
<th>degree</th>
<th>Designation</th>
<th></th>
<th></th>
</tr>
<?php
for($i=0;$i<=$len;$i++)
{
while($row=@mysqli_fetch_assoc($result))
	
{
$id=$row['id'];
$v1=$row['name'];
$v2=$row['degree'];
$v3=$row['designation'];?>
<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">
<tr>
<td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>"><input  name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>"><input  name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3" value="<?php echo $v3;?>"><input  name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td></form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" name="delete"><input type="submit" value="delete"name="delete"></a></td></tr>
<?php } } } 

if($field=="news_events"){
	$str="select * from sce_newsandevents where dept_id='$dept_id_db'";
	$result=@mysqli_query($con,$str);
	$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5" >
	<tr>
		<th>id</th>
		<th>title</th>
		<th>message</th>
		<th>date</th>
		<th>image1</th>
		<th>image2</th>
		<th>image3</th>
		<th>image4</th>
		<th>image5</th>
		<th>image6</th>
		<th>image7</th>
		<th>image8</th>
		<th>image9</th>
		<th>image0</th>
		<th></th>
		<th></th>
	</tr>
<?php
for($i=0;$i<=$len;$i++){
	while($row=@mysqli_fetch_assoc($result)){
		$id=$row['id'];
		$title=$row['title'];
		$message=$row['message'];
		$date=$row['date'];
		$v1=$row['image1'];
		$v2=$row['image2'];
		$v3=$row['image3'];
		$v4=$row['image4'];
		$v5=$row['image5'];
		$v6=$row['image6'];
		$v7=$row['image7'];
		$v8=$row['image8'];
		$v9=$row['image9'];
		$v0=$row['image0'];
?>

<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">

<tr>
<td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="title" value="<?php echo $title;?>"><input name="title" value="<?php echo $title;?>"disabled>
</td>
<td><input type="hidden" name="message" value="<?php echo $message;?>"><input name="message" value="<?php echo $message;?>"disabled>
</td>
<td><input type="hidden" name="date" value="<?php echo $date;?>"><input name="date" value="<?php echo $date;?>" disabled>
</td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>"><input name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>"><input name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3" value="<?php echo $v3;?>"><input name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4" value="<?php echo $v4;?>"><input name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" name="v5" value="<?php echo $v5;?>"><input name="v5" value="<?php echo $v5;?>" disabled></td>
<td><input type="hidden" name="v6" value="<?php echo $v6;?>"><input name="v6" value="<?php echo $v6;?>" disabled></td>
<td><input type="hidden" name="v7" value="<?php echo $v7;?>"><input name="v7" value="<?php echo $v7;?>" disabled></td>
<td><input type="hidden" name="v8" value="<?php echo $v8;?>"><input name="v8" value="<?php echo $v8;?>" disabled></td>
<td><input type="hidden" name="v9" value="<?php echo $v9;?>"><input name="v9" value="<?php echo $v9;?>" disabled></td>
<td><input type="hidden" name="v0" value="<?php echo $v0;?>"><input name="v0" value="<?php echo $v0;?>" disabled></td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td></form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" 
name="delete"><input type="submit" value="delete"name="delete"></a></td></tr>
<?php }
}}
if($field=="facility"){
	$str="select * from sce_facilities where dept_id='$dept_id_db'";
	$result=@mysqli_query($con,$str);
	$len=@mysqli_num_rows($result);
?>
<html>
<body>
<table border="1" id="table" cellspacing="5" >
	<tr>
		<th>id</th>
		<th>title</th>
        <th>image1</th>
		<th>image2</th>
		<th>image3</th>
		<th>image4</th>
		<th>image5</th>
	    <th>message</th>
		<th></th>
		<th></th>
	</tr>
<?php

for($i=0;$i<=$len;$i++){
	while($row=@mysqli_fetch_assoc($result)){
		$id=$row['id'];
		$title=$row['title'];
		$message=$row['message'];
		
		$v1=$row['image1'];
		$v2=$row['image2'];
		$v3=$row['image4'];
		$v4=$row['image5'];
		$v5=$row['image6'];

?>	

<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">

<tr>
<td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="title" value="<?php echo $title;?>"><input name="title" value="<?php echo $title;?>"    disabled>
</td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>"><input name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>"><input name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3" value="<?php echo $v3;?>"><input name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4" value="<?php echo $v4;?>"><input name="v4" value="<?php echo $v4;?>" disabled></td>
<td><input type="hidden" name="v5" value="<?php echo $v5;?>"><input name="v5" value="<?php echo $v5;?>" disabled></td>
<td><input type="hidden" name="message" value="<?php echo $message;?>"><input name="message" value="<?php echo $message;?>" disabled>
</td>
<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td></form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" 
name="delete"><input type="submit" value="delete" name="delete"></a></td></tr>
<?php }
}}
if($field=="advertisement") {
	
$str="select * from sce_advertisement where dept_id='$dept_id_db'";
$result=@mysqli_query($con,$str);
$len=@mysqli_num_rows($result);?>
<html>
<body>
<table border="1" id="table" cellspacing="5" >
	<tr>
		<th>id</th>
		<th>title</th>
        <th>Message</th>
		<th>Date</th>
		<th>image1</th>
		<th>image2</th>
		<th>image3</th>
	    <th>Registration_link</th>
		<th></th>
		<th></th>
	</tr>		

<?php
for($i=0;$i<=$len;$i++){
	while($row=@mysqli_fetch_assoc($result)){
		$id=$row['id'];
		$title=$row['title'];
		$message=$row['message'];
		$date=$row['date'];
		$v1=$row['image1'];
		$v2=$row['image2'];
		$v3=$row['image3'];
		$v4=$row['reglink'];
?>

<form action="updateview.php?field=<?php echo $field.'&id='.$id;?>" method="POST">

<tr>
<td class="counterCell"><input type="hidden" name="id" value="<?php echo $id;?>"></td>
<td><input type="hidden" name="title" value="<?php echo $title;?>"><input name="title" value="<?php echo $title;?>"disabled>
</td>
<td><input type="hidden" name="message" value="<?php echo $message;?>"><input name="message" value="<?php echo $message;?>"disabled>
</td>
<td><input type="hidden" name="date" value="<?php echo $date;?>"><input name="date" value="<?php echo $date;?>" disabled>
</td>
<td><input type="hidden" name="v1" value="<?php echo $v1;?>"><input name="v1" value="<?php echo $v1;?>" disabled></td>
<td><input type="hidden" name="v2" value="<?php echo $v2;?>"><input name="v2" value="<?php echo $v2;?>" disabled></td>
<td><input type="hidden" name="v3" value="<?php echo $v3;?>"><input name="v3" value="<?php echo $v3;?>" disabled></td>
<td><input type="hidden" name="v4" value="<?php echo $v4;?>"><input name="v4" value="<?php echo $v4;?>" disabled></td>	<td><input type="hidden" value="edit" name="edit"> <input type="submit" value="edit"  name="edit"></td></form>
<td><a href="delete.php?field=<?php echo $field.'&id='.$id;?>"><input type="hidden" value="delete" 
name="delete"><input type="submit" value="delete" name="delete"></a></td></tr>
<?php }
}}
?>	
</table>
</body>
</html>