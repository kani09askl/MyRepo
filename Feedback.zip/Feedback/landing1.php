<!DOCTYPE html>
<html>
<head>
	<title>feedback</title>
</head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/landing.css">

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

<body background ="IMAGE\background.jpg" >
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="img\logo.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" align="center">Sasurie Feedback System</h1>
        </div>
      </li>
      </div>
  
</nav>

  
</head>

<body class="body">
<form>

  
   

    <div class="container">
  <div class="row" id="rowmain">
    
      <div class="col-sm-6">
        <div class="left">
        <div class="row">
    
          <button type="button" class="btn btn-warning" id="btn1"   onclick="location.href = 'principal/principal.php';"><p id="textt"> Principal</p></button>
  
        </div>
        <div class="row">
          <button type="button" class="btn btn-warning" id="btn3"   onclick="location.href = 'hod/login.php';"> <p id="textt">HOD</p></button>
        </div>
      </div>

      </div>



 

      <div class="col-sm-6">
        <div class="right">
      <div class="row">      
        <button type="button" class="btn btn-warning" id="btn3"   onclick="location.href = 'staff/login.php';"><p id="textt">Staff</p></button>
      </div>
      <div class="row">
        <button type="button" class="btn btn-warning" id="btn4"   onclick="location.href = 'Student/index.php';"><p id="textt">Student</p></button>
   
      </div>
        
      </div>


    </div>
  </div>
   
 </div>



   </form>
    
    </body>

    
    
    <style type="text/css">
.field-wrap
{
  margin-top:2%;
}
  #textt
  {
    font-family:bookman;
    font-size:30px;
  }
</style>

</body>
<script type="js/bootstrap.min.js"></script>
<script type="js/jquery.min.js"></script>

</html>