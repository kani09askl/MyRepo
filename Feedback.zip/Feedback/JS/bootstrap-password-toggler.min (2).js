/**
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2018, canchito-dev
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * @author 		Jose Carlos Mendoza Prego
 * @copyright	Copyright (c) 2018, canchito-dev (http://www.canchito-dev.com)
 * @license		http://opensource.org/licenses/MIT	MIT License
 * @link		https://github.com/canchito-dev/bootstrap-password-toggler
 * @link		http://canchito-dev/projects/bpt
 **/
!function(i){"use strict";var s=function(t,e){this.$element=i(t),this.options=i.extend(s.defaults,e),this.isVisible=!1,this.init(t,e)};function t(i){s.defaults.debug&&window.console&&window.console.log&&window.console.log(i.type+"."+i.namespace+": ",i)}s.defaults={append:"right",iconPrefix:"fa",iconShow:"fa-eye",iconHide:"fa-eye-slash",tooltip:"Show/Hide password",version:"1.0.1",debug:!1},s.prototype.init=function(s,t){this.$element.attr("type","password"),this.$element.wrap('<div class="input-group"></div>'),this.$icon=i(['<span class="input-group-text" title="'+this.options.tooltip+'"><i class="'+this.options.iconPrefix+" "+this.options.iconShow+'" aria-hidden="true"></i></span>'].join("")).css("cursor","pointer"),this.$icon.wrap((this.options.append,"prepend")),this.$icon.insertAfter(this.$element),this.bindEvents(),this.$icon.off("click").on("click",i.proxy(function(){this.toggle()},this))},s.prototype.toggle=function(){var i=this.isVisible?"hide":"show",t=this.isVisible?"hidden":"shown";this.$element.trigger(i+".bs.password"),this.isVisible?(this.$element.attr("type","password"),this.$icon.find("i").removeClass(s.defaults.iconHide).addClass(s.defaults.iconShow),this.$icon.find("svg").removeClass(s.defaults.iconHide).addClass(s.defaults.iconShow)):(this.$element.attr("type","text"),this.$icon.find("i").removeClass(s.defaults.iconShow).addClass(s.defaults.iconHide),this.$icon.find("svg").removeClass(s.defaults.iconShow).addClass(s.defaults.iconHide)),this.$element.trigger(t+".bs.password"),this.isVisible=!this.isVisible},s.prototype.bindEvents=function(){this.$element.on({"show.bs.password":function(i){t(i)},"shown.bs.password":function(i){t(i)},"hide.bs.password":function(i){t(i)},"hidden.bs.password":function(i){t(i)}})},i.fn.password=function(t){return this.each(function(){var e=i(this),o=i.extend(e.data(),t);e.data("bs.password",new s(e,o))}),this},i(function(){i('[data-toggle="password"]').password()})}(jQuery);