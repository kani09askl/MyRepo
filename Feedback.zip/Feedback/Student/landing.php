<?php
session_start();
$regno=$_SESSION["regno"];
$pword=$_SESSION["pword"];
$dept=$_SESSION["dept"];
$_SESSION["pword"]=$pword;
$_SESSION["regno"]=$regno;
$_SESSION["dept"]=$dept;
if($regno && $dept)
{
	//echo "session valid";
}
else{
   // echo "session doesnot valid";
}
//echo $pword;	
?>

<?php
$regno=$_SESSION["regno"];
$dept=$_SESSION["dept"];

$servername = "localhost";
$username = "root";
$password = "";
//echo $dept;
//echo $regno;

$con = mysql_connect($servername, $username, $password);

  
if (!$con) {
    die("Connection failed: " . mysql_connect_error());
}
//echo "Connected successfully";
 

$db=mysql_select_db("dept_details",$con)or die(mysql_error());
if($db)
{
	//echo "connected db";
}
if($dept=="eee")
{
	//echo "con";
	$str="SELECT * FROM student_eee where regno='$regno' ";
}
elseif($dept=="mech")
{
	//echo "connected";
	$str="SELECT * FROM student_mech where regno='$regno' ";
}
elseif($dept=="ece")
{
	//echo "disconnected";
	$str="SELECT * FROM student_ece where regno='$regno' ";
}

elseif($dept=="cse")
{
	//echo "disconnected";
	$str="SELECT * FROM student_cse where regno='$regno' ";
}
elseif($dept=="civil")
{
	//echo "disconnected";
	$str="SELECT * FROM student_civil where regno='$regno' ";
}
elseif($dept=="snh")
{
	//echo "disconnected";
	$str="SELECT * FROM student_snh where regno='$regno' ";
}

$result = mysql_query($str,$con);
if($result)
{
	//echo "connected result";
}
while($row=mysql_fetch_array($result))
{
$v1=$row['regno'];
$v2=$row['name'];
$v3=$row['sem'];
$v4=$row['dept'];
$v5=$row['year'];
$v6=$row['emailid'];
$v7=$row['phoneno'];
$_SESSION['sem']=$v3;
$_SESSION['year']=$v5;
$_SESSION['name']=$v2;
//echo $v3;
//echo $v5;
//echo $v2;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>feedback</title>
</head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/landing.css">

  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

<body>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="img\logo.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" align="center">Feedback </h1>
        </div>
      </li>
      </div>
  
</nav>

<script>
$(document).ready(function(){
    $("button").click(function(){
        $("#change").html("<form method='post' action='edit1.php'><div class='field-wrap'><label><span class='req'></span></label><input type='text' id='ttxxt' name='name' value='<?php echo $v2;?>' autocomplete='off'/></div><div class='field-wrap'><label><span class='req'></span></label><input type='text' id='ttxxt' name='regno'  value='<?php echo $v1;?>' autocomplete='off'/></div><div class='field-wrap'><label>  <span class='req'></span></label><input type='text' id='ttxxt' name='sem' value='<?php echo $v3;?>' autocomplete='off'/></div><div class='field-wrap'><label><span class='req'></span></label><input type='text' id='ttxxt' name='year' value='<?php echo $v5;?>' autocomplete='off'/></div><div class='field-wrap'><label><span class='req'></span></label><input type='text' id='ttxxt' name='dept' value='<?php echo $v4;?>' autocomplete='off'/></div><div class='field-wrap'><label><span class='req'></span></label><input type='text' id='ttxxt' name='emailid' value='<?php echo $v6;?>' autocomplete='off'/></div><div class='field-wrap'><label><span class='req'></span></label><input type='text'name='phoneno' value='<?php echo $v7;?>' id='ttxxt' autocomplete='off'/></div><div><button type='submit' class='btn' id='btn5'>Save</button></div></form>");
    });
});
</script>

  
  
  
  
</head>

<body class="body">


  
   

    <div class="container">
  <div class="row" id="rowmain">
    
      <div class="col-sm-3">
        <div class="left">
        <div class="row">
        <form action="edit1.php" method="POST">
    
          <button type="button" class="btn btn-warning" id="btn1"><a href="#"></a><img src="img/edit.png" id="feedback" ><p id="textt"> Edit</p></button>
  </form>
        </div>
        <div class="row">
          <button type="button" class="btn btn-warning" id="btn3"   onclick="location.href = 'feedback.php';"><img src="img/feedback.png" id="feedback" > <p id="textt">Feed Back</p></a></button>
        </div>
      </div>

      </div>


<div class="col-sm-6">
        <div class="center">
        <div id="change" >
          <div class="row">
            <div class="col-sm-3" id="left1">
             <h4> Name</h4>
            </div>
            <div class="col-sm-3" id="right1"> 
              <h4><?php echo $v2;?></h4>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-3" id="left1">
              <h4>Reg No</h4>
            </div>
            <div class="col-sm-3" id="right1">
              <h4><?php echo $v1;?></h4>
            </div>
          </div>
           <div class="row">
            <div class="col-sm-3" id="left1">
              <h4>semester</h4>
            </div>
            <div class="col-sm-3" id="right1">
              <h4><?php echo $v3;?></h4>
            </div>
          </div>      
          <div class="row">
            <div class="col-sm-3" id="left1">
              <h4>Year</h4>
            </div>
            <div class="col-sm-3" id="right1">
              <h4><?php echo $v5;?></h4>
            </div>
          </div> 
           <div class="row">
            <div class="col-sm-3" id="left1">
              <h4>Department</h4>
            </div>
            <div class="col-sm-3" id="right1">
              <h4><?php echo $v4;?></h4>
            </div>
          </div>        
          <div class="row">
            <div class="col-sm-3" id="left1">
              <h4>Email Id</h4>
            </div>
            <div class="col-sm-3" id="right1">
              <h4><?php echo $v6;?></h4>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-3" id="left1">
              <h4>Mobile No</h4>
            </div>
            <div class="col-sm-3" id="right1">
              <h4><?php echo $v7;?></h4>
            </div>
          </div>        
          <div class="row">
            <div class="col-sm-3" id="left1">
              <h4>Password</h4>
            </div>
            <div class="col-sm-3" id="right1">
              <h4>********</h4>
            </div>
          </div>        
       </div>
        </div>  
      </div>
 

      <div class="col-sm-3">
        <div class="right">
      <div class="row">      
        <button type="button" class="btn btn-warning" id="btn3"   onclick="location.href = 'password.php';"><img src="img/pswd.png" id="feedback" ><p id="textt">password</p></button></a>
      </div>
      <div class="row">
        <button type="button" class="btn btn-success" id="btn4"   onclick="location.href = 'logout.php';"><img src="img/logout1.png" id="out"><p id="textt">Log Out</p></button></a>
   
      </div>
        
      </div>


    </div>
  </div>
   
 </div>



   
    
    </body>

    
    
   <style type="text/css">
#ttxxt
{
  height:5%;
  width:100%;
}
.field-wrap
{
  margin-top:2%;
}
  #textt
  {
    font-family:bookman;
  }


.field-wrap {
  position: relative;
  margin-bottom: 40px;
}

.button:hover, .button:focus {
  background: #368a9f;
}

.button-block {
   margin-left:5%;
  width: 25%;
}



#feedback
{
  height:50px;
  width:50px;
  font-family:;


}
#edit
{
   height:50px;
  width:60px;
  
}
#out
{
 height:50px;
  width:60px;

  }
#pswd
{
height:50px;
  width:50px;

}

.left
{
  margin:2%;
  padding-left:25%;
  border-style:line;

   
}
.right
{
  margin:2%;
  padding-left:25%;

}
.center
{
  margin:1%;
  padding:10%;


}
#btn2 ,#btn3, #btn4,#btn1
{
  margin-top:15%;
  margin-bottom:15%;
  background-color:white;
  color:black;
  width:200px;
  height:13%;

}
#rowmain {
    margin-top: 5%;
  
    background-color:green;
    border-radius: 1%;
    box-shadow: 0px 0px 4px #47564C;
}
.body {
  background-color:white;
  
}


#myNavbar{
  text-align: center;
}
#text1{
  font-family: Bookman;
  font-style: inherit;
  font-size: 34px;
  text-shadow: 0px 1px 2px black;
  color:green;

}
#nav
{
  box-shadow: 0px 1px 3px green;
 padding: 20px; 
 background-color:yellow;
 border:none;  
}
.navbar-toggle
{
  background-color:yellow;
  box-shadow: 0px 1px 3px black;
  width: 30px;
  height: 30px;
}
#img1
{
  margin-left:-27%;
  margin-top:-27%;
  
  position: relative;

}

.text
{
  color:white;
}
#left1
{
margin-right:5%;
text-shadow: 0px 1px 1px yellow;
color:white;
}
#right1
{
padding-left:25%;
text-shadow: 0px 1px 1px yellow;
color:white;
}


a:hover {
  color: #179b77;
}

.form {

  padding:20px;
  box-shadow:0px 1px 1px 1px white;
    max-width: 400px;
  border-radius:2px;
  
  }
  
.tab-group .active a {
  background: #1ab188;
  color: #ffffff;
}

.tab-content > div:last-child {
  display: none;
}

label {
  position: absolute;
  -webkit-transform: translateY(6px);
          transform: translateY(6px);
  left: 13px;
  color:black;
  -webkit-transition: all 0.25s ease;
  transition: all 0.25s ease;
  -webkit-backface-visibility: hidden;
  pointer-events: none;
  font-size: 22px;
}

input, textarea {
  font-size: 22px;
  display: block;
  width: 100%;
  height: 100%;
  padding: 5px 10px;
  margin-top:1px;
  border-radius: 5px;
  
}
#btn5
{
  background-color:white;
  border-radius:5%;
  margin-left:40%;
}
#modify
{

}
</style>
</body>
<script type="js/bootstrap.min.js"></script>
<script type="js/jquery.min.js"></script>

</html>