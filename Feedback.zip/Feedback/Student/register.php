
<?php


if (isset($_POST["regno"])) {
$regno=$_POST['regno'];
$name=$_POST['name'];
$sem=$_POST['sem'];
$dept=$_POST['dept'];
$year=$_POST['year'];
$email=$_POST['emailid'];
$mob=$_POST['phoneno'];
$pass=$_POST['pword'];
$cpass=$_POST['cpword'];
}

$servername = "localhost";
$username = "root";
$password = "";


$con = mysql_connect($servername, $username, $password);


if (!$con) {
    die("Connection failed: " . mysql_connect_error());
	}
	//else echo "connection successful";
$db=mysql_select_db("dept_details",$con)or die(mysql_error());
if($dept=="cse"&&$pass==$cpass){
$str="insert into `student_cse` values('','$regno','$name','$dept','$year','$sem','$mob','$email','$pass')";
}
elseif($dept=="ece"&&$pass==$cpass){
$str="insert into `student_ece` values('','$regno','$name','$dept','$year','$sem','$mob','$email','$pass')";	
}
elseif($dept=="eee"&&$pass=$cpass){
	$str="insert into `student_eee` values('','$regno','$name','$dept','$year','$sem','$mob','$email','$pass')";
}
elseif($dept=="civil"&&$pass==$cpass){
	$str="insert into `student_civil` values('','$regno','$name','$dept','$year','$sem','$mob','$email','$pass')";
}
elseif($dept=="mech"&&$pass==$cpass){
	$str="insert into `student_mech` values('','$regno','$name','$dept','$year','$sem','$mob','$email','$pass')";
}
if($dept=="snh"&&$pass==$cpass){
$str="insert into `student_snh` values('','$regno','$name','$dept','$year','$sem','$mob','$email','$pass')";
}
else{
	echo "incorrect password";
}

$result = mysql_query($str,$con);


if ($result) { 
echo "<script type=\"text/javascript\">window.alert('Data Inserted successfully');
window.location.href = 'index.php';</script>"; 
}
else
{
echo "<script type=\"text/javascript\">window.alert('Error on inserting data');
window.location.href = 'registration.php';</script>"; 
}
?>
  
