<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;


//echo $pass;
//echo $name;


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dept</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="img/logo.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 class="text1" align="center">Feedback</h1>
        </div>
      </li>
      </div>
     
      <div class="icon-bar">
        <button= data-toggle="modal" data-target="#myModal"><i class="fa fa-user-circle-o"></i></button>
        <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <form action="dept.html" method="POST">
           <button type="button" class="close"></button><button type="button" class="close">&times;</button></form>
           <form action="logout.php" method="POST">
          <button type="submit" class="btn btn-primary">Logout</button></form>
        </div>
        <div class="modal-body"><form action="password.php" method="POST">
          <button type="submit" class="btn btn-primary">Change password </button> </form>      </div>
        <div class="modal-footer">
          
        </div>
      </div>
      </div>
    </div>
      </div>

  
</nav>
</header>

<div class="container-fluid">
  <div class="row">
   <?php 
    $subname=$_POST["subname"];
//$_SESSION["subname"]=$subname;
?>
    <h3>Subject Name:<?php echo $subname;?></h3>
  </div>
  
  <div class="row">
    <h2 >Student Feedback</h2>
  </div>
  
</div>

<div class="col-sm-5">

  
  <?php 
  $name=$_SESSION["staff name"];
  $dept=$_SESSION["dept"];
  $subname=$_POST["subname"];
  //echo $dept;
$servername = "localhost";
$username = "root";
$password = "";

$con=mysql_connect($servername,$username,$password);
if($con)
{
  //echo "connect con";
}
$db=mysql_select_db("dept_details",$con);
if($db)
{
  //echo "connected db";
}
$str="select * from feedback where staff_name='$name' and subname='$subname'";
if($str)
{
  //echo "connect str";
}
$tables=array("subdetails_cse","subdetails_ece","subdetails_eee","subdetails_civil","subdetails_mech","subdetails_snh");




$result=mysql_query($str,$con);
 
if($result)
{
  //echo "connected result";
}



?>

<body>
  <div class="scroll-table-container">
      <table class="scroll-table">
       <tr class="row1">
  
  <td>Feedback</td>
</tr>



  <?php
while($row=mysql_fetch_array($result)){
  $feed=$row["feedback"];

?>

  <tr>
  <td><?php echo $feed;?></td>
  </tr>
  <?php
}
?>

      </table>
    </div>
	

    <div class="form-group" >
           <label for="comment" id="tt">Hod Feedback</label>
           
           <textarea class="form-control" name="feedback" rows="10" id="comment" required="text"><?php 
      $len=sizeof($tables);

for($i=0;$i<$len;$i++){

$str1="SELECT * FROM $tables[$i] where staffname='$name' AND subname='$subname'";


 $result1=mysql_query($str1,$con);

 while($row=mysql_fetch_array($result1))
{
$princ=$row['principal_msg'];
$hod=$row['hod_msg'];
 //echo $hod;
}}?>
</textarea>
        </div>
    <div class="form-group" >
            <label for="comment" id="tt">Principal Feedback</label>
           <textarea class="form-control" name="feedback" rows="10" id="comment" required="text"><?php 
      $len=sizeof($tables);

for($i=0;$i<$len;$i++){

$str1="SELECT * FROM $tables[$i] where staffname='$name' AND subname='$subname'";


 $result1=mysql_query($str1,$con);

 while($row=mysql_fetch_array($result1))
{
$princ=$row['principal_msg'];
$hod=$row['hod_msg'];
 //echo $princ;
}}?> 
</textarea>

		   
        </div>
		
   


<div class="row">
 <div > 
 <a href="change.php">   
 <input type="button" value="BACK" class="btn btn-primary" id="ba"></a></div>
</div>
</div>
</body>

</html>
<style>
      .scroll-table-container {box-shadow:0px 0px 3px green; height: 300px; overflow: scroll;margin-top:10%;
        margin-left:30%; width:900px;}
      .scroll-table, td, th{border-collapse:collapse; border:1px solid #777; min-width: 900px;}
    </style>
<style>
#tt
{
  margin-left:25%;
  font-size:20px;
  margin-top:5%;
}
#comment
{
  margin-left:50%;
  width:120%;
  box-shadow: 0px 0px 3px green; 
}
body
{
 background-color:;
}
#btn3
{
  margin-left:10%;
}
 #usr
    {
      color:black;
        padding-top: 55px;
        text-shadow: 0px 0px 1px black;
   }
    #pwd
    {
      color:black;
      padding-top:30px;
      text-shadow: 0px 0px 1px black;
    }
    #log
    {
      padding-top: 30px;
      padding-bottom: 15px;
    }

    #main
    {
      background-color: #b3ffe0;
      margin-top: 40px;
        font-size: 20px;
        border-radius:15px;
        box-shadow: 0px 0px 8px white;
    }
    #clr
    {
      font-size: 40px;
      color:#003300;
    }
    #box1
   {
      border-radius: 4px;
    font-size: 15px;
    border: none;
    box-shadow: 0px 0px 1px white;
    height: 30px;
    text-align: center;
    width: 200px;
    color: black;
    margin-left:50px;
   }
   #box2
   {
      border-radius: 4px;
    font-size: 15px;
    border: none;
    box-shadow: 0px 0px 1px white;
    height: 30px;
    text-align: center;
    width: 200px;
    color: black;
    margin-left: 40px;
   }
   #box3
   {
      border-radius: 4px;
    font-size: 15px;
    border: none;
    box-shadow: 0px 0px 1px white;
    height: 30px;
    text-align: center;
    width: 200px;
    color: black;
    margin-left: 5px;
   }

   #row
   {
    width:300px;
    height: 40px;
    color:#fff;
   }
   .img-circle
   {
  
    margin-left:120%;
    margin-top:-5%;
   }
   #nav
{
  box-shadow: 0px 0px 5px #caefca;
 padding: 20px; 
background-color: #66d9ff;
 border:none;  
}
.navbar-toggle
{
  background-color:#c9e6c9;
  box-shadow: 0px 0px 3px #c9e6c9;
  width: 30px;
  height: 25px;
}
#img1
{
  margin-left:-27%;
  margin-top:-27%;
  width: 100%;
  position: relative;

}
.fa
{
 float:right;
 font-size:50px;
 margin-top:-5%;

}

.icon-bar a {
    
    
    text-align: center;
    padding: 12px 0;
    transition: all 0.3s ease;
    color: white;
    font-size: 36px;
}
.row
{
  margin-top:10px;
  margin-left:15%;
}
.table
{
 border-radius:2%;

}
.row1
{
  text-align:center;
}
#table
{
  margin-left:30%;
  margin-top:5%;
}

#ba
{
  margin-left:115%;
  margin-top:5%;
  color:white;
  font-size:18px;
}
</style>