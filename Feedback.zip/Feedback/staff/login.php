<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Staff Login Form</title>
 <link rel="stylesheet" href="css/style.css">
</head>
<body>
<form method="POST" action="login1.php">
	<link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,700' rel='stylesheet' type='text/css'>
	<div class="container">
		<div class="profile">
    <button class="profile__avatar" id="toggleProfile">
     <img src="logo1.png" id="img" alt="Avatar">
 </button>
<div class="profile__form">
      <div class="profile__fields">
        <div class="field">
        	<div class="row">
        		<div class="col-sm-12">
        			<h3 id="text"> <center>Login to Faculty</center></h3></div></div>
          <input type="text" name="name" id="fieldUser" class="input" required pattern=.*\S.* />
          <label for="fieldUser" class="label" id="box">Username</label>
        </div>
        <div class="field">
          <input type="password" name="pass" id="fieldPassword" class="input" required pattern=.*\S.* />
          <label for="fieldPassword" class="label">Password</label>
        </div>
        <div class="profile__footer">
          <a href="login1.php">
          <button class="btn">Login</button></a>
        </div>
      </div>
     </div>
  </div>
</div>
  
  

    <script  src="js/index.js"></script>



</form>
</body>

</html>



<style>
#text
{
	font-family:andalus;
}
</style>