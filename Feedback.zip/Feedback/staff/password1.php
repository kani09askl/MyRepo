<?php

session_start();
$username=$_SESSION["name"];
$password=$_SESSION["pass"];
$_SESSION["name"]=$username;
$_SESSION["pass"]=$password;


//echo $username;
//echo $password;
?>  

<?php

$oword=$_POST['oword'];
$npass=$_POST['npass'];
$cpass=$_POST['cpass'];




$servername = "localhost";
$username = "root";
$password = "";


$con = mysql_connect($servername, $username, $password);
if($con){
	//echo "connected";
}


$db=mysql_select_db("complaint",$con)or die(mysql_error());
if($db){
	//echo "db";
}

//echo $_SESSION["pass"];
//echo $oword;
if($oword==$_SESSION["pass"]){
	//echo "connected oword";
if( $npass==$cpass){
	//echo "connected cse";
	$str="update staff_main set password='$npass' where password='$oword'";
	$_SESSION["pass"]=$npass;
}

$result=mysql_query($str,$con);
if($result)
{
	//echo "connected result";
}


if($result) { 
echo "<script type=\"text/javascript\">window.alert('successfully password changed');
window.location.href = 'password.php';</script>"; }
else{
echo "<script type=\"text/javascript\">window.alert('invalid password');
window.location.href = 'password.php';</script>"; 
}

}
else{
	echo "<script type=\"text/javascript\">window.alert('invalid oldpassword');
window.location.href = 'password.php';</script>"; }


?>