<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;


//echo $pass;
//echo $name;


?>

<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <script src="js/jquery.min.js"></script>
  <script src="js/1.min.js"></script>
  <link rel="stylesheet" href="css/login.css">
  <style>
  #container{
width:100%;
height:78%;
background-color:lightblue;
border-radius: 10px;
border-color:black;
  }
  #imge{
     background-color: white;
  }
 #pading{
  margin-left: 180px;
  margin-top: 45px;
 }
 #paddind{
  padding-left: 103px;
  padding-top: 10px;
 }
 #padding{
  padding-top: 10px;
  padding-left: 103px;
 }
 #paddins{
  padding-top: 10px;
  padding-left:93px;
 }
 #button{
  width:140px;
 }
 #buton1{
   width:140px;
 }
 #color{
  background-color:#c8c1c7;
  height:95%;
  
  border-radius: 10px;
 }
 #text{
  color:#050726;
  padding-right:25px;
  font-size: 35px;

 }
 #img1{
  width:`15px;
 }

                                                                                                                          
#img1{
  height:160px;
}
.popup {
    position: relative;
    display: inline-block;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* The actual popup */
.popup .popuptext {
    visibility: hidden;
    width: 150px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 8px 0;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left:-70%;
    margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left:90%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}
.text{
  padding-left:94px;
    margin-left: 30px;
}


.popup .show {
    visibility: visible;
    -webkit-animation: fadeIn 1s;
    animation: fadeIn 1s;
}


@-webkit-keyframes fadeIn {
    from {opacity: 0;} 
    to {opacity: 1;}
}

@keyframes fadeIn {
    from {opacity: 0;}
    to {opacity:1 ;}
}
#popup2{
  margin-bottom:-5px;
}
.img-circle
{
  background-color: #0
}
#cn{
  width:90%;
}
#daa{
  width:140px;
  
  
  margin-top: 15px;
}
#font{
  font-size: 10px;
}
#text1{
  font-size: 28px;
}
</style>
</head>
<body  id="imge">
<header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="image\logo.png" id="img1"></a>
    </div>
    </div>
    <div style="width: 100%;" class="collapse navbar-collapse" id="myNavbar">
      <ul style="width: 100%;" class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" style="font-size: 30px;">Sasurie Feedback System</h1>
        </div>
      </li>
       <li style="padding-left: 60%;"><div class="popup" onclick="myFunction()" id="popup2"><img src="download.jpg" class="img-circle" alt="Cinque Terre" width="45" height="45">
  <span class="popuptext" id="myPopup"><a href="logout.php"><button type="button" class="btn btn-primary" id="font">Logout</button></a>
    <a href="password.php">
   <button type="button" class="btn btn-primary" id="font">Change Psw </button></a></span>
</div></li>
      </div>
     
  
</nav>
</header>
<div class="container">
<div class="row">
    <div class="col-sm-3"></div>
<div class="col-sm-6" id="color">
 
  <p id="text"><center><h3 id="text">Pick Subject</h3></center></p>
<?php

$mail=$_SESSION["name"];
$tables=array("subdetails_cse","subdetails_ece","subdetails_eee","subdetails_civil","subdetails_mech","subdetails_snh");

$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$con = mysql_connect($servername, $username, $password);
if (!$con) {
    die("Connection failed: " . mysql_connect_error());
}
//echo "Connected successfully";
 
$db=mysql_select_db("complaint",$con)or die(mysql_error());
if($db)
{
  //echo "connected db";
}
$str="SELECT * FROM staff_main where emailid='$mail' AND password='$pass'";
if($str)
{
  //echo "connected str";
}
$result = mysql_query($str,$con);
if($result)
{
 // echo "connected result";
}
while($row=mysql_fetch_array($result)){

$name=$row["staff_name"];
$dept=$row["dept"];
$_SESSION["staff name"]=$name;
$_SESSION["dept"]=$dept;

}

$db1=mysql_select_db("dept_details",$con)or die(mysql_error());
if($db1)
{
 // echo "connected db1";
}
$len=sizeof($tables);

for($i=0;$i<$len;$i++){

$str1="SELECT * FROM $tables[$i] where staffname='$name' AND dept='$dept'";


 $result1=mysql_query($str1,$con);

 while($row=mysql_fetch_array($result1))
{
$subname=$row["subname"];


 ?> 
      <form action="tabfeed.php" method="post">
        <center> <input type="hidden"
         value="<?php echo $subname ;?>" name="subname" class="btn btn-primary" id="cn" style="position: center"></center><br />
        <center> <input type="submit"   name="subname" value="<?php echo $subname; ?>"class="btn btn-primary" id="cn" style="height: 60px; position: center"></center><br />
</form>
<?php 
}
}
 ?> 

   </div>
  <div class="col-sm-3"></div>
    
  </div>


<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>

        
  </div>
  
 
</body>
<script>

function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
</script>
 
<script  src="js/index.js"></script>
<script  src="js/style.js"></script>
<script  src="js/jquary.min.js"></script>
<script  src="js/style.js"></script>
</html> 

