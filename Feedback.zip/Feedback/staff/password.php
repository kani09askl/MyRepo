<?php

session_start();
$username=$_SESSION["name"];
$password=$_SESSION["pass"];
$_SESSION["name"]=$username;
$_SESSION["pass"]=$password;
//$_SESSION["subname"]=$subname;

//echo $username;
//echo $password;
?>  
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <script src="js/jquery.min.js"></script>
  <script src="js/1.min.js"></script>
  <link rel="stylesheet" href="css/login.css">
  <style>
  #con{
    background-color:#c8c1c7;
    
  height:500px;
  border-radius: 10px;
  }
   #name1{
    padding-top:125px;
    margin-left:-10px;

  }
  
  #name2{
    margin-left:-10px;
    padding-top: 190px;
  }
  #name3{
    padding-top:240px;
    margin-left:-10px;
  }
 
  #name{
    margin-top:40px;
    width:200px;
    margin-left: 270px;
    
  }
  #names{
  
  height:30px;
  background-color: white;
  
  margin-top: 130px;
  border-radius: 5px;
  font-size: 15px;
  margin-right:0px;
  }
  #namess{
   
  height:30px;
  background-color: white;
 
  margin-top: 40px;
   border-radius: 5px;
    font-size: 15px;
  }
  #namesss{
    
  height:30px;
  background-color: white;
  
  margin-top: 50px;
   border-radius: 5px;
    font-size: 15px;
  }
  #re{
    padding-right:10px;
  }
  #bt5{
    background-color:#8d7086;
    margin-top:70px;
    border-radius: 10px;
    padding-right:25px;

  }
  #imge{
     background-color:#e8d5dd;
  }
  #name0{
    margin-right: 60px;
  }
  #nemea{
    margin-right: 60px;
  }
  #ba
  {
    margin-left:45%;
  }
  #text
  {
    font-size:18px;
    color:white;
  }
</style>
</head><body>
  <body  id="imge">
<header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="image\logo.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" align="left">Sasurie Feedback System</h1>
        </div>
        
  
</nav>
</header>
<form method="POST" action="password1.php">
<div class="container">
  <div class="row">
    <div class="col-sm-2"></div>
<div class="col-sm-8" id="con">
<div class="col-sm-2"></div>
<div class="col-sm-2">    
  <label for="NAME" id="name1"><b>Old PSW  </b></label><br />
  <label for="Reg_no" id="name2"><b>New PSW  </b></label><br />
  <label for="Department " id="name3"><b>Confirm Password </b></label><br />
</div>
<div class="col-sm-5">
     <input type="password" name="oword" placeholder="EnterYour old Password" name="Name" id="names" style="color:black"required >
    


<input type="password" name="npass" placeholder="EnterYour new password" name="Regno" id="namess"  id="re" style="color:black" required >

      
      
      <input type="password" name="cpass" placeholder="Repeat password" name="Dept"  id="namesss"  style="color:black" required>
   </div>
      <a href="password1.php">
      <button type="submit" style="font-size:15px;;color:black;;;" class="button button-block" id="bt5">SAVE</button></a>
      
</div>

<div class="col-sm-2"></div>
</div>
</div>
</form>

 <div class="col-sm-12">    
 <button class="btn btn-primary" id="ba"><a href="change.php" id="text">BACK</a></button>
</div>
</body>
</html>


