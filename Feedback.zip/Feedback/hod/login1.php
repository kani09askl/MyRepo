<?php
if(isset($_POST['name']))
{
    $name=$_POST['name'];
	$pass=$_POST['pass'];

//echo $name;
//echo $pass;
$servername = "localhost";
$username = "root";
$password = "";


$con = mysql_connect($servername, $username, $password);



if (!$con) {
    die("Connection failed: " . mysql_connect_error());
	}
	//echo "connection successful";
 
	
$db=mysql_select_db("complaint",$con)or die(mysql_error());

$query=mysql_query("select * from staff_main where emailid='$name' and password='$pass'");
}
?>


<?php 
session_start();

$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;


	
	
	if(mysql_num_rows($query)==1)
	{
		header('location:option.php');
		exit();
	}
	
else
{
	echo "<script type=\"text/javascript\">window.alert('invalid username or password');
window.location.href = 'login.php';</script>"; 

}	
	
?>