<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];


	$_SESSION["name"]=$name;

	$_SESSION["pass"]=$pass;
	//echo $_SESSION["pass"];
if($name &&$pass)
{
	//echo "session valid";
}
else
{
	//echo "session does not valid";
}

?>

<?php

$oword=$_POST['oword'];
$npass=$_POST['npass'];
$cpass=$_POST['cpass'];
//echo $oword;

//echo $npass;

//echo $cpass;




$servername = "localhost";
$username = "root";
$password = "";


$con = mysql_connect($servername, $username, $password);
if($con){
	//echo "connected con";
}


$db=mysql_select_db("complaint",$con)or die(mysql_error());
if($db){
	//echo "db";
}
if($oword==$_SESSION["pass"])
{
	//echo "connected oword";
	if($npass==$cpass)
	{
		//echo "connected password";
		$str="update staff_main set password='$npass' where password='$oword'";
		$_SESSION["pass"]=$pass;
		
		$result=mysql_query($str,$con);
	}
		
		
		

if ($result) { 
echo "<script type=\"text/javascript\">window.alert('successfully password changed');
window.location.href = 'password.php';</script>"; }
else{
echo "<script type=\"text/javascript\">window.alert('invalid password');
window.location.href = 'password.php';</script>"; 
}

}

else{
	echo "<script type=\"text/javascript\">window.alert('invalid oldpassword');
window.location.href = 'password.php';</script>"; }

	




?>