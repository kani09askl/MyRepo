<?php
$staffname=$_POST["subname"];
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;
$_SESSION["subname"]=$staffname;


if($name && $pass)
{
  //echo "session valid";

}
//echo $name;
//echo $pass;
?>
<?php

$dept=$_SESSION["dept"];
$_SESSION["dept"]=$dept;

//echo $staffname;
$set=explode("-",$staffname);

 //echo $set[0];
 //echo $set[1];
 $dbhost = "localhost";
   $dbuser = "root";
   $dbpass = "";

   $con = mysql_connect($dbhost, $dbuser, $dbpass);
   $db=mysql_select_db("dept_details",$con)or die(mysql_error());
   if($db)
   {
  //echo "connected";
   }
   
   if(! $con ) {
      die('Could not connect: ' . mysql_error());
      }
    //echo "connection successful";
    
$str= "SELECT *FROM  feedback where staff_name='$set[0]' AND subname ='$set[1]' AND dept='$dept'";
if($str)
{
  //echo "con str";
  
}
$result=mysql_query($str,$con);
if($result)
{
  //echo "connected result";
}

?>  

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
   <script src="js/jquery.min.js"></script>
  <script src="js/1.min.js"></script>
  <link rel="stylesheet" href="css/login.css">
  <style>

  body{
    background-image: url("images/ss.jpg");
    background-repeat: no-repeat;
  
  }
  #table
{
  margin-left:10%;
  margin-top:15%;
  font-size:20px;
  
}
.table{
  border-color: white;
}
#st
{
  margin-top:-10px;
  padding-left:70px;
  font-size:20px;
}
#sub
{
  margin-top:-10px;
  font-size:18px;
  padding-left:30px;
}
#sno
{
  padding-left:30px;
  font-size:20px;
  padding-right:30px;
}
#feed
{
  padding-left:200px;
  font-size:20px;
  padding-right:200px;
}
#sug
{
  color:black;
  font-size:20px;

  margin-top:2px;
  
}
#comment
{
  font-size:20px;
  margin-left:-30%;
  background-color:#f7e5b9;
}
#submit
{
  margin-left:-1150px;
  background-color:#605e5a;
  margin-top:33%;
}
.red{

  font-size: 30px;
  margin-top:40%;
}
.staff{
  color:white;
  font-family: Gabriola;
  font-size: 30px;
  padding-top:-10px;
}
.font{
  color:#f4f4e6;
  font-size: 20px;
}
#nav{
  background-color:#eae4de;
}
.area{
  background-color:red;
}

.popup {
    position: relative;
    display: inline-block;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* The actual popup */
.popup .popuptext {
  
    visibility: hidden;
    width: 120px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 8px 0;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left:93%;
    margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left:85%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}
.text{
  padding-left:94px;
}


.popup .show {
    visibility: visible;
    -webkit-animation: fadeIn 1s;
    animation: fadeIn 1s;
}


@-webkit-keyframes fadeIn {
    from {opacity: 0;} 
    to {opacity: 1;}
}

@keyframes fadeIn {
    from {opacity: 0;}
    to {opacity:1 ;}
}
#popup2{
  margin-bottom:-5px;
}
.img-circle
{
  background-color: #000;
}
#text1{
  font-size:30px;
}

.row1
{
  text-align:center;
}
#table
{
  margin-left:30%;
  margin-top:-1%;
  background-color:white;
}
#text{
color:black;
}
#new
{
  font-family: bookman;

}
</style>

</head>
<body  id="imge">
<header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="logo.png" id="img1"></a>
    </div>
 </div>
    <div style="width: 100%;" class="collapse navbar-collapse" id="myNavbar">
      <ul style="width:100%;" class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" >Sasurie FeedBack System</h1>
        </div>
         <li style="padding-left:55%;"><div class="popup" onclick="myFunction()" id="popup2"><img src="download.jpg" class="img-circle" alt="Cinque Terre" width="45" height="45">
  <span class="popuptext" id="myPopup"><a href="logout.php"><button type="button" class="btn btn-primary" id="font">Log out</button></a>
      
      </div>
     
  
</nav>

<body>
  <form method="POST" action="update.php">
  <div class="container">
  <div class="row">
    <div class="col-sm-2">
    </div>
    <div class="col-sm-8">
      <div class="col-sm-6" id="st">
   <p class="staff"> Staff name: <?php echo $set[0];?></p></div>
    <div class="col-sm-6" id="sub">
    <p class="staff">Subject name:<?php echo $set[1];?></p></div>
    <div class="row">
    
  </div>
  
</div>


 </div>
    
</div>


<div class="col-sm-3" id="div3">
  <!--<h2 id="new"><b>Feedback</b></h2>-->
  <div class="scroll-table-container">
      <table class="scroll-table">
        <thead>
          <tr>
            <th style="font-size: 20px;"><center>Feedback</center></th>
          </tr>
          <?php
while($row=mysql_fetch_assoc($result))
    {
     // echo "connected while";
      $feed=$row['feedback'];
      ?>

          
    <tr>
    <td style="color:white"><?php echo $feed;?></td>
          </tr>
          <?php
          }
          ?>
        </thead>
        <tbody>

          </tbody>
      </table>
    </div>

</div>

  <div class="col-sm-6" id="sug">
   <p class="red">Suggession</p>
      <textarea class="form-control" rows="3" id="comment"  name="suggest"></textarea>
    </div>
    <div class="col-sm-3">
        
       <center><button type="submit" class="btn btn-primary" id="submit">SUBMIT</button></form>
       </center>
      
        <div class="col-sm-3">
        
       <center><button type="submit" class="btn btn-primary" id="submit">BACK</button></form>
       </center>
        </div>
          </div>
        <div class="col-sm-2"></div>
      </div></div>
      <script>function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
</script>
 
<script  src="js/index.js"></script>
<script  src="js/style.js"></script>
<script  src="js/jquary.min.js"></script>
<script  src="js/style.js"></script>



</body>
<style type="text/css">
   .scroll-table-container {box-shadow:0px 0px 3px green; overflow:scroll;margin-top:10%;
        margin-left:30%; width:800px;height:20%;}
      .scroll-table, td, th{border-collapse:collapse; border:1px solid #777; min-width: 900px;}  #div3
      {
      margin-left:15%;

      }
</style>