<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$dept=$_SESSION["dept"];
$_SESSION["dept"]=$dept;
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;
if($name && $pass)
{
  //echo "session valid";

}
//echo $name;
//echo $pass;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <script src="js/jquery.min.js"></script>
  <script src="js/1.min.js"></script>
  <link rel="stylesheet" href="css/login.css">
  <style>
  body{
  background-image:url("image/014.png"); 

  }
  
#circle{
	

height:250px;
border-radius: 10px;
margin-top: 70px;
background-image:url("image/00.jpg"); 
}
#bt{
	background-color:black; 
	color:red;
	border-radius:5px;
	font-size:15px;
	width:100px;
	height:30px;
	padding-top:5px;
  margin-left:20%;
  margin-top:65px;


  

}
#option{
	color:red;
	font-size:15px;
	border-radius:5px;
  width:40%;
  height:15%;
}
#nav1{
  box-shadow: 0px 0px 10px black;
 padding: 20px; 
 background-color:#d1cba9;
 border:none;  
background-image: url("image/.jpg");
}
body{
	background-image: url("image/73.jpg");


 
}
.popup {
    position: relative;
    display: inline-block;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* The actual popup */
.popup .popuptext {
    visibility: hidden;
    width: 150px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 8px 0;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left:-70%;
    margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left:90%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}
.text{
  padding-left:94px;
}


.popup .show {
    visibility: visible;
    -webkit-animation: fadeIn 1s;
    animation: fadeIn 1s;
}


@-webkit-keyframes fadeIn {
    from {opacity: 0;} 
    to {opacity: 1;}
}

@keyframes fadeIn {
    from {opacity: 0;}
    to {opacity:1 ;}
}
#popup2{
  margin-bottom:-5px;
}
.img-circle
{
  background-color: #000;
}

#sub{
  margin-top: 50px;
  background-color: black;
  font-color:red;
  border-radius: 6px;
}
#font{
  font-size: 10px;
}
#text1{
  font-size: 30px;
}
</style>
</head>

	<body  id="imge">
   
<header>
<body  id="imge">
<header>
<nav class="navbar navbar" id="nav1">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="logo.png" id="img1"></a>
    </div>
    </div>
    <div style="width: 100%;" class="collapse navbar-collapse" id="myNavbar">
      <ul style="width: 100%;" class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1">Sasurie FeedBack System</h1>
        </div>
      </li>
       <li style="padding-left: 60%;"><div class="popup" onclick="myFunction()" id="popup2"><img src="download.jpg" class="img-circle" alt="Cinque Terre" width="45" height="45">
      
  <span class="popuptext" id="myPopup"> <a href="logout.php"><button type="button" class="btn btn-primary" id="font">Log out</button></a>
    <a href="password.php">
   <button type="button" class="btn btn-primary" id="font">Change Psw </button></a></span>
</div></li>
      </div>
     
  
</nav>
</header>
 <form action="submit.php" method="POST">
<div class="contaoiner">
  <div clas="row">
    <div class="col-sm-4"></div>

<div class="col-sm-4" id="circle" >
	
		 	<center></center><div class="dropdown" id="submit">
  <button type="submit" class="button" id="bt">SEMESTER</button>
             
  <select class="select" id="option" required="required" name="sem">
  <option></option>  
  <option>I</option>
  <option>II</option>  
  <option>III</option>  
  <option>IV</option>
  <option>V</option>
  <option>VI</option>
  <option>VII</option>
  <option>VIII</option>
</select>
 </div></button></center>
	
    <center><button type="submit" class="btn btn-primary" id="sub">Submit</button></center></a>
  </div>
  </div>
		<div class="col-sm-4"></div>
	</div>
</div>
</form>
</body>
<script>function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
</script>
 
<script  src="js/index.js"></script>
<script  src="js/style.js"></script>
<script  src="js/jquary.min.js"></script>
<script  src="js/style.js"></script>


</html>