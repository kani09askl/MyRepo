<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>HOD login</title>
	<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700|Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/style.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
</head>

<body>
	<form action="login1.php" method="POST">
	<div class="container">
		<div class="row">
		<div class="col-sm-12" style="align-content: center;"><div class="img"><center><img src="logo.png"></center></div></div></div>
			<div class="row1"><h1 id="title" class="hidden"><span id="logo">Welcome Head of Department</span></h1></div>
		
		<div class="login-box animated fadeInUp">
			<div class="box-header">
				<h2>Log In</h2>
			</div>
			<label for="username">Username</label>
			<br/>
			<input type="text" id="username" name="name">
			<br/>
			<label for="password">Password</label>
			<br/>
			<input type="password" id="password" name="pass">
			<br/>
			<a href="login1.php">
			<input type="submit" value="Sign In" name="submit" id="sub"></a>
			<br/>
			
		</div>
	</div>
</form>
</body>

</html>




<style>
#sub
{
	height:40px;
	width:90px;
	background-color: #665851;
	color:white;
}
.login-box 
{
	margin-top: 20px;
}

