<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$dept=$_SESSION["dept"];
$arrayvalue=$_SESSION['n'];

$sta=$_SESSION['staffname'];
$subb=$_SESSION["subname"];
$department=$_SESSION["department"];

//print_r($department);
//echo $sta;
//echo $subb;

if($name && $pass)
{
 // echo "session valid";

}



?>
<?php

 echo $dept;
$staffname=array();
$subject=array();

	

$tables=array("subdetails_cse","subdetails_ece","subdetails_eee","subdetails_civil","subdetails_mech","subdetails_snh");
$len=sizeof($tables);

$servername = "localhost";
$username = "root";
$password = "";

$con=mysql_connect($servername,$username,$password);
if(!$con)
{
	die("connection failed:".mysql_connect_error());
}

echo "Connected successfully";
 
$db=mysql_select_db("dept_details",$con)or die(mysql_error());

if($db)
{
	echo "connected db";
}
$i=0;
$j=0;

for($i=1,$j=0;$i<=$arrayvalue;$i++,$j++)
{
	echo $j;
	$staffname[$i]=$_POST[$i];
	$subject[$i]=$_POST['sub'.$i];
	//echo $department[$j];
	//echo $sta[$j];
	//echo $subb[$j];
	//echo $staffname[$i];
	//echo $subject[$i];
	//echo $sta[$j];
	//echo $subb[$j];

//var_dump($subject);
//var_dump($staffname);
	//var_dump($department);
	// $str="UPDATE subdetails_cse set staffname='$staffname[$i]',subname='$subject[$i]' where dept='$department[$j]' and staffname='$sta[$j]' and subname='$subb[$j]'";
	 $str="update subdetails_cse set staffname='nikithaji' ,subname='computer networking' where staffname='nikitha' and subname='evs' and dept='cse'";
	 if($str)
	 {
	 	echo "connected str";
	 }
	//echo $str;

if($dept=="CSE")
{
$str="UPDATE subdetails_cse set staffname='$staffname[$i]',subname='$subject[$i]' where dept='$department[$j]'";
//echo "$str";
//echo $department[$j];

}
if($dept=="ece")
{
	$str="UPDATE subdetails_ece set staffname='$staffname[$i]' subname='$subject[$i]'";
}
if($dept=="eee")
{
	$str="UPDATE subdetails_eee set staffname='$staffname[$i]' subname='$subject[$i]'";
}

if($dept=="civil")
{
	$str="UPDATE subdetails_civil set staffname='$staffname[$i]' subname='$subject[$i]'";
}
if($dept=="mech")
{
	$str="UPDATE subdetails_mech set staffname='$staffname[$i]' subname='$subject[$i]'";
}
if($dept=="snh")
{
	$str="UPDATE subdetails_snh set staffname='$staffname[$i]' subname='$subject[$i]'";
}

}

$result=mysql_query($str,$con);
if($result)
{
  echo "connected result";
}

/*if ($result) { 

echo "<script type=\"text/javascript\">window.alert('updated successfully');
window.location.href = 'staffalocation1.php';</script>"; 
}
else
{
echo "<script type=\"text/javascript\">window.alert('Error on updating');
window.location.href = 'update1.php';</script>"; 
}*/
?>