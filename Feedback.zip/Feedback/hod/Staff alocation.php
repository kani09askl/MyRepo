<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$dept=$_SESSION["dept"];

$_SESSION["dept"]=$dept;
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;
if($name && $pass)
{
  //echo "session valid";

}
//echo $name;
//echo $pass;
?>
<?php
$tables=array("subdetails_cse","subdetails_ece","subdetails_eee","subdetails_civil","subdetails_mech","subdetails_snh");
$len=sizeof($tables);

$department=array();
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$con = mysql_connect($servername, $username, $password);
if (!$con) {
    die("Connection failed: " . mysql_connect_error());
}
//echo "Connected successfully";
 
$db=mysql_select_db("dept_details",$con)or die(mysql_error());
if($db)
{
  //echo "connected db";
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>hod staff alocation </title>
</head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">


  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <header>
      <nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="logo.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" align="center">Feedback </h1>
        </div>
      </li>
      </div>
  
</nav>

  </header>
  
<body id="body">
<form action="staffalocation1.php" method="post">

<div class="container">
<table width="80%" height="500px" id="table">
  <tr>
    <th>Staff Name</th>
    <th>Subject Name</th>
  </tr> 
  <?php
  $department=array();
  $j=1;
  $k=0;
             for($i=0;$i<$len;$i++)
               {
               $str=mysql_query("select * from $tables[$i] where dept='$dept'",$con);
               if($str)
    
               {
      //echo "connected str";
               }
            while($row=mysql_fetch_array($str))
          {
            //array_push($department,$row['dept']);
            $department[$k]=$row['dept'];
            //echo $department[$k];
            
          $staff=$row['staffname'];
          $sub=$row['subname'];
          $_SESSION['staffname']=$staff;
          $_SESSION['subname']=$sub;

          //echo $_SESSION['subname'];
          //echo $_SESSION['staffname'];
          $j=$j+1;
           $k=$k+1;

          ?>
          
         <tr>   
        <td><?php echo $staff;?></td>
        <td><?php echo $sub;?></td>

  </tr>
  <?php
  }
   }
  
  $_SESSION['department']=$department;
  ?>
</table>  
</div>
</form>
<div
>
  <a href="option.php"><button id="btn1" class="btn-warning">Back</button></a>
</div>

</body>
</html>
<style type="text/css">
#body{
  background-color:lightgreen;
}
#table{
  margin-left:10%;
}	
#btn1
{
margin-top:2%;
margin-left:45%;
width:8%;
height:45px;
border-radius:5em;
}
#table td,#table th{
  padding-left:15%;
  font-size:30px;
}



#myNavbar{
  text-align: center;
}
#text1{
  font-family: Bookman;
  font-style: inherit;
  font-size: 34px;
  text-shadow: 0px 1px 2px black;
  color:green;

}
#nav
{
  box-shadow: 0px 1px 3px green;
 padding: 20px; 
 background-color:yellow;
 border:none;  
}
.navbar-toggle
{
  background-color:yellow;
  box-shadow: 0px 1px 3px black;
  width: 30px;
  height: 30px;
}
#img1
{
  margin-left:-27%;
  margin-top:-27%;
  
  position: relative;

}


</style>