<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$dept=$_SESSION["dept"];

$department=$_SESSION["department"];
$_SESSION['department']=$department;
$_SESSION["dept"]=$dept;
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;
if($name && $pass)
{
  echo "session valid";

}
/*echo $name;
echo $pass;
echo $dept;
echo $department[0*/
?>
<?php




$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$con = mysql_connect($servername, $username, $password);
if (!$con) {
    die("Connection failed: " . mysql_connect_error());
}
echo "Connected successfully";
 
$db=mysql_select_db("dept_details",$con)or die(mysql_error());
if($db)
{
  echo "connected db";
}



$tables=array("subdetails_cse","subdetails_ece","subdetails_eee","subdetails_civil","subdetails_mech","subdetails_snh");
$len=sizeof($tables);

?>


<!DOCTYPE html>
<html>
<head>
	<title>staff alocation</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  
 
 <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

  
</head>
<body>
<form action="update1.php" method="POST">
	<header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="logo.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" align="left">Sasurie Feedback System</h1>
        </div>
        
  
</nav>
</header>

	<div class="col-xs-12" id="color1">
		<div class="col-sm-5" id="left">
			<h1>Staff Name</h1>
			<?php
			$sta=array();
			
				$n=0;


             for($i=0;$i<$len;$i++)
               {
               $str=mysql_query("select * from $tables[$i] where dept='$dept'",$con);
               if($str)
    
               {
      //echo "connected str";
               }
              
            while($row=mysql_fetch_array($str))
          {
          $staff=$row['staffname'];
          $sta[$n]=$row['staffname'];
          // echo $sta[$n];
         
         $n=$n+1;
         
         ?>
         <input type="text" value="<?php echo $staff; ?>" id="color" name="<?php echo $n; ?>">
         <?php
			
		}
	}
	$_SESSION['n']=$n;
	$_SESSION['staffname']=$sta;
	
		
		?>
			
			 
		</div>
		<div class="col-sm-5" id="right">
			<h1>Subject Name</h1>
			<?php
			$subb=array();

			 $m=0;
             for($i=0;$i<$len;$i++)
               {
               $str=mysql_query("select * from $tables[$i] where dept='$dept'",$con);
               if($str)
    
               {
      //echo "connected str";
               }
              

            while($row=mysql_fetch_array($str))
          {
          //$staff=$row['staffname'];
          $subb[$m]=$row['subname'];
          $sub=$row['subname'];
          //echo $subb[$m];
          
         $m=$m+1;
                   
          ?>
			<input type="text" value="<?php echo $sub;?>" id="color" name="sub<?php echo $m;?>">
			<?php
		}
	}
	
	$_SESSION['subname']=$subb;
	//echo $sta;
	//echo $subb;
		?>
			
		</div>
	
	<div>
  <button type="submit" id="btn1" class="btn-warning">Save</button>
</div>
</div>
</form>
</body>
</html>
<style type="text/css">
	#color
	{
		background-color:white;
		margin:5%;
		width:100%;
		color:black;

		
	}
	#btn1
{
margin-top:2%;
margin-left:45%;
width:8%;
height:45px;
border-radius:5em;
}
	#color1
	{
		background-color:blue;
	}
	#left
	{
		margin-left:10%;
	}
	#right
	{
		margin-left:5%;
	}


body {
  background:white;
  font-family: 'Titillium Web', sans-serif;
}


.form {
  background:black;
  padding-left: 40px;
  padding-right: 40px;
  box-shadow: 0px 0px 4px #70c970;
  height: auto;
  margin: 20px auto;
  border-radius: 4px;
  
}


label {
  position: absolute;
  -webkit-transform: translateY(6px);
          transform: translateY(6px);
  left: 13px;
  color: black;
  -webkit-transition: all 0.25s ease;
  transition: all 0.25s ease;
  -webkit-backface-visibility: hidden;
  pointer-events: none;
  font-size: 22px;
  padding-bottom:2%;
}


label.active {
  -webkit-transform: translateY(50px);
          transform: translateY(50px);
  left: 2px;
  font-size: 14px;
}

label.highlight {
  color:white;
}

input, textarea {
  display: block;
  width: 100%;
  padding: 5px 10px;
  background: none;
  background-image: none;
  
  box-shadow:0px 0px 4px white;
  border:none;
  color:white;
  border-radius: 0;
  -webkit-transition: border-color .25s ease, -webkit-box-shadow .25s ease;
  transition: border-color .25s ease, -webkit-box-shadow .25s ease;
  transition: border-color .25s ease, box-shadow .25s ease;
  transition: border-color .25s ease, box-shadow .25s ease, -webkit-box-shadow .25s ease;
}
input:focus, textarea:focus {
  outline: 0;
  border-color:black;
}

textarea {
  border: 2px solid black;
  resize: vertical;
}

.field-wrap {
  position: relative;
  margin-bottom: 40px;
}
.button {
  border: 0;
  outline: none;
 border-radius: 0;
  padding: 15px 0;
  font-size: 2rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: .1em;
  background: #1ab188;
  color:#ffffff;
  -webkit-transition: all 0.5s ease;
  transition: all 0.5s ease;
  -webkit-appearance: none;

}

.button-block {
   margin-left:25%;
   margin-bottom:5%;
  width:50%;
  background-color:yellow;
  padding-left:20px;
  font-color:#f54e0c;

}
  
#img1
{
  margin-left:2%;
  margin-top:-27%;
  width: 80%;
  position: relative;

}
#nav
{
  box-shadow: 0px 0px 10px black;
 padding: 20px; 
 background-color:#cef7d1;
 border:none;  
}
.navbar-toggle
{
  background-color:#e3c38b;
  box-shadow: 0px 0px 3px black;
  width: 30px;
  height: 30px;
}
.h1

{
  padding:30px;
  color: white;
  text-shadow: 1px 1px 3px #025802;
}
#myNavbar{
  text-align: center;
}
#text1{
  font-family: calibri;
  font-style: inherit;
  font-size: 34px;
  text-shadow: 0px 0px 2px #024602;
  color:#024602;
  
}
#input{
  box-shadow: 0px 0px 4px white;

  border:none;
  border-radius: 3px;
}
label{
  color: #ffffff;
  opacity: 0.8;
  text-shadow: 0px 1px 3px #000;
}
#btn1
{
  border-radius:5px;
  color:red;
  opacity: 0.8;
  
  
  
}
#submit{
  color: white;
}
#log{
padding-top:20px; 


}
#button button-block{

  font-color:red;
}
#name{
  

  background-color:white; 
  height: 40px;
  font-size:15px;
}

.texty{

  font-size: 60px;
  font-color:red;
  padding-bottom: 90px;

}
</style>