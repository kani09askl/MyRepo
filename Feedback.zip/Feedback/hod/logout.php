<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];


if($name && $pass)
{
  echo "session valid";

}
session_destroy() ;

header("location:login.php");
?>