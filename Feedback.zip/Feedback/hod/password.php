<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;
if($name && $pass)
{
  //echo "session valid";

}
//echo $name;
//echo $pass;
?>


<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <script src="js/jquery.min.js"></script>
  <script src="js/1.min.js"></script>
  <link rel="stylesheet" href="css/login.css">
  <style>
  #con{
    background-color: #af8c9b;
    
  height:510px;
  border-radius: 10px;
  background-image:url("image/00.jpg"); 
  }
  #name1{
    padding-top:130px;
    margin-left:-10px;
  }
  #name2{
    margin-left: -10px;
    padding-top: 159px;
  }
  #name3{
    padding-top:190px;
    margin-left: -10px;
  }
  #name{
    margin-top:40px;
    width:200px;
    margin-left: 270px;
    
  }
  #names{

  margin-top: 135px;
  height:30px;
  background-color: white;
  margin-left:30px;
 
  border-radius: 10px;
  font-size: 15px;
  }
  #namess{
    
  height:30px;
  background-color: white;
  margin-left: 30px;
  margin-top:190px:
   border-radius: 10px;
    font-size: 15px;
  }
  #namesss{
  
  height:30px;
  background-color: white;
  margin-left: 30px;

   border-radius: 10px;
    font-size: 15px;
  }
  #re{
    padding-right:10px;
    border-radius: 10
  }
  #bt5{
    background-color:;
    margin-top:70px;
    border-radius: 10px;
    padding-right:25px;
    background-image:url("image/00.jpg"); 

  }
  #imge{
     background-color:#e8d5dd;
  }
  body{
    background-image: url("image/73.jpg");
  }
  #nav{
    background-color:#d1cba9;
  }
  #name1
  {
    
    padding-left:30%;
  }
  #name2
  {
    margin-top:17px;
    padding-left:30%;

    }
    #name3
    {
      margin-top:40px;
      padding-left:30px;
    }
  </style>
</head><body>
  <body  id="imge">
<header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="logo.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1" align="left">Sasurie FeedBack System</h1>
        </div>
        
  
</nav>
</header>
<form action="password1.php" method="POST">
<div class="container">
  <div class="row">
    

    <div class="col-sm-2"></div>

<div class="col-sm-8" id="con">
  <div class="col-sm-3">

  <label for="NAME" id="name1">Old PSW 
    </label>
  <label for="Reg_no" id="name2" >New PSW</label>
  <label for="Department " id="name3" >Repeat PSW</label></div>

<div class="col-sm-5">
     <input type="Password" placeholder="EnterYour old Password" name="oword" required id="names" style="color:black;"><br/>
<input type="password" placeholder="Enter your new password" name="npass" required id="namess"  id="re" style="color:black;" ><br/>
<input type="password" placeholder="Repeat password" name="cpass" required id="namesss"  style="color:black;"><br/>
   
 <button type="submit" style="font-size:15px;font-color:black;"
       class="button button-block" id="back">SAVE</button></a>
       </form>
<a href="option.php"><button type="submit" style="font-size:15px;font-color:black;"
       class="button button-block" id="back1" >BACK</a></button>
      
    </div>
    <
      
</div>

</div>
</div>


<style>
#back
{
  background-color:black; 
  height:40px;
  width:85px;
  border-radius: 10px;
  padding-bottom: 30px;
  padding-right: 30px;
  margin-top: 30px;
  color: #5b7fba;
}
#back1
{
  background-color:black; 
  height:40px;
  width:85px;
  border-radius: 10px;
  margin-left: 30px;
   padding-right: 30px;
   padding-bottom: 30px;
  color: white;
}