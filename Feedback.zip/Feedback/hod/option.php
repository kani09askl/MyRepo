<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$_SESSION["name"]=$name;
$_SESSION["pass"]=$pass;
if($name && $pass)
{
  //echo "session valid";

}
//echo $name;
//echo $pass;
?>
<?php 



$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$con = mysql_connect($servername, $username, $password);
if (!$con) {
    die("Connection failed: " . mysql_connect_error());
}
//echo "Connected successfully";
 
$db=mysql_select_db("complaint",$con)or die(mysql_error());
if($db)
{
  //echo "connected db";
}
$str="SELECT * FROM staff_main where emailid='$name' AND password='$pass'";
if($str)
{
  //echo "connected str";
}
$result=mysql_query($str,$con);
if($result)
{
  //echo "connected result";
}
while($row=mysql_fetch_array($result))
{
  $dept=$row['dept'];
  $_SESSION["dept"]=$dept;
  //echo $dept;
}
//$sem=$_POST["sem"];
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <script src="js/jquery.min.js"></script>
  <script src="js/1.min.js"></script>
  <link rel="stylesheet" href="css/login.css">
  <style>
  body{
  background-image:url("image/014.png");
  opacity: 0.8;

  }
  
#circle{
  
height:250px;
margin-top: 70px;
border-radius: 10px;
background-image:url("images/89.jpg");
opacity:0.8; 
}
#bt{
  background-color:black; 
  color:red;
  border-radius:5px;
  font-size:15px;
  width:180px;
  height:35px;
  padding-top:10px;
  margin-top: 80px;

  padding-left: 4px;

  

}
#fd{
  background-color:black; 
  color:red;
  border-radius:5px;
  font-size:15px;
  width:180px;
  height:35px;
  padding-top: 10px;
   

}
#option{
  color:red;
  font-size:15px;
  border-radius: 10px;
}
#nav1{
  box-shadow: 0px 0px 10px black;
 padding: 20px; 
 background-color:#d1cba9;
 border:none;  
background-image: url("image/.jpg");
}
body{
  background-image: url("image/73.jpg");


 
}
.popup {
    position: relative;
    display: inline-block;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* The actual popup */
.popup .popuptext {
    visibility: hidden;
    width: 150px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 8px 0;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left:-70%;
    margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left:90%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}
.text{
  padding-left:94px;
}


.popup .show {
    visibility: visible;
    -webkit-animation: fadeIn 1s;
    animation: fadeIn 1s;
}


@-webkit-keyframes fadeIn {
    from {opacity: 0;} 
    to {opacity: 1;}
}

@keyframes fadeIn {
    from {opacity: 0;}
    to {opacity:1 ;}
}
#popup2{
  margin-bottom:-5px;
}
.img-circle
{
  background-color: #000;
}

#sub{
  margin-top: 70px;
  background-color: black;
  font-color:red;
  border-radius: 6px;
}
#font{
  font-size: 10px;
}
#text1{
  font-size: 28px;
}
</style>
</head>

  <body  id="imge">
<header>
<body  id="imge">
<header>
<nav class="navbar navbar" id="nav1">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="logo.png" id="img1"></a>
    </div>
    </div>
    <div style="width: 100%;" class="collapse navbar-collapse" id="myNavbar">
      <ul style="width: 100%;" class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 id="text1">Sasurie FeedBack System</h1>
        </div>
      </li>
       <li style="padding-left: 60%;"><div class="popup" onclick="myFunction()" id="popup2"><img src="download.jpg" class="img-circle" alt="Cinque Terre" width="45" height="45">
  <span class="popuptext" id="myPopup"> <a href="logout.php"><button type="button" class="btn btn-primary" id="font">Log out</button></a>
    <a href="password.php">
   <button type="button" class="btn btn-primary" id="font">Change Psw </button></a></span>
</div></li>
      </div>
     
  
</nav>
</header>
<div class="contaoiner">
  <div clas="row">
    <div class="col-sm-4"></div>

<div class="col-sm-4" id="circle" >
  
    <a href="Staff alocation.php">
  <button type="submit" class="button button-block" id="bt">Staff Allogation</button>
  <a href="hod.php">
  <button type="submit" class="button button-block" id="fd">Feedback</button>
   </a>          
  
 </div>

  </div>
  </div>
    <div class="col-sm-4"></div>
  </div>
</div>

</body>
<script>function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
</script>
 
<script  src="js/index.js"></script>
<script  src="js/style.js"></script>
<script  src="js/jquary.min.js"></script>
<script  src="js/style.js"></script>


</html>