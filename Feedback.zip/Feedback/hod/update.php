<?php
session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$staffname=$_SESSION["subname"];

$dept=$_SESSION["dept"];

if($staffname)
{
	//echo "session valid";
}
else{
    //echo "session doesnot valid";
}

?>


<?php 

 $dept=$_SESSION["dept"];
 //echo $dept;
$staffname=$_SESSION["subname"]; 
//echo $staffname;  
$sugg=$_POST["suggest"];
//echo $sugg;
$set=explode("-",$staffname);


//echo $staff;
//echo $sub;

$dbhost = "localhost";
   $dbuser = "root";
   $dbpass = "";

   $con = mysql_connect($dbhost, $dbuser, $dbpass);
   $db=mysql_select_db("dept_details",$con)or die(mysql_error());
   if($db)
   {
  //echo "connected";
   }
   
   if(! $con ) {
      die('Could not connect: ' . mysql_error());
      }
	 // echo "connection successful";
	  if($dept=="CSE"){
     // echo "cse";
      //echo $set[0];
     // echo $set[1];
      $fb="UPDATE subdetails_cse SET hod_msg='$sugg' where subname='$set[1]' AND staffname='$set[0]'";

	  }
	  elseif($dept=="ECE"){
		  //echo "ECE";
     $fb="UPDATE subdetails_ece SET hod_msg='$sugg' where subname='$set[1]' AND staffname='$set[0]'";
	  }
	  elseif($dept=="EEE")
	  {
    $fb="UPDATE subdetails_eee SET hod_msg='$sugg' where subname='$set[1]' AND staffname='$set[0]'";
	  }
	  elseif($dept=="MECH"){
    $fb="UPDATE subdetails_mech SET hod_msg='$sugg' where subname='$set[1]' AND staffname='$set[0]'";
	  }
	  elseif($dept=="CIVIL")
	  {
    $fb="UPDATE subdetails_civil SET hod_msg='$sugg' where subname='$set[1]' AND staffname='$set[0]'";
	  }
	  elseif($dept=="SNH"){
    $fb="UPDATE subdetails_snh SET hod_msg='$sugg' where subname='$set[1]' AND staffname='$set[0]'";
	  }
$result=mysql_query($fb,$con);
if($result)
{
 // echo "connected result";
}

if ($result) { 

echo "<script type=\"text/javascript\">window.alert('msg Inserted successfully');
window.location.href = 'option.php';</script>"; 
}
else
{
echo "<script type=\"text/javascript\">window.alert('Error on inserting msg');
window.location.href = 'option.php';</script>"; 
}

?>