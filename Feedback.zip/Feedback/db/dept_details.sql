-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2019 at 03:57 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dept_details`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `subname` varchar(100) DEFAULT NULL,
  `feedback` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`sno`, `staff_name`, `name`, `year`, `dept`, `sem`, `subname`, `feedback`) VALUES
(1, 'priya', 'dinesh', 2, 'civil', 'IV', 'computer programming', 'she is good.we can understand her teaching.'),
(2, 'nikitha', 'dinesh', 2, 'civil', 'IV', 'evs', 'she is good.we can understand her teaching.'),
(3, 'priya', 'gayathri', 2, 'civil', 'IV', 'computer programming', 'she is good.we can understand her teaching.'),
(4, 'nikitha', 'gayathri', 2, 'civil', 'IV', 'evs', 'she is good.we can understand her teaching.'),
(5, 'nikitha', 'kaniii', 2, 'cse', 'IV', 'computer network', 'she is  very good.we can understand her teaching.Her class is useful.'),
(6, 'nikitha', 'kaniii', 2, 'cse', 'IV', 'transfer and partial differential equation and programming and computer', 'she is very good.we can understand her teaching.Her class is useful'),
(7, 'nikitha', 'nikitha', 2, 'cse', 'IV', 'computer network', 'she is very good.we can understand her teaching.Her class is useful'),
(8, 'nikitha', 'nikitha', 2, 'cse', 'IV', 'transfer and partial differential equation and programming and computer', 'she is very good.we can understand her teaching.Her class is useful'),
(9, 'nikitha', 'ranjani', 2, 'cse', 'IV', 'transfer and partial differential equation and programming and computer', 'she is very good.we can understand her teaching.Her class is useful'),
(10, 'nikitha', 'ranjani', 2, 'cse', 'IV', 'computer network', 'she is very good.we can understand her teaching.Her class is useful'),
(11, 'swetha', 'swetha', 2, 'ece', 'IV', 'evs', 'she is good.'),
(12, 'swetha', 'deepak', 2, 'ece', 'IV', 'evs', 'she is good in teaching'),
(13, 'mahesh', 'priya', 2, 'eee', 'IV', 'electrical engineering', 'she is excellent in teaching.It is very useful.'),
(14, 'mahesh', 'pavithra', 2, 'eee', 'IV', 'electrical engineering', 'she is excellent in teaching.It is very useful.'),
(15, 'nikitha', 'maheswari', 2, 'mech', 'IV', 'electrical engineering', 'she is very good in teaching.she gives many technical knowledge to us.'),
(16, 'priya', 'saranya', 1, 'snh', 'II', 'computer programming', 'she is very good in teaching.she gives many technical knowledge to us.'),
(17, 'gayathri', 'saranya', 1, 'snh', 'II', 'computer network', 'she is very good in teaching.she gives many technical knowledge to us.'),
(18, 'nikitha', 'nikitha', 2, 'cse', 'IV', 'computer network', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `student_civil`
--

CREATE TABLE IF NOT EXISTS `student_civil` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `regno` char(12) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `phoneno` char(10) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `pword` char(8) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `student_civil`
--

INSERT INTO `student_civil` (`sno`, `regno`, `name`, `dept`, `year`, `sem`, `phoneno`, `emailid`, `pword`) VALUES
(1, '732416104011', 'dinesh', 'civil', 2, 'IV', '9876542130', 'dinesh1233@gmail.com', 'dinesh12'),
(3, '732416104012', 'gayathri', 'civil', 2, 'IV', '9876543210', 'gayu123@gmail,com', 'gayu1234');

-- --------------------------------------------------------

--
-- Table structure for table `student_cse`
--

CREATE TABLE IF NOT EXISTS `student_cse` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `regno` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `phoneno` char(10) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `pword` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `student_cse`
--

INSERT INTO `student_cse` (`sno`, `regno`, `name`, `dept`, `year`, `sem`, `phoneno`, `emailid`, `pword`) VALUES
(8, '732416104022', 'kaniii', 'cse', 2, 'IV', '8220916142', 'kani123@gmail.com', 'kani1234'),
(3, '732416104035', 'nikitha', 'cse', 2, 'IV', '9876543210', 'niki1234@gmail.com', 'niki'),
(4, '732416104042', 'ranjani', 'cse', 2, 'IV', '8764632541', 'ranju@gmail.com', 'ranju1234');

-- --------------------------------------------------------

--
-- Table structure for table `student_ece`
--

CREATE TABLE IF NOT EXISTS `student_ece` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `regno` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `phoneno` char(10) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `pword` char(8) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `student_ece`
--

INSERT INTO `student_ece` (`sno`, `regno`, `name`, `dept`, `year`, `sem`, `phoneno`, `emailid`, `pword`) VALUES
(5, '732416104051', 'swetha', 'ece', 2, 'IV', '9876543210', 'swe123@gmail.com', 'swe12345'),
(4, '732416104008', 'deepak', 'ece', 2, 'IV', '9876543210', 'deepak123@gmail.com', 'gkdeepak');

-- --------------------------------------------------------

--
-- Table structure for table `student_eee`
--

CREATE TABLE IF NOT EXISTS `student_eee` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `regno` char(12) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `phoneno` char(10) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `pword` char(8) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `student_eee`
--

INSERT INTO `student_eee` (`sno`, `regno`, `name`, `dept`, `year`, `sem`, `phoneno`, `emailid`, `pword`) VALUES
(1, '732416104038', 'priya', 'eee', 2, 'IV', '9876543210', 'priya123@gmail.com', 'priya123'),
(2, '732416104036', 'pavithra', 'eee', 2, 'IV', '9876512340', 'pavi1234@gmail.com', 'pavi1243');

-- --------------------------------------------------------

--
-- Table structure for table `student_mech`
--

CREATE TABLE IF NOT EXISTS `student_mech` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `regno` char(12) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `phoneno` char(10) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `pword` char(8) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `student_mech`
--

INSERT INTO `student_mech` (`sno`, `regno`, `name`, `dept`, `year`, `sem`, `phoneno`, `emailid`, `pword`) VALUES
(1, '732416104030', 'maheswari', 'mech', 2, 'IV', '8012893941', 'mahes123@gmail.com', 'mahesh12');

-- --------------------------------------------------------

--
-- Table structure for table `student_snh`
--

CREATE TABLE IF NOT EXISTS `student_snh` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `regno` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `phoneno` char(10) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `pword` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `student_snh`
--

INSERT INTO `student_snh` (`sno`, `regno`, `name`, `dept`, `year`, `sem`, `phoneno`, `emailid`, `pword`) VALUES
(1, '732416104045', 'saranya', 'snh', 1, 'II', '9876543210', 'saran123@gmail.com', 'saran123');

-- --------------------------------------------------------

--
-- Table structure for table `subdetails_civil`
--

CREATE TABLE IF NOT EXISTS `subdetails_civil` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(100) DEFAULT NULL,
  `staffname` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `hod_msg` varchar(1500) DEFAULT NULL,
  `principal_msg` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `subdetails_civil`
--

INSERT INTO `subdetails_civil` (`sno`, `subname`, `staffname`, `dept`, `sem`, `year`, `hod_msg`, `principal_msg`) VALUES
(1, 'computer programming', 'priya', 'ece', 'IV', 2, 'keep going', 'keep it up.'),
(3, 'computer architecture', 'mahesh', 'mech', 'VI', 3, 'keep going', 'keep it up.'),
(4, 'distributed system', 'gayathri', 'civil', 'V', 3, 'keep going', 'keep it up.'),
(5, 'computer network', 'priya', 'ece', 'V', 3, 'keep going', 'keep it up.'),
(6, 'evs', 'swetha', 'eee', 'II', 1, 'keep going', 'keep it up.');

-- --------------------------------------------------------

--
-- Table structure for table `subdetails_cse`
--

CREATE TABLE IF NOT EXISTS `subdetails_cse` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(100) DEFAULT NULL,
  `staffname` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `principal_msg` varchar(1500) DEFAULT NULL,
  `hod_msg` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `subdetails_cse`
--

INSERT INTO `subdetails_cse` (`sno`, `subname`, `staffname`, `dept`, `sem`, `year`, `principal_msg`, `hod_msg`) VALUES
(1, 'computer architecture', 'mahesh', 'mech', 'III', 2, 'mahesh computer architecture', 'keep going'),
(2, 'computer network', 'nikitha', 'cse', 'IV', 2, 'kaaa', NULL),
(3, 'transfer and partial differential equation and programming and computer', 'nikitha', 'cse', 'IV', 2, 'keep it up.', 'keep going'),
(5, 'computer network', 'mahesh', 'mech', 'V', 3, 'keep it up.', 'keep going'),
(6, 'distributed system', 'swetha', 'eee', 'VI', 3, 'keep it up.', 'keep going');

-- --------------------------------------------------------

--
-- Table structure for table `subdetails_ece`
--

CREATE TABLE IF NOT EXISTS `subdetails_ece` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(100) DEFAULT NULL,
  `staffname` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `hod_msg` varchar(1500) DEFAULT NULL,
  `principal_msg` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `subdetails_ece`
--

INSERT INTO `subdetails_ece` (`sno`, `subname`, `staffname`, `dept`, `sem`, `year`, `hod_msg`, `principal_msg`) VALUES
(1, 'evs', 'swetha', 'eee', 'IV', 2, 'keep going', 'keep it up.'),
(2, 'computer architecture', 'mahesh', 'mech', 'VI', 2, 'keep going', 'keep it up.'),
(4, 'computer architecture', 'swetha', 'eee', 'III', 2, 'keep going', 'keep it up.'),
(5, 'distributed system', 'mahesh', 'mech', 'II', 1, 'keep going', 'keep it up.'),
(6, 'evs', 'priya', 'ece', 'V', 3, 'keep going', 'keep it up.');

-- --------------------------------------------------------

--
-- Table structure for table `subdetails_eee`
--

CREATE TABLE IF NOT EXISTS `subdetails_eee` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(100) DEFAULT NULL,
  `staffname` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `hod_msg` varchar(1500) DEFAULT NULL,
  `principal_msg` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `subdetails_eee`
--

INSERT INTO `subdetails_eee` (`sno`, `subname`, `staffname`, `dept`, `sem`, `year`, `hod_msg`, `principal_msg`) VALUES
(1, 'electrical engineering', 'mahesh', 'mech', 'IV', 2, 'keep going', 'keep it up.'),
(3, 'distributed system', 'gayathri', 'mech', 'V', 3, 'keep going', 'keep it up.'),
(4, 'electrical engineering', 'priya', 'ece', 'II', 1, 'keep going', 'keep it up.'),
(5, 'computer programming', 'mahesh', 'mech', 'VI', 2, 'keep going', 'keep it up.'),
(6, 'computer network', 'swetha', 'eee', 'III', 2, 'keep going', 'keep it up.'),
(7, 'electrical engineering', 'gayathri', 'civil', 'II', 1, 'keep going', 'keep it up.');

-- --------------------------------------------------------

--
-- Table structure for table `subdetails_mech`
--

CREATE TABLE IF NOT EXISTS `subdetails_mech` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(100) DEFAULT NULL,
  `staffname` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `hod_msg` varchar(1500) DEFAULT NULL,
  `principal_msg` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `subdetails_mech`
--

INSERT INTO `subdetails_mech` (`sno`, `subname`, `staffname`, `dept`, `sem`, `year`, `hod_msg`, `principal_msg`) VALUES
(2, 'evs', 'gayathri', 'civil', 'V', 3, 'keep going', 'keep it up.'),
(3, 'computer network', 'priya', 'ece', 'VI', 2, 'keep going', 'keep it up.'),
(4, 'distributed system', 'mahesh', 'mech', 'V', 3, 'keep going', 'keep it up.'),
(5, 'computer architecture', 'swetha', 'eee', 'III', 2, 'keep going', 'keep it up.');

-- --------------------------------------------------------

--
-- Table structure for table `subdetails_snh`
--

CREATE TABLE IF NOT EXISTS `subdetails_snh` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(100) DEFAULT NULL,
  `staffname` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(10) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `principal_msg` varchar(1500) DEFAULT NULL,
  `hod_msg` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `subdetails_snh`
--

INSERT INTO `subdetails_snh` (`sno`, `subname`, `staffname`, `dept`, `sem`, `year`, `principal_msg`, `hod_msg`) VALUES
(1, 'computer programming', 'priya', 'ece', 'II', 1, 'keep it up.', 'keep going'),
(3, 'computer network', 'swetha', 'eee', 'III', 2, 'keep it up.', 'keep going'),
(4, 'computer network', 'gayathri', 'civil', 'II', 1, 'keep it up.', 'keep going'),
(5, 'electrical engineering', 'mahesh', 'mech', 'V', 3, 'keep it up.', 'keep going');
