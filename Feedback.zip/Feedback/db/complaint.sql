-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2019 at 03:43 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `complaint`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--


-- --------------------------------------------------------

--
-- Table structure for table `staff_main`
--

CREATE TABLE IF NOT EXISTS `staff_main` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(50) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `phoneno` varchar(15) DEFAULT NULL,
  `emailid` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `desgination` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `staff_main`
--

INSERT INTO `staff_main` (`sno`, `staff_name`, `dept`, `phoneno`, `emailid`, `password`, `desgination`) VALUES
(1, 'nikitha', 'cse', '9876543210', 'nikitha123@gmail.com', 'niki1243', 'staff'),
(2, 'priya', 'ece', '9876054321', 'priya1234@gmail.com', 'priya123', 'staff'),
(3, 'swetha', 'eee', '9876543210', 'swe1234@gmail.com', 'swe12345', 'staff'),
(4, 'mahesh', 'mech', '9876543210', 'mahes123@gmail.com', 'niki1243', 'staff'),
(5, 'gayathri', 'civil', '9864573111', 'gayu123@gmail.com', 'gayu1234', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `subject_main`
--

CREATE TABLE IF NOT EXISTS `subject_main` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `subname` varchar(100) DEFAULT NULL,
  `dept` varchar(10) DEFAULT NULL,
  `sem` varchar(5) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `regulation` int(11) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `subject_main`
--

INSERT INTO `subject_main` (`sno`, `subname`, `dept`, `sem`, `year`, `regulation`) VALUES
(1, 'software Engineering', 'CSE', 'IV', 2, 2013),
(2, 'computer architecture', 'CSE', 'III', 2, 2013),
(3, 'computer architecture', 'ece', 'VI', 3, 2013),
(4, 'thermo dynamics', 'mech', 'VIII', 4, 2013);
