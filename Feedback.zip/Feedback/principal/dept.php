<?php

session_start();


$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$_SESSION["pass"]=$pass;
$_SESSION["name"]=$name;


if($name && $pass)
{
	//echo "session valid";
}
else{
   // echo "session doesnot valid";
}

?><!DOCTYPE html>
<html lang="en">
<head>
  <title>Dept</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="CSS/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="IMAGE/logo-sasurie.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 class="text1" align="center">Feedback</h1>
        </div>
      </li>
      </div>
     
      <div class="icon-bar">
        <button= data-toggle="modal" data-target="#myModal"><i class="fa fa-user-circle-o"></i></button>
        <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <form action="dept.php" method="POST">
           <button type="button" class="close"></button></form>
           <a href="logout.php">
          <button type="submit" class="btn btn-primary">Logout</button></a>
        <button type="button" class="close">&times;</button>
        </div>
        <!--<div class="modal-body"><form action="password.php" method="POST">
          <button type="submit" class="btn btn-primary">Change password </button> </form>      </div>-->
        <div class="modal-footer">
          
        </div>
      </div>
      </div>
    </div>
      </div>

  
</nav>
</header>
<form action="subject.php" method="POST">
 <div class="container"> 
  <div class="row">
    <div class="col-sm-2">
  </div>
  <div class="col-sm-4" id="row1">
  	<div class="col1">
  Dept:<select class="selectpicker"  name="dept" id="box1">
  <option></option>
   <option value="snh" >S&H</option>
  <option value="cse">CSE</option>
  <option value="ece">ECE</option>
  <option value="eee">EEE</option>
  <option value="civil">CIVIL</option>
  <option value="mech">MECH</option>
</select></div></div>
<div class="col-sm-4" id="row2">
	<div class="col2">
Sem:<select class="selectpicker" name="sem" id="box2">
<option></option>
  <option value="I">I</option>
<option value="II">II</option>
<option value="III">III</option>
<option value="IV">IV</option>
<option value="V">V</option>
<option value="VI">VI</option>
<option value="VII">VII</option>
<option value="VIII">VIII</option>
</select>
</div></div>
<div class="col-sm-2">
</div></div>
</div><div class="log">
  <div class="col-sm-6">
<center><button type="submit" class="btn " id="row"> Submit </button></center>
</div>
<div class="col-sm-6">
  <a href="principal.php" >
      <input type="button" class="btn" id="back" id="text1" value="BACK"></a>
    </div>
  </div>
</form>
</body>
</html>



<style>

#center
{
 margin-top: 100px;
 background-color: #063d11;
 border-radius: 10px;
 height: 300px;
}

body
{
 background-color:white;
}
.log
{
 padding-top: 10%;
 margin-left:10%;
}
#row
{
 font-size: 20px;
}
#box1
{
 margin-left: 10px;
 padding-left: 20px;
 box-shadow: 0px 0px 1px black;
 color:white;
 border:none;
 border-radius: 5px;
 background-color:#491645;
}
#box2
{
 margin-left: 10px;
 padding-left: 20px;
 box-shadow: 0px 0px 1px black;
 color:white;
 border:none;
 border-radius: 5px;
 background-color:#491645;
}
#row1
{
 padding-top: 90px;
 padding-left:10px;
}
#row2
{
 padding-top: 90px;
 padding-left:10px;
}

.col1
{
 background-color:#b9bbbf;
 height:100px;
 width:80%;
 padding-top:40px;
 padding-left:50px;
 font-size: 20px;
 border-radius: 5px;
}
.col2
{
 background-color:#b9bbbf;
 height:100px;
 width:80%;
 padding-top:40px;
 padding-left:50px;
 font-size: 20px;
 border-radius: 5px;
}

.img-circle
{
  margin-left:200px;
  margin-top:7%;
}
#text
{
  padding-top:5%;
}
#nav
{
  box-shadow: 0px 0px 5px #caefca;
 padding: 20px; 
background-color: #66d9ff;
 border:none;  
}
.navbar-toggle
{
  background-color:#c9e6c9;
  box-shadow: 0px 0px 3px #c9e6c9;
  width: 30px;
  height: 25px;
}
#img1
{
  margin-left:-27%;
  margin-top:-27%;
  width: 100%;
  position: relative;

}
.fa
{
 float:right;
 font-size:50px;
 margin-top:-5%;

}

.icon-bar a {
    
    
    text-align: center;
    padding: 12px 0;
    transition: all 0.3s ease;
    color: white;
    font-size: 36px;
  }
#back
{
  font-size:20px;
  color:black;
}
#text1
{
  color:black;
}
</style>











