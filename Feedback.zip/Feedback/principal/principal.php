<!DOCTYPE html>
<html lang="en">
<head>
  <title>Principal Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>

	 <header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="IMAGE/logo-sasurie.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 class="text1" align="center">Feedback</h1>
        </div>
      </li>
      </div>
  
</nav>
</header>
<form action="login.php" method="POST">
<div class="container">
	
	<p> </p></div>
	<div class="col-sm-4">
	</div>
	<div class="col-sm-4" id="main">
    <h3 id="welcome" align="center">  Welcome to principal</h3>
<div class="form-group" id="usr"><center>
	<lable for="usr"><b>Username:</b></lable>
	<input type="text" name="name" class="form-group" placeholder="Username" required id="box">
</center>
</div>
<div class="form-group" id="pwd"><center>
	<lable for="pwd"><b>Password:</b></lable>
	<input type="Password" name="pass" class="form-group" placeholder="password" required id="box">
</center>
</div>
<div class id="log"><center>
	
	<button type="submit" class="btn " id="row"> login </button></center>
</div>
</div>
<div class="col-sm-4"></div>
</form>
</body>
</html>




<style>
#nav
{
  box-shadow: 0px 5px 5px black;
}
#img1
{
  margin-left:-27%;
   margin-top:-27%;
  width: 100%;
  position: relative;
  
}
#nav
{
  box-shadow: 0px 0px 5px #caefca;
 padding: 20px; 
 background-color: #66d9ff;
 border:none;  
}
.navbar-toggle
{
  background-color:#c9e6c9;
  box-shadow: 0px 0px 3px #c9e6c9;
  width: 30px;
  height: 30px;
}

    #main
    {
      background-color:#003300;
      margin-top: 13%;
        font-size: 20px;
        border-radius:15px;
        box-shadow: 0px 0px 8px white;
    }
          #usr
    {
      color:white;
        padding-top: 55px;
   }
    #pwd
    {
      color:white;
      padding-top:30px;
    }
  #box
   {
      border-radius: 4px;
    font-size: 15px;
    border: none;
    box-shadow: 0px 0px 1px white;
    height: 30px;
    text-align: center;
    width: 200px;
    color: black;
   }
  #log
    {
      padding-top: 30px;
      padding-bottom: 15px;
    }
   #row
   {
    width:20%;
    color:black;
    background-color:yellow;
   }
   #welcome
    {
      
      font-family: Andalus;
      color: white;
      text-shadow: 0px 1px 2px yellow;

      }
  
     
 </style>