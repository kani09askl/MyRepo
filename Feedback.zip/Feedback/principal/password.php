<?php
session_start();

$name=$_SESSION["name"];
$pass=$_SESSION["pass"];


	$_SESSION["name"]=$name;

	$_SESSION["pass"]=$pass;
	//echo $pass;
	//echo $name;
if($name && $pass)
{
	//echo "session valid";
}
else
{
	//echo "session does not valid";
}

?><!DOCTYPE html>
<html lang="en">
<head>
  <title>Dept</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
  <header>
<nav class="navbar navbar" id="nav">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button " class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <div>
      <a class="navbar-brand" id="img"> <img src="IMAGE/logo-sasurie.png" id="img1"></a>
    </div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <div class="text">
          <h1 class="text1" align="center">Feed Back</h1>
        </div>
      </li>
      </div>
     
      <div class="icon-bar">
        <button= data-toggle="modal" data-target="#myModal"><i class="fa fa-user-circle-o"></i></button>
        <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <form action="dept.html" method="POST">
           <button type="button" class="close"></button><button type="button" class="close">&times;</button></form>
           <a href="logout.php">
          <button type="submit" class="btn btn-primary">Log out</button></a>
        </div>
        <div class="modal-body"><a href="password.php">
          <button type="submit" class="btn btn-primary">Change password </button></a>      </div>
        <div class="modal-footer">
          
        </div>
      </div>
      </div>
    </div>
      </div>

  
</nav>
</header>

<form action="password1.php" method="POST">
<div class="container">
  
  <p> </p></div>
  <div class="col-sm-4">
  </div>
  <div class="col-sm-4" id="main">
<div class="form-group" id="usr"><center>
  <lable for="pwd"><b>Old password:</b></lable>
  <input type="password" name="oword" class="form-group" placeholder="password" required id="box1">
</center>
</div>
<div class="form-group" id="pwd"><center>
  <lable for="pwd"><b> New  Password:</b></lable>
  <input type="Password" name="npass" class="form-group" placeholder="password" required id="box2">
</center>
</div>
<div class="form-group" id="pwd"><center>
  <lable for="pwd"><b>Confirm Password:</b></lable>
  <input type="Password" name="cpass"  class="form-group" placeholder="password" required id="box3">
</center>
</div>
<div class id="log"><center>
<button type="submit" class="btn btn-success" id="row"> Save </button></center>
</div>
</div>
<div class="col-sm-4">
  </div>
</center>
</div>
</div>
</form>
 <div class="col-sm-12">    
 <button class="btn btn-primary" id="ba"><a  onClick="location.href='dept.php';" id="text">BACK</a></button></div>
</body></html>

















<style>
body
{
 background-color:white;
}
 #usr
    {
      color:black;
        padding-top: 55px;
        text-shadow: 0px 0px 1px black;
   }
    #pwd
    {
      color:black;
      padding-top:30px;
      text-shadow: 0px 0px 1px black;
    }
    #log
    {
      padding-top: 30px;
      padding-bottom: 15px;
    }

    #main
    {
      background-color: #b3ffe0;
      margin-top: 40px;
        font-size: 20px;
        border-radius:15px;
        box-shadow: 0px 0px 8px white;
    }
    #clr
    {
      font-size: 40px;
      color:#003300;
    }
    #box1
   {
      border-radius: 4px;
    font-size: 15px;
    border: none;
    box-shadow: 0px 0px 1px white;
    height: 30px;
    text-align: center;
    width: 200px;
    color: black;
    margin-left:50px;
   }
   #box2
   {
      border-radius: 4px;
    font-size: 15px;
    border: none;
    box-shadow: 0px 0px 1px white;
    height: 30px;
    text-align: center;
    width: 200px;
    color: black;
    margin-left: 40px;
   }
   #box3
   {
      border-radius: 4px;
    font-size: 15px;
    border: none;
    box-shadow: 0px 0px 1px white;
    height: 30px;
    text-align: center;
    width: 200px;
    color: black;
    margin-left: 5px;
   }

   #row
   {
    width:300px;
    height: 40px;
    color:#fff;
   }
   .img-circle
   {
  
    margin-left:120%;
    margin-top:-5%;
   }
   #nav
{
  box-shadow: 0px 0px 5px #caefca;
 padding: 20px; 
background-color: #66d9ff;
 border:none;  
}
.navbar-toggle
{
  background-color:#c9e6c9;
  box-shadow: 0px 0px 3px #c9e6c9;
  width: 30px;
  height: 25px;
}
#img1
{
  margin-left:-27%;
  margin-top:-27%;
  width: 100%;
  position: relative;

}
.fa
{
 float:right;
 font-size:50px;
 margin-top:-5%;

}

.icon-bar a {
    
    
    text-align: center;
    padding: 12px 0;
    transition: all 0.3s ease;
    color: white;
    font-size: 36px;
}
#ba 
{
  margin-left:48%;
  margin-top:3%;
}
#text
{
  font-size:18px;
  color:white;
}
</style>
