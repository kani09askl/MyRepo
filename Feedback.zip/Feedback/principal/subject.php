<?php

session_start();


$name=$_SESSION["name"];
$pass=$_SESSION["pass"];
$_SESSION["pass"]=$pass;
$_SESSION["name"]=$name;


if($name && $pass)
{
	//echo "session valid";
}
else{
    //echo "session doesnot valid";
}

?>
<?php
$dept=$_POST["dept"];
$sem=$_POST["sem"];
$_SESSION["dept"]=$dept;

$servername = "localhost";
$username = "root";
$password = "";

$con = mysql_connect($servername, $username, $password);
if($con)
{
//echo "connection successfully";
}
$str=mysql_select_db("dept_details",$con);
if($str)
{
	//echo "connected str";
}
$tables=array("subdetails_cse","subdetails_ece","subdetails_eee","subdetails_civil","subdetails_mech","subdetails_snh");
$len=sizeof($tables);
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dept</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="CSS\bootstrap.min.css">
  <script src="JS\jquery.min.js"></script>
  <script src="JS\bootstrap.min.js"></script>
</head>
<body>
	<header>
	<nav class="navbar navbar-default navbar" id="main-menu" role="banner">
<div class="container">
<div class="navbar-header"><button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse" type="button"><span class="sr-only">Toggle navigation</span></button><a class="navbar-brand" href="index.html"><img class="clglogo" alt="logo"  src="IMAGE/logo-sasurie.png" id="img"></a></div>
<div class="collapse navbar-collapse navbar-left" id="navbar">
<ul class="nav navbar-nav"><center><p>
	Sasurie Feedback System</p></center></ul>
<button= data-toggle="modal" data-target="#myModal"><img src="IMAGE/download.jpg" class="img-circle" alt="cinque terre" width="60" height="60"></button>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
                    <form action="dept.php" method="POST">
           <button type="button" class="close">&times;</button></form>
          
          <a href="logout.php"><button type="submit" class="btn btn-primary">Logout</button></a>
        </div>
        <!--<div class="modal-body"><form action="password.php" method="POST">
          <button type="submit" class="btn btn-primary">Change password </button> </form>      </div>-->
        <div class="modal-footer">
        </div>
      </div>
      </div>
    </div>
  </div>
  </div>
</nav>
</header> 
<form action="feed1.php" method="POST">
 <div class="container"> 
  <div class="row">
    <div class="col-sm-4">
  </div>
  <div class="col-sm-4" id="row1">
  	<div class="col1">
  Subject:
  <br>
  <select id="tt1" name="subname" required="text">
   <option></option>
  <?php
  for($i=0;$i<$len;$i++)
  {
  $str=mysql_query("select * from $tables[$i] where dept='$dept' and sem='$sem'",$con);
  if($str)
	  
	  {
		  //echo "connected str";
	  }
	  while($row=mysql_fetch_array($str))
	  {
		  $staff=$row['staffname'];
		  $sub=$row['subname'];
		  $v=$staff."-".$sub;
	  
  
  ?>
  
  <option><?php echo $v;?> </option>
  <?php
	  }
  }
  ?>
</select></div></div>
<div class="col-sm-4">
  </div>
</div>
</div>
<div class="log">
  <div class="col-sm-6">
<center><button type="submit" class="btn btn-primary" id="row"> Submit </button></center>
</div>
<div class="col-sm-6">
  <a href="dept.php">
      <input type="button" class="btn btn-primary"  value="BACK" id="ba"> </a>
    </div>
  </div>
</form>
</body>
</html>
<style>
#main-menu
{
  background-color:#66d9ff;
  height: 130px;
  box-shadow: 0px 0px 5px white;
}
#navbar
{
  padding-left: 180px;
  font-family: Andalus;
  color:#ff4da6;
  background-color:#66d9ff;
  
  text-shadow: 0px 0px 2px black;
}
#center
{
 margin-top: 100px;
 background-color: #063d11;
 border-radius: 10px;
 height: 300px;
}
.nav
{
 margin-left:15px;
 padding-top: 25px;
 font-size:40px;
}
body
{
 background-color:white;
}
#img
{
 margin-top:-15px;
 margin-left:-87%;
}

.log
{
 padding-top: 10%;
 margin-right:6%;
}
#row
{
 font-size: 20px;
 margin-left:90%;
 margin-top:-100px;
 width:20%;
}
#ba
{
  font-size:20px;
  margin-left:8%;
  margin-top: -100px;
  width:20%;
  color:white;
  font-size:20px;
}
#box1
{
 
 box-shadow: 0px 0px 1px black;
 color:white;
 border:none;
 border-radius: 5px;

 background-color:#ff1a1a;
  font-size:16px;
}
#row1
{
 padding-top: 90px;
 padding-left:10px;
}

.col1
{
 background-color:#79ff4d;
 height:190px;

 padding-top:55px;
 padding-left:70px;
 font-size:24px;
 border-radius: 5px;
}

.img-circle
{
  margin-left:130%;
  margin-top:-15%;
}

#tt1
{
  font-size: 20px;
width:200px;
height:30px;
border-radius:5px;
box-shadow:0px 0px 5px brown;
}

</style>
