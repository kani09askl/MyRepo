<?php
$staffname=$_POST["subname"];


session_start();
$name=$_SESSION["name"];
$pass=$_SESSION["pass"];



$_SESSION["subname"]=$staffname;
$staffname=$_SESSION["subname"];




$_SESSION["pass"]=$pass;
$_SESSION["name"]=$name;


if($name && $pass)
{
	//echo "session valid";
}
else{
    //echo "session doesnot valid";
}
?>
<?php

$dept=$_SESSION["dept"];

 //echo $staffname;
$set=explode("-",$staffname);

 
//echo $staff;
//echo $sub;
$dbhost = "localhost";
   $dbuser = "root";
   $dbpass = "";

   $con = mysql_connect($dbhost, $dbuser, $dbpass);
   $db=mysql_select_db("dept_details",$con)or die(mysql_error());
   if($db)
   {
  //echo "connected";
   }
   
   if(! $con ) {
      die('Could not connect: ' . mysql_error());
      }
	  //echo "connection successful";
	  
$str= "SELECT *FROM  feedback where staff_name='$set[0]' AND subname ='$set[1]' AND dept='$dept'";
if($str)
{
	//echo "con str";
	
}
$result=mysql_query($str,$con);
if($result)
{
	//echo "connected result";
}

?>  
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Feedback</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>

  <header>
  <nav class="navbar navbar-default navbar" id="main-menu" role="banner">
<div class="container">
<div class="navbar-header"><button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse" type="button"><span class="sr-only">Toggle navigation</span></button><a class="navbar-brand" href="index.html"><img class="clglogo" alt="logo"  src="IMAGE/logo-sasurie.png" id="img"></a></div>
<div class="collapse navbar-collapse navbar-left" id="navbar">
<ul class="nav navbar-nav"><center>
  <p>Sasurie Feedback System</p></center></ul>
  <button= data-toggle="modal" data-target="#myModal"><img src="IMAGE/download.jpg" class="img-circle" alt="cinque terre" width="60" height="60"></button>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
                    <form action="dept.html" method="POST">
           <button type="button" class="close">&times;</button></form>
          <a href="logout.php">
          <button type="submit" class="btn btn-primary">Log out</button></a>
        </div>
        <div class="modal-body"><a href="password.php">
          <button type="submit" class="btn btn-primary">Change password </button> </a>      </div>
        <div class="modal-footer">
        </div>
      </div>
      </div>
    </div>
  </div>
  </div>
</nav>
</header>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-2">
    </div>
    <div class="col-sm-4" id="sub">
    Subject name:<?php echo $set[1];?></div>
    <div class="col-sm-4" id="staff">
    Staff name:<?php echo $set[0];?></div>
    <div class="col-sm-2">
    </div>
  </div></div>
  </br>
  <div class="container">
    <div class="row">
      <div class="col-sm-2">
      </div>
      
    <div class="form-group">
    
            <label for="comment1" id="ttt">Student FeedBack:</label>
      <br>
	 <div class="scroll-table-container">
      <table class="scroll-table">
       <tr class="row1">
  
  <td><center><b>Feedback</b></center></td>
</tr>
<?php
    while($row=mysql_fetch_assoc($result))
    {
      $feed=$row['feedback'];
     
    ?>
        <tr>
        <td><?php echo $feed;?></td>
    </tr>
    <?php
    }
    ?>
    
</table>
    </div>
  </div>
	   <form method="post" action="update1.php">
      <div class="col-sm-2">
      </div>
    </div>
      </div>
	 
      <div class="form-group">
	  
            <label for="comment" id="tt">Comment:</label>
			<br>
           <textarea class="form-control" name="suggest" rows="5" id="comment" required></textarea>
        </div>
        <div class="row">
		<div class="col-sm-6">
      <input type="submit" name="submit" class="btn btn-primary" id="submit">
</div> 

	  </form>
    <!--<div class="col-sm-6">    
 <button class="btn btn-primary" id="ba"><a href="subject.php" id="text">BACK</a></button></div>
</div>-->
    </body>
      </html>  





<style>
      .scroll-table-container {box-shadow:0px 0px 3px green; height: 300px; overflow: scroll;margin-top:6%;
        margin-left:18%; width:900px;}
      .scroll-table, td, th{border-collapse:collapse; border:1px solid #777; min-width: 900px;}
    </style>
<style>
#main-menu
{
  background-color:#66d9ff;
  height: 130px;
  box-shadow: 0px 0px 5px white;
}
#navbar
{
  padding-left: 180px;
  font-family: Andalus;
  color:#ff4da6;
  background-color:#66d9ff;
  text-shadow: 0px 0px 2px black;
}
.nav
{
 margin-left:15px;
 padding-top: 25px;
 font-size:40px;
}
#img
{
 margin-top:-20px;
 height: 200px; 
 width:165px;
 margin-left:-19px;
}
.img-circle
{
  margin-left:130%;
  margin-top:-15%;
}
#sub
{
  font-size:20px;
  margin-left:65px;
  margin-top:-10px;
}
#staff
{
  font-size:20px;
  margin-top:-10px;
}
#scroll-table
{
  margin-left:30%;
  margin-top:5%;
}
#row
{
  font-weight:bold;
  font-size:16px;
}
#sug
{
  font-size:20px;
}
#tt
{
  margin-left:22.5%;
  font-size:20px;
  margin-top:-10%;
}
#ttt {
    margin-left:8.5%;
    font-size: 20px;
    margin-top: 3%;
}
#comment1
{
  margin-top:5%;
  margin-left:22.5%;
  width:55%;
  font-size:16px;
}
#comment
{
  margin-top:-0.8%;
  margin-left:22.5%;
  width:55%;
  font-size:16px;
}
#submit
{
 margin-left:95%;
}
#table
{
  margin-top:-20px;
}
#ba
{
  height:35px;
  margin-left:20%;
  }
#text
{
  color:white;
}
</style>