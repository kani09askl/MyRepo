<html>
<head>
<title>CCC-GENERATE</title>
<style type="text/css">
#b1{
 height: 40px;
     width: 100px;
      border-radius: 8px;
background-color: #4eea4a;
border:none;
border-radius: 10px;
}
#b1:hover{
box-shadow: 2px 2px 20px;
}

</style>

<script>
function validateForm() {
    var x = document.forms["myform"]["reg"].value;

    if (x == "") {
        alert("Enter REGno");
        return false;
    }
   
}

</script>

</head>

<body >

<center><img src="img/logo_clg.jpg" alt="logo" height="200" width="900"></center>
<center><h2>Enter Regno for Generate CC-Certificate</h2></center>
<div id="d1">
<br><br>
<center><form name="myform" method="post" action="ccdisplay.php" onsubmit="return validateForm()">
Regno: <input type="text" name="reg" ><br><br>
<input type="submit" value="submit" id="b1"> &nbsp;&nbsp;<input type="button" onClick="location.href='Index.php';" id="b1" value="HOME" /></center>
</form></center>
</div>
<footer><h3 align="right"><strong>Developed by Sasurie Info-Tech(SIT)</strong></h3></footer>
</body>

</html>
