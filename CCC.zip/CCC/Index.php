<html>
<head>
<title>CCC-INDEX</title>
<style type="text/css">

.b1{
 height: 50px;
     width: 120%;
      border-radius: 8px;
background-color:#33FFFF;
border:none;
border-radius: 20px;
font-style:inherit;
}
.b1:hover{
box-shadow: 2px 2px 20px;
}

</style>
</script>
</head>


<body background="img/bg6.jpg">
<center><img src="img/logo_clg.jpg" alt="logo" height="200" width="900"></center>
<div id="d1">
<br><br><br><br>
<b>
<table align="center" cellspacing="10" cellpadding="10">
<tr><td><input type="button" class="b1" value="BE CSE" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="BE ECE" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="BE EEE" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="BE CIVIL" onclick="location.href='view.php';" ></td></tr>

<tr><td><input type="button" class="b1" value="BE MECH" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="ME CSE" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="ME AE" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="ME CS" onclick="location.href='view.php';" ></td></tr>

<tr><td><input type="button" class="b1" value="ME PED" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="MTECH IT" onclick="location.href='view.php';" ></td>
<td><input type="button" class="b1" value="MBA" onclick="location.href='view.php';" ></td></tr>

</table></b>
<footer><h3 align="left"><strong>Developed by Sasurie Info-Tech(SIT)</strong></h3></footer>
</div>
</body>
</html>
