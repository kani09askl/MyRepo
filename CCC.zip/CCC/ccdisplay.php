<html>
<head>
<title>CCC-Display</title>
<style type="text/css">

#printableArea{
size:29cm 21cm 7cm; margin:0px;
}

@page{size:29cm 21cm 7cm; margin:0px;
}

#b1{
 height: 40px;
     width: 100px;
      border-radius: 8px;
background-color: #4eea4a ;
}

#d1{
border-style:solid;
border-width:3px;

margin-left:40px;
margin-right:40px;
margin-top:0px;
margin-bottom:10px;
padding-left:40px;
padding-right:40px;

}

#d2{
border-style:solid;
border-width:3px;

margin-left:60px;
margin-right:20px;
margin-top:0px;
margin-bottom:10px;
padding-left:40px;
padding-right:40px;

}


.b1{
height: 40px;
     width: 100px;
      border-radius: 12px;
background-color: #5f9de8  ;
border:none;
border-radius: 10px;
}
.b1:hover{
box-shadow: 2px 2px 20px;
}


 h4 {
   font-style: italic;
 }


</style>
</head>
<body>

<?php
if (isset($_POST)) {

$reg=$_POST['reg'];
//echo $table;
} ?>

<?php
header('Content-Type:text/html;charset=utf-8');
 
//$reg=$_POST['reg'];
//$table=$_POST['table'];

$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$con = mysql_connect($servername, $username, $password);

// Check connection
if (!$con) {
    die("Connection failed: " . mysql_connect_error());
}
//echo "Connected successfully";
 

$db=mysql_select_db("cc_db",$con)or die(mysql_error());


$str="SELECT * FROM cc_data where regno='$reg' ";

$result = mysql_query($str,$con);

 /*if ($result) { echo "done</br>";}
else
//echo "problem";*/


while($row=mysql_fetch_array($result)){

$sno=$row['sno'];
$name=$row['name'];
$regno=$row['regno'];
$gen=$row['gen'];
$dept=$row['dept'];
$yoj=$row['yoj'];
$yoc=$row['yoc'];

$sno2 = sprintf('%04d',$sno);

if($gen=="M")
{
  $g1="Mr";
  $g2="He";
  $g3="his";
  $g4="His";
}
else
{
  $g1="Ms";
  $g2="She";
  $g3="her";
  $g4="Her";
}


}

?>

<div id="printableArea">
<br>
<div id="d1">
<center><img src="img/clglogo copy.jpg" alt="logo" height="130" width="600"></center>
<center><h3>COURSE COMPLETION CERTIFICATE</h3></center>
<h4 align="right">S.No:<?php echo $sno2; ?></h4>

<table width=100% height=auto><tr><td align="center"><h4> This is to certify that &nbsp;&nbsp;<?php echo ($g1); ?>  &nbsp;<strong><u><?php echo ($name); ?></u></strong>
&nbsp;&nbsp;Register No. <strong><u><?php echo ($regno); ?></u></strong> </h4></td></tr> 
<tr><td align="center"><h4>has studied &nbsp;<strong><u><?php echo ($dept); ?></u></strong>&nbsp course in this college from the year &nbsp;&nbsp;<strong><u><?php echo ($yoj); ?></u></strong> &nbsp;&nbsp;To &nbsp;&nbsp;<strong><u><?php echo ($yoc); ?></u></strong></h4></td></tr>
<tr><td align="center"><h4><?php echo ($g2); ?> has completed the duration of &nbsp;<?php echo ($g3); ?> course.</h4></td></tr>
<tr><td align="center"><h4><?php echo ($g4); ?> conduct and character during the study period were <strong>.....................</strong></h4></td>
</tr></table>
<table width="100%">
<tr><td><h4>Place &nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp; Vijayamangalam<br>
Date &nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</h4></td><td align="right"><h4>Principal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h4></td></tr>
</table>
<br><br>
</div>
<br><br>
<div id="d2">
<center><img src="img/clglogo copy.jpg" alt="logo" height="130" width="600"></center>
<center><h3>COURSE COMPLETION CERTIFICATE</h3></center>
<h4 align="right">S.No:<?php echo $sno2; ?></h4>

<table width=100% height=auto><tr><td align="center"><h4> This is to certify that &nbsp;&nbsp;<?php echo ($g1); ?>  &nbsp;<strong><u><?php echo ($name); ?></u></strong>
&nbsp;&nbsp;Register No. <strong><u><?php echo ($regno); ?></u></strong> </h4></td></tr> 
<tr><td align="center"><h4>has studied &nbsp;<strong><u><?php echo ($dept); ?></u></strong>&nbsp course in this college from the year &nbsp;&nbsp;<strong><u><?php echo ($yoj); ?></u></strong> &nbsp;&nbsp;To &nbsp;&nbsp;<strong><u><?php echo ($yoc); ?></u></strong></h4></td></tr>
<tr><td align="center"><h4><?php echo ($g2); ?> has completed the duration of &nbsp;<?php echo ($g3); ?> course.</h4></td></tr>
<tr><td align="center"><h4><?php echo ($g4); ?> conduct and character during the study period were <strong>.....................</strong></h4></td>
</tr></table>
<table width="100%">
<tr><td><h4>Place &nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp; Vijayamangalam<br>
Date &nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</h4></td><td align="right"><h4>Principal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h4></td></tr>
</table>
<br /><br>
</div>

</div>
<center><input type="button" class="b1" onClick="printDiv('printableArea')" value="print"/>&nbsp;&nbsp;<input type="button" onClick="location.href='view.php';" class="b1" value="NEW CC" />&nbsp;&nbsp;<input type="button" onClick="location.href='Index.php';" class="b1" value="HOME" /></center>
</body>

</html>

<script type="text/javascript">
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>
