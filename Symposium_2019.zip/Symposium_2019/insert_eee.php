 <?php
require 'db.php';
$name=$_POST['Name'];
$year=$_POST['year'];
$clg=$_POST['clg_name'];
$dept=$_POST['Dept'];
$num=$_POST['Whatsapp_no'];
$mail=$_POST['email_id'];
$eee=$_POST['eee'];
//echo $name.'-'.$year.'-'.$clg.'-'.$dept.'-'.$num.'-'.$mail.'-'.$computer;
if($eee){
$eve1=$_POST['Event1'];
$eve2=$_POST['Event2'];
$eve3=$_POST['Event3'];
$eve4=$_POST['Event4'];
$eve5=$_POST['Event5'];
$sql = "SELECT * FROM eee_reg where Name='$name'&&clg_name='$clg'&&Dept='$dept'&&year='$year'&&email_id='$mail'&&Whatsapp_no='$num'&&Event1='$eve1'&&Event2='$eve2'&&Event3='$eve3'&&Event4='$eve4'&&Event5='$eve5'";
$res=mysqli_query($conn,$sql);
if (mysqli_num_rows($res) >= 1) {
		echo "<script type=\"text/javascript\">window.alert('Data Already Inserted');window.location.href = 'eee.html';</script>";
	}
	else{
		$str= "INSERT INTO eee_reg VALUES ('','$name','$clg','$dept','$year','$mail','$num','$eve1','$eve2','$eve3','$eve4','$eve5')";
		$result= mysqli_query($conn, $str);
		if($result){
			echo "<script type=\"text/javascript\">window.alert('Data Inserted successfully');window.location.href = 'index.html';</script>"; 
		}}
}
mysql_close($conn);
?> 