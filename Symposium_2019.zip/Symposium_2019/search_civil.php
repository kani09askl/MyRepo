<?php
require "db.php";

$n=$_POST['name'];
//echo $n;
$clg=$_POST['clg_name'];
//echo $clg;
$d=$_POST['dept'];
//echo $d;
$y=$_POST['year'];
//echo $y;
$mail=$_POST['mailid'];
//echo $mail;
$number=$_POST['num'];
//echo $number;
$cbtn=$_POST['button1'];
//echo $cbtn;



if($cbtn){
	$e1=$_POST['ev1'];
	//echo $e1;
	$e2=$_POST['ev2'];
	//echo $e2;
	$e3=$_POST['ev3'];
	//echo $e3;
	$e4=$_POST['ev4'];
	//echo $e4;
	$e5=$_POST['ev5'];
	//echo $e5;
	$sql = "SELECT * FROM civil_reg WHERE Name='$n' && clg_name ='$clg' && Dept ='$d' && year='$y' && email_id = '$mail' && Whatsapp_no = '$number' && Event1='$e1' && Event2 ='$e2' && Event3 ='$e3' && Event4='$e4' && Event5 ='$e5'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) >= 1) {
		echo "<script type=\"text/javascript\">window.alert('Data Already Inserted');window.location.href = 'civil.html';</script>";
	}
	else{
		$s = "INSERT INTO civil_reg VALUES ('','$n','$clg','$d','$y','$mail','$number','$e1','$e2','$e3','$e4','$e5')";
		$res = mysqli_query($conn, $s);
		if($res){
			echo "<script type=\"text/javascript\">window.alert('Data Inserted successfully');window.location.href = 'index.html';</script>"; 
		}
	}
	mysql_close($conn);
}



?>
